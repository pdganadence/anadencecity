/* ========================================================================
   ANADENCE CITY — Application de gestion de centre de formation
   ======================================================================== */
const STORAGE_KEY = 'anadence_db_v1';
let DB = null;
let state = { role: null, userName: '', userId: null, section: 'dashboard' };
let pendingDelete = null;

/* ---------- Visionneuse plein écran (agrandir une image sans dépasser l'écran) ---------- */
function openImgLightbox(src){
  if(!src) return;
  document.getElementById('imgLightboxImg').src = src;
  document.getElementById('imgLightboxOverlay').classList.add('show');
}
function closeImgLightbox(){
  document.getElementById('imgLightboxOverlay').classList.remove('show');
  document.getElementById('imgLightboxImg').src = '';
}
document.getElementById('imgLightboxOverlay').addEventListener('click', e=>{
  if(e.target.id==='imgLightboxOverlay' || e.target.id==='imgLightboxImg') closeImgLightbox();
});
document.getElementById('imgLightboxClose').addEventListener('click', closeImgLightbox);
document.addEventListener('keydown', e=>{ if(e.key==='Escape') closeImgLightbox(); });
document.getElementById('btnRetryLoadDB')?.addEventListener('click', ()=> location.reload());

/* ---------- Bouton oeil : afficher/masquer les champs mot de passe ---------- */
document.querySelectorAll('.password-toggle-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const input = document.getElementById(btn.dataset.toggleFor);
    if(!input) return;
    const icon = btn.querySelector('i');
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    icon.className = isHidden ? 'bi bi-eye-slash' : 'bi bi-eye';
  });
});

/* ========================================================================
   CONFIGURATION FIREBASE
   Remplacez les valeurs ci-dessous par celles de VOTRE projet Firebase :
   Console Firebase → (⚙️ Paramètres du projet) → Vos applications → SDK setup and configuration
   ======================================================================== */
const firebaseConfig = {
  apiKey: "AIzaSyADH5uAzHO5OX-aRDX69jVINEg1oEccF6w",
  authDomain: "anadencecity2.firebaseapp.com",
  projectId: "anadencecity2",
  storageBucket: "anadencecity2.firebasestorage.app",
  messagingSenderId: "347862144836",
  appId: "1:347862144836:web:e230d9c1430bf354a42911"
};
firebase.initializeApp(firebaseConfig);
const firestore = firebase.firestore();
// Un seul document contient toute la base (même logique que l'ancien stockage local)
const dbDocRef = firestore.collection('anadence').doc('centre-formation');

/* ---------- Upload de fichiers vers Cloudinary (photos, preuves, CV, documents) -----------
   On stocke uniquement l'URL renvoyée par Cloudinary dans Firestore, au lieu du fichier
   encodé en base64 : le document Firestore reste léger, donc l'ouverture et la sauvegarde
   de l'application restent rapides même quand beaucoup de photos/fichiers sont ajoutés. */
const CLOUDINARY_CLOUD_NAME = 'izzv5vj3';
const CLOUDINARY_UPLOAD_PRESET = 'anadence_files';
async function uploadToCloudinary(file){
  const fd = new FormData();
  fd.append('file', file);
  fd.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/auto/upload`, { method:'POST', body: fd });
  if(!res.ok) throw new Error("Échec de l'envoi vers Cloudinary");
  const data = await res.json();
  return data.secure_url;
}
// Suivi des envois en cours : les formulaires attendent la fin de l'upload avant d'enregistrer,
// pour ne jamais sauvegarder une URL locale temporaire (blob:) qui ne survivrait pas au rechargement.
const pendingUploads = new Map();
function trackPendingUpload(key, promise){
  pendingUploads.set(key, promise);
  promise.finally(()=>{ if(pendingUploads.get(key)===promise) pendingUploads.delete(key); });
}
async function resolvePendingUpload(key){
  const p = pendingUploads.get(key);
  if(p){ try{ await p; }catch(err){ /* déjà signalé par l'appelant d'origine */ } }
}

const ROLES = [
  {id:'direction', label:'Direction', icon:'bi-briefcase-fill'},
  {id:'secretariat', label:'Secrétariat', icon:'bi-journal-text'},
  {id:'comptabilite', label:'Comptabilité', icon:'bi-calculator-fill'},
  {id:'formateur', label:'Formateur', icon:'bi-person-workspace'},
  {id:'etudiant', label:'Étudiant', icon:'bi-mortarboard-fill'},
  {id:'partenaire', label:'Partenaire', icon:'bi-hand-thumbs-up-fill'},
];
// Rôles regroupés sous l'onglet "Administration" dans le menu Utilisateurs (direction, secrétariat, comptabilité,
// + tout futur profil ajouté qui ne serait ni formateur, ni étudiant, ni partenaire).
const ADMIN_ROLE_IDS = ['direction','secretariat','comptabilite'];

const NAV = [
  {section:'dashboard', label:'Tableau de bord', icon:'bi-speedometer2', roles:['direction','secretariat','comptabilite','formateur','etudiant','partenaire']},
  {section:'etudiants', label:'Étudiants', icon:'bi-people-fill', roles:['direction','secretariat','comptabilite','formateur']},
  {section:'filieres', label:'Filières', icon:'bi-mortarboard-fill', roles:['direction','secretariat','formateur']},
  {section:'formateurs', label:'Formateurs', icon:'bi-person-workspace', roles:['direction','secretariat']},
  {section:'paiements', label:'Paiements', icon:'bi-cash-coin', roles:['direction','comptabilite','etudiant']},
  {section:'evaluations', label:'Évaluations', icon:'bi-clipboard-check-fill', roles:['direction','secretariat','formateur','etudiant']},
  {section:'rapports', label:'Rapports de chantier', icon:'bi-clipboard-data-fill', roles:['direction','secretariat','formateur','etudiant']},
  {section:'presences', label:'Présences', icon:'bi-calendar-check-fill', roles:['direction','secretariat','formateur','etudiant']},
  {section:'documents', label:'Documents', icon:'bi-folder-fill', roles:['direction','secretariat','formateur','etudiant','partenaire']},
  {section:'annonces', label:'Annonces', icon:'bi-megaphone-fill', roles:['direction','secretariat','comptabilite','formateur','etudiant','partenaire']},
  {section:'messagerie', label:'Messagerie', icon:'bi-chat-dots-fill', roles:['direction','secretariat','comptabilite','formateur','etudiant','partenaire']},
  {section:'monprofil', label:'Mon profil', icon:'bi-person-badge-fill', roles:['formateur','etudiant']},
  {section:'parametres', label:'Paramètres', icon:'bi-gear-fill', roles:['direction']},
];

/* ---------- Autorisations par menu (par défaut selon le rôle, ajustables par utilisateur) ---------- */
// Modules pour lesquels une case "Gérer" (créer/modifier/supprimer) a un sens
const MANAGE_MODULES = ['etudiants','filieres','formateurs','paiements','evaluations','rapports','presences','documents','annonces'];
// Réglages "Gérer" par défaut selon le rôle (utilisés pour pré-remplir un nouveau compte)
const DEFAULT_MANAGE = {
  etudiants: ['direction','secretariat'],
  filieres: ['direction','secretariat'],
  formateurs: ['direction','secretariat'],
  paiements: ['direction','comptabilite'],
  evaluations: ['direction','formateur'],
  rapports: ['direction','formateur','secretariat','etudiant'],
  presences: ['direction','formateur','secretariat'],
  documents: ['direction','secretariat'],
  annonces: ['direction','secretariat'],
};
// Liste des menus pouvant être cochés individuellement (hors tableau de bord, mon profil et utilisateurs, gérés à part)
const PERMISSION_MODULES = NAV.filter(n=>!['dashboard','monprofil','parametres'].includes(n.section));

function defaultPermsForRole(role){
  const perms = {};
  PERMISSION_MODULES.forEach(n=>{
    perms[n.section] = {
      view: n.roles.includes(role),
      manage: MANAGE_MODULES.includes(n.section) ? (DEFAULT_MANAGE[n.section]||[]).includes(role) : false,
    };
  });
  return perms;
}
function currentUser(){ return DB && DB.users ? DB.users.find(u=>u.id===state.userId) : null; }
function hasPerm(section, type){
  if(section==='parametres') return state.role==='direction';
  if(section==='monprofil') return state.role==='formateur' || state.role==='etudiant';
  if(section==='dashboard') return true;
  if(state.role==='direction') return true; // la direction a toujours accès complet
  const u = currentUser();
  const perms = (u && u.perms && u.perms[section]) ? u.perms[section] : defaultPermsForRole(state.role)[section];
  return !!(perms && perms[type]);
}

/* ---------- Portée des données (chaque profil ne voit que ce qui le concerne) ---------- */
function scopedFiliereIds(){
  const u = currentUser();
  if(state.role==='formateur' && u && u.formateurId){
    const filIds = modulesOfFormateur(u.formateurId).map(m=>m.filiereId);
    return [...new Set(filIds)];
  }
  if(state.role==='etudiant' && u && u.etudiantId){
    const et = DB.etudiants.find(e=>e.id===u.etudiantId);
    return et ? [et.filiereId] : [];
  }
  return null; // null = pas de restriction (voit toutes les filières autorisées)
}
function scopedFormateurOptionsHTML(){
  const u = currentUser();
  if(state.role==='formateur' && u && u.formateurId){
    return DB.formateurs.filter(f=>f.id===u.formateurId).map(f=>`<option value="${f.id}">${nomComplet(f)}</option>`).join('');
  }
  if(state.role==='etudiant'){
    const ids = scopedFiliereIds() || [];
    const formIds = [...new Set(DB.modules.filter(m=>ids.includes(m.filiereId)).map(m=>m.formateurId).filter(Boolean))];
    return DB.formateurs.filter(f=>formIds.includes(f.id)).map(f=>`<option value="${f.id}">${nomComplet(f)}</option>`).join('');
  }
  return null; // null = pas de restriction, utiliser la liste complète
}
function scopeFilieres(list){
  const ids = scopedFiliereIds();
  return ids ? list.filter(f=>ids.includes(f.id)) : list;
}
function scopeByFiliereId(list){
  const ids = scopedFiliereIds();
  return ids ? list.filter(x=>ids.includes(x.filiereId)) : list;
}
// Un formateur ne voit/gère que les modules qui lui sont confiés ; les autres profils sont limités à leur(s) filière(s).
function scopeModules(list){
  const u = currentUser();
  if(state.role==='formateur' && u && u.formateurId){
    return list.filter(m=>m.formateurId===u.formateurId);
  }
  const ids = scopedFiliereIds();
  return ids ? list.filter(m=>ids.includes(m.filiereId)) : list;
}
// Portée des présences : basée sur le module (via le formateur qui l'anime, ou la filière pour les autres profils).
function scopeByModuleId(list){
  const u = currentUser();
  if(state.role==='formateur' && u && u.formateurId){
    const modIds = modulesOfFormateur(u.formateurId).map(m=>m.id);
    return list.filter(x=>modIds.includes(x.moduleId));
  }
  const ids = scopedFiliereIds();
  if(!ids) return list;
  const modIds = DB.modules.filter(m=>ids.includes(m.filiereId)).map(m=>m.id);
  return list.filter(x=>modIds.includes(x.moduleId));
}
function scopeEtudiants(list){
  const u = currentUser();
  if(state.role==='etudiant'){
    return list.filter(e=>u && e.id===u.etudiantId);
  }
  const ids = scopedFiliereIds();
  let out = ids ? list.filter(e=>ids.includes(e.filiereId)) : list;
  // Le formateur ne doit voir que les étudiants actifs (pas les abandons ni les diplômés)
  if(state.role==='formateur'){
    out = out.filter(e=>e.statut==='actif');
  }
  return out;
}

/* ---------- Helpers ---------- */
const uid = () => Math.random().toString(36).slice(2,9);
const fmtCFA = n => new Intl.NumberFormat('fr-FR').format(Math.round(n||0)) + ' F';
const fmtDate = d => d ? new Date(d).toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'}) : '—';
// Affichage lisible de la dernière connexion d'un compte (utilisé par la direction pour suivre l'activité
// des utilisateurs) : "Aujourd'hui à 14:32", "Hier à ...", "Il y a X jours", ou la date complète au-delà d'une
// semaine. Un compte resté inactif 30 jours ou plus est mis en évidence en rouge.
function fmtDerniereConnexion(iso){
  if(!iso) return '<span class="text-muted fst-italic">Jamais connecté</span>';
  const d = new Date(iso);
  if(isNaN(d.getTime())) return '<span class="text-muted fst-italic">Jamais connecté</span>';
  const now = new Date();
  const startOfDay = dt => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
  const diffDays = Math.round((startOfDay(now) - startOfDay(d)) / 86400000);
  const heure = d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
  let label;
  if(diffDays<=0) label = `Aujourd'hui à ${heure}`;
  else if(diffDays===1) label = `Hier à ${heure}`;
  else if(diffDays>1 && diffDays<7) label = `Il y a ${diffDays} jours`;
  else label = `${d.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'})} à ${heure}`;
  return diffDays>=30 ? `<span class="text-danger">${label}</span>` : `<span>${label}</span>`;
}
const initials = (a,b='') => (((a||'?')[0]||'')+((b||'')[0]||'')).toUpperCase();
function avatarHTML(o, size, shape){
  size = size||34;
  const cls = shape==='square' ? 'avatar-img-square' : 'avatar-img';
  if(o && o.photo){ return `<img src="${o.photo}" class="${cls}" style="width:${size}px;height:${size}px;">`; }
  return `<div class="avatar-circ" style="width:${size}px;height:${size}px;font-size:${size<40?'.7rem':'1rem'};">${initials(o?o.prenom:'',o?o.nom:'')}</div>`;
}
// Retourne le badge du logo du centre (affiché en haut à droite des fiches) si un logo a été configuré dans les Paramètres
function ficheLogoBadgeHTML(){
  return (DB && DB.parametres && DB.parametres.logo) ? `<img src="${DB.parametres.logo}" class="fiche-logo-badge">` : '';
}
// Numéro matricule au format: <n° d'ordre sur 3 chiffres>CF<mois d'inscription sur 2 chiffres><année d'inscription sur 2 chiffres>
// Exemple : 001CF0622 => n° d'ordre 001, inscrit en 06 (juin) 2022
// Exemple : 006CF0126 => n° d'ordre 006, inscrit en 01 (janvier) 2026
// Le n° d'ordre est unique pour chaque étudiant (jamais partagé), attribué automatiquement de façon
// croissante selon l'ordre d'inscription, mais modifiable manuellement par la direction si besoin.
function computeMatricule(ordre, dateInscription){
  const d = dateInscription ? new Date(dateInscription) : new Date();
  const annee2 = String(d.getFullYear()).slice(-2);
  const mois = String(d.getMonth()+1).padStart(2,'0');
  const ordreNum = Number(ordre)||0;
  return `${String(ordreNum).padStart(3,'0')}CF${mois}${annee2}`;
}
// Prochain n° d'ordre disponible : le plus grand n° d'ordre déjà utilisé + 1
function nextOrdreEtudiant(){
  const max = DB.etudiants.reduce((m,e)=>Math.max(m, Number(e.ordre)||0), 0);
  return max + 1;
}
// Vérifie qu'un n° d'ordre n'est pas déjà utilisé par un autre étudiant (excludeId = étudiant en cours d'édition)
function ordreEtudiantDejaUtilise(ordre, excludeId){
  const ordreNum = Number(ordre);
  return DB.etudiants.some(e=>e.id!==excludeId && Number(e.ordre)===ordreNum);
}
function updateMatriculeDisplay(){
  const f = document.getElementById('formEtudiant');
  if(!f) return;
  const wrap = document.getElementById('ordreEditWrap');
  const editing = wrap && !wrap.classList.contains('d-none');
  const ordreVal = editing ? document.getElementById('inputEtudiantOrdreEdit').value : document.getElementById('inputEtudiantOrdre').value;
  const dateEl = f.elements['dateInscription'];
  const display = document.getElementById('matriculeDisplayText');
  if(!display) return;
  display.textContent = (ordreVal && dateEl.value) ? computeMatricule(ordreVal, dateEl.value) : '—';
}
function toast(msg){ document.getElementById('toastMsg').textContent = msg; new bootstrap.Toast(document.getElementById('mainToast')).show(); }
function getFiliere(id){ return DB.filieres.find(f=>f.id===id); }
function getFormateur(id){ return DB.formateurs.find(f=>f.id===id); }
function getEtudiant(id){ return DB.etudiants.find(e=>e.id===id); }
function getModule(id){ return DB.modules.find(m=>m.id===id); }
function modulesOfFiliere(filId){ return DB.modules.filter(m=>m.filiereId===filId); }
function modulesOfFormateur(forId){ return DB.modules.filter(m=>m.formateurId===forId); }
function nomComplet(o){ return o ? `${o.prenom} ${o.nom}` : '—'; }
function waLink(phone){
  if(!phone) return '';
  let digits = String(phone).replace(/\D/g,'');
  if(digits.startsWith('0')) digits = digits.slice(1);
  if(!digits.startsWith('229')) digits = '229'+digits;
  return `https://wa.me/${digits}`;
}

// Liste des types de versement rattachés au coût de la formation (tranches + solde) : ce sont les
// seuls pris en compte pour le calcul de ce que l'étudiant doit encore et pour l'échéancier.
// Frais d'inscription, Uniforme et Autre sont des frais annexes, suivis séparément mais jamais
// additionnés au coût de la formation pour ces calculs.
const TYPES_PAIEMENT_FORMATION = ['Tranche 1','Tranche 2','Tranche 3','Solde'];
function paiementEstFormation(p){
  if(typeof p.estFormation === 'boolean') return p.estFormation;
  return TYPES_PAIEMENT_FORMATION.includes(p.type); // compat. anciens versements sans le champ
}
function etudiantFinance(etId){
  const et = getEtudiant(etId);
  // Ce que l'étudiant doit (et l'échéancier) ne portent que sur le coût de la formation : on ne
  // fait pas la somme avec les frais d'inscription, d'uniforme ou autres frais, qui sont suivis
  // à part. Seuls les versements de type Tranche/Solde sont comptés comme réglant ce montant.
  const total = et ? (Number(et.coutFormation)||0) : 0;
  const paye = DB.paiements.filter(p=>p.etudiantId===etId && paiementEstFormation(p)).reduce((s,p)=>s+Number(p.montant),0);
  const reste = Math.max(total-paye,0);
  let statut = 'Impayé';
  if(reste<=0 && total>0) statut='Payé'; else if(paye>0) statut='Partiel';
  return {total,paye,reste,statut};
}
// Suivi séparé des frais annexes (inscription + uniforme + autres frais) : même logique que
// etudiantFinance mais sur le total de ces frais, réglés par les versements qui ne sont pas des
// tranches/solde de formation (Frais d'inscription, Uniforme, Autre).
function etudiantAutresFrais(etId){
  const et = getEtudiant(etId);
  const total = et ? (Number(et.fraisInscription)||0) + (Number(et.fraisUniforme)||0) + (Number(et.autresFraisMontant)||0) : 0;
  const paye = DB.paiements.filter(p=>p.etudiantId===etId && !paiementEstFormation(p)).reduce((s,p)=>s+Number(p.montant),0);
  const reste = Math.max(total-paye,0);
  let statut = 'Impayé';
  if(reste<=0 && total>0) statut='Payé'; else if(paye>0) statut='Partiel';
  return {total,paye,reste,statut};
}

/* ---------- Échéancier de paiement (tranches propres à chaque étudiant, définies par la direction) ---------- */
// Les versements sont affectés aux tranches dans l'ordre chronologique : un versement solde d'abord
// le reste de la tranche la plus ancienne non soldée, puis le surplus éventuel est reporté sur la
// tranche suivante (et ainsi de suite), jusqu'à épuisement du montant versé.
function computeEcheancier(etId){
  const et = getEtudiant(etId);
  const fin = etudiantFinance(etId);
  const today = new Date(); today.setHours(0,0,0,0);
  const tranches = ((et && et.echeancier) || []).slice().sort((a,b)=> new Date(a.date) - new Date(b.date));
  let restantAAffecter = fin.paye;
  return tranches.map(tr=>{
    const montant = Number(tr.montant)||0;
    let paye, reste;
    if(restantAAffecter >= montant){ paye = montant; reste = 0; restantAAffecter -= montant; }
    else if(restantAAffecter > 0){ paye = restantAAffecter; reste = montant - restantAAffecter; restantAAffecter = 0; }
    else { paye = 0; reste = montant; }
    const dateEch = tr.date ? new Date(tr.date) : null;
    const diffJours = dateEch ? Math.ceil((dateEch - today)/(1000*60*60*24)) : null;
    let statut = 'À venir';
    if(reste<=0.5) statut = 'Payé';
    else if(dateEch && diffJours<0) statut = 'En retard';
    else if(dateEch && diffJours<=30) statut = 'À échoir';
    return {...tr, montant, paye, reste, dateEch, diffJours, statut};
  });
}
// Échéances non soldées dont la date limite tombe dans les 30 jours (passés ou à venir) : sert au
// rappel affiché sur le tableau de bord et dans le menu paiement de l'étudiant concerné.
function echeancesARappeler(etId){
  return computeEcheancier(etId).filter(r=> r.statut==='En retard' || r.statut==='À échoir');
}

/* ---------- Génération PDF (police Poppins embarquée) ---------- */
let PDF_FONT_READY = null;
function bufferToBase64(buf){
  let binary = '';
  const bytes = new Uint8Array(buf);
  const chunk = 0x8000;
  for(let i=0;i<bytes.length;i+=chunk){
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i+chunk));
  }
  return btoa(binary);
}
async function ensurePdfFont(doc){
  if(!PDF_FONT_READY){
    PDF_FONT_READY = (async()=>{
      try{
        const base = 'https://raw.githubusercontent.com/google/fonts/main/ofl/poppins/';
        const [regBuf, boldBuf] = await Promise.all([
          fetch(base+'Poppins-Regular.ttf').then(r=>r.arrayBuffer()),
          fetch(base+'Poppins-Bold.ttf').then(r=>r.arrayBuffer()),
        ]);
        return { regular: bufferToBase64(regBuf), bold: bufferToBase64(boldBuf) };
      }catch(err){
        console.warn('Police Poppins indisponible pour le PDF (hors-ligne ?), utilisation de la police par défaut.', err);
        return null;
      }
    })();
  }
  const fonts = await PDF_FONT_READY;
  if(fonts){
    doc.addFileToVFS('Poppins-Regular.ttf', fonts.regular);
    doc.addFont('Poppins-Regular.ttf', 'Poppins', 'normal');
    doc.addFileToVFS('Poppins-Bold.ttf', fonts.bold);
    doc.addFont('Poppins-Bold.ttf', 'Poppins', 'bold');
    doc.setFont('Poppins', 'normal');
    return 'Poppins';
  }
  return 'helvetica';
}
function pdfHeader(doc, titre, sousTitre, font){
  font = font || 'helvetica';
  doc.setFillColor(22,35,63);
  doc.rect(0,0,210,26,'F');
  doc.setTextColor(255,255,255);
  doc.setFont(font,'bold');
  doc.setFontSize(14);
  doc.text('ANADENCE CITY', 14, 12);
  doc.setFontSize(9);
  doc.setFont(font,'normal');
  doc.text('Centre de formation professionnelle — Cotonou, Bénin', 14, 18);
  // Logo du centre configuré dans Paramètres (chargé et mis en cache en base64 par loadCentreLogoForPdf)
  if(typeof centreLogoPdfDataUrl !== 'undefined' && centreLogoPdfDataUrl){
    try{
      const logoSize = 16;
      doc.setFillColor(255,255,255);
      doc.roundedRect(210-14-logoSize, 5, logoSize, logoSize, 2, 2, 'F');
      doc.addImage(centreLogoPdfDataUrl, pdfImgFormat(centreLogoPdfDataUrl), 210-14-logoSize+1, 6, logoSize-2, logoSize-2);
    }catch(err){ console.error('Logo PDF non affiché', err); }
  }
  doc.setTextColor(30,30,30);
  doc.setFont(font,'bold');
  doc.setFontSize(15);
  doc.text(titre, 14, 35);
  if(sousTitre){
    doc.setFont(font,'normal');
    doc.setFontSize(10);
    doc.setTextColor(100,100,100);
    doc.text(sousTitre, 14, 43);
  }
  doc.setTextColor(30,30,30);
}
function pdfFooter(doc, font){
  font = font || 'helvetica';
  const pageCount = doc.internal.getNumberOfPages();
  for(let i=1;i<=pageCount;i++){
    doc.setPage(i);
    doc.setFont(font,'normal');
    doc.setFontSize(8);
    doc.setTextColor(150,150,150);
    doc.text(`Document généré le ${new Date().toLocaleDateString('fr-FR')} — ANADENCE CITY`, 14, 290);
    doc.text(`Page ${i}/${pageCount}`, 190, 290, {align:'right'});
  }
}

/* ---------- Rubriques stylées pour les fiches PDF (cartes bordées, contenu en 2 colonnes, sans grille de tableau) ---------- */
function pdfImgFormat(dataUrl){
  const m = /^data:image\/(\w+);base64,/i.exec(dataUrl||'');
  const t = m ? m[1].toLowerCase() : '';
  if(t==='png') return 'PNG';
  if(t==='webp') return 'WEBP';
  return 'JPEG';
}
function pdfParseImages(jsonStr){
  try{ const arr = JSON.parse(jsonStr||'[]'); return Array.isArray(arr) ? arr.slice(0,3) : []; }catch(err){ return []; }
}
function pdfStatBox(doc,x,y,w,h,label,value,color,font){
  doc.setDrawColor(228,231,236); doc.setLineWidth(0.15);
  doc.setFillColor(248,249,251);
  doc.roundedRect(x,y,w,h,2,2,'FD');
  doc.setFont(font,'bold'); doc.setFontSize(11.5);
  doc.setTextColor.apply(doc,color||[26,29,35]);
  doc.text(String(value), x+w/2, y+h/2+0.5, {align:'center'});
  doc.setFont(font,'normal'); doc.setFontSize(6.6);
  doc.setTextColor(107,114,128);
  doc.text(String(label).toUpperCase(), x+w/2, y+h-3, {align:'center'});
}
function pdfStatsRow(doc, x, y, w, stats, font){
  const gap=4, h=17.5;
  const bw=(w-gap*(stats.length-1))/stats.length;
  stats.forEach((s,i)=>pdfStatBox(doc,x+i*(bw+gap),y,bw,h,s.label,s.value,s.color,font));
  return y+h;
}
// Bandeau d'entête plein (trame navy) commun à toutes les rubriques de la fiche PDF,
// dans le même style que les entêtes de tableau "ÉCHÉANCIER DE PAIEMENT" / "HISTORIQUE DES PAIEMENTS"
function pdfSectionHeader(doc, x, y, w, title, font, h){
  h = h || 10;
  doc.setFillColor(22,35,63);
  doc.roundedRect(x, y, w, h, 2.5, 2.5, 'F');
  doc.rect(x, y+h-2.5, w, 2.5, 'F'); // carre les coins bas : bandeau arrondi en haut seulement
  doc.setFont(font,'bold'); doc.setFontSize(9.5); doc.setTextColor(255,255,255);
  doc.text(title.toUpperCase(), x+5, y+7);
  return y+h;
}
// Carte bordée avec titre + une rangée de mini-statistiques (ex: "État financier", "Présence")
function pdfStatsSection(doc, x, y, w, title, stats, font){
  const pad = 5, titleH = 10, gapAfterHeader = 4, statsH = 17.5, boxH = titleH + gapAfterHeader + statsH + pad - 1;
  if(y + boxH > 283){ doc.addPage(); y = 20; }
  doc.setDrawColor(228,231,236); doc.setLineWidth(0.2); doc.setFillColor(255,255,255);
  doc.roundedRect(x, y, w, boxH, 2.5, 2.5, 'FD');
  pdfSectionHeader(doc, x, y, w, title, font, titleH);
  pdfStatsRow(doc, x+pad, y+titleH+gapAfterHeader, w-pad*2, stats, font);
  return y+boxH;
}
// Carte bordée : titre + champs affichés en 2 colonnes, chaque libellé suivi directement de sa valeur sur la même ligne ("Sexe : Masculin")
function pdfSection(doc, x, y, w, title, fields, font){
  const pad = 5, colGap = 6, titleH = 10, lineH = 4.2, fs = 8.6;
  const colW = (w - pad*2 - colGap) / 2;
  const rows = [];
  for(let i=0;i<fields.length;i+=2) rows.push([fields[i], fields[i+1]||null]);

  // Pré-calcul : libellé (normal) + valeur (grasse) qui continue sur la même ligne, avec retour à la ligne si trop long
  // Même taille de police pour le libellé et la valeur afin que les deux restent parfaitement alignés sur la ligne de base
  const prepRows = rows.map(pair=>pair.map(f=>{
    if(!f) return null;
    const label = String(f[0]).toUpperCase()+' : ';
    doc.setFont(font,'normal'); doc.setFontSize(fs);
    const labelW = doc.getTextWidth(label);
    const valText = String(f[1]===0?'0':(f[1]||'—'));
    doc.setFont(font,'bold'); doc.setFontSize(fs);
    const firstLineW = Math.max(colW - labelW, 15);
    const words = valText.split(' ');
    let acc = '', i2 = 0;
    for(; i2<words.length; i2++){
      const trial = acc ? acc+' '+words[i2] : words[i2];
      if(doc.getTextWidth(trial) <= firstLineW || !acc){ acc = trial; } else break;
    }
    const firstLine = acc;
    const rest = words.slice(i2).join(' ');
    const restLines = rest ? doc.splitTextToSize(rest, colW) : [];
    return {label, labelW, firstLine, restLines};
  }));

  const rowHeights = prepRows.map(pair=>{
    let maxLines = 1;
    pair.forEach(f=>{ if(f){ maxLines = Math.max(maxLines, 1+f.restLines.length); } });
    return maxLines*lineH + 2.6;
  });
  const contentH = rowHeights.reduce((a,b)=>a+b,0);
  const boxH = titleH + contentH + pad - 0.5;
  if(y + boxH > 283){ doc.addPage(); y = 20; }
  doc.setDrawColor(228,231,236); doc.setLineWidth(0.2); doc.setFillColor(255,255,255);
  doc.roundedRect(x, y, w, boxH, 2.5, 2.5, 'FD');
  pdfSectionHeader(doc, x, y, w, title, font, titleH);
  let cy = y + titleH + 4;
  rows.forEach((pair,idx)=>{
    prepRows[idx].forEach((f,ci)=>{
      if(!f) return;
      const cx = x+pad + ci*(colW+colGap);
      doc.setFont(font,'normal'); doc.setFontSize(fs); doc.setTextColor(107,114,128);
      doc.text(f.label, cx, cy);
      doc.setFont(font,'bold'); doc.setFontSize(fs); doc.setTextColor(26,29,35);
      doc.text(f.firstLine, cx+f.labelW, cy);
      if(f.restLines.length) doc.text(f.restLines, cx, cy+lineH);
    });
    cy += rowHeights[idx];
  });
  return y + boxH;
}
// Carte bordée : titre + paragraphe de texte libre (ex: Modules suivis)
function pdfTextSection(doc,x,y,w,title,text,font){
  const pad = 5, titleH = 10;
  doc.setFont(font,'normal'); doc.setFontSize(8.8);
  const lines = doc.splitTextToSize(text||'—', w-pad*2);
  const boxH = titleH + lines.length*4.0 + pad;
  if(y + boxH > 283){ doc.addPage(); y = 20; }
  doc.setDrawColor(228,231,236); doc.setLineWidth(0.2); doc.setFillColor(255,255,255);
  doc.roundedRect(x, y, w, boxH, 2.5, 2.5, 'FD');
  pdfSectionHeader(doc, x, y, w, title, font, titleH);
  doc.setFont(font,'normal'); doc.setFontSize(8.8); doc.setTextColor(26,29,35);
  doc.text(lines, x+pad, y+titleH+4);
  return y + boxH;
}
// Carte bordée : titre + champs (comme pdfSection) + vignettes d'images jointes (preuve, diplômes...)
function pdfSectionWithImages(doc, x, y, w, title, fields, images, font){
  y = pdfSection(doc, x, y, w, title, fields, font);
  images = (images||[]).slice(0,3);
  if(images.length){
    const imgW = 42, imgH = 32, gap = 4;
    if(y + imgH + 8 > 283){ doc.addPage(); y = 20; }
    doc.setFont(font,'normal'); doc.setFontSize(6.6); doc.setTextColor(107,114,128);
    doc.text('PIÈCES JOINTES', x, y+8);
    y += 11;
    images.forEach((img,i)=>{
      const ix = x + i*(imgW+gap);
      try{
        doc.setDrawColor(228,231,236); doc.setLineWidth(0.2);
        doc.roundedRect(ix, y, imgW, imgH, 2, 2, 'S');
        doc.addImage(img, pdfImgFormat(img), ix+1, y+1, imgW-2, imgH-2);
      }catch(err){ /* image illisible : on l'ignore silencieusement */ }
    });
    y += imgH + 6;
  }
  return y;
}

async function exportEtudiantsListPdf(){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const search = (document.getElementById('searchEtudiant').value||'').toLowerCase();
  const filFilter = document.getElementById('filterFiliereEtudiant').value;
  const statutFilter = etudiantStatutFilter;
  const list = scopeEtudiants(DB.etudiants).filter(e=>{
    const matchSearch = (nomComplet(e)+e.matricule).toLowerCase().includes(search);
    const matchFil = !filFilter || e.filiereId===filFilter;
    const matchStatut = !statutFilter || e.statut===statutFilter;
    return matchSearch && matchFil && matchStatut;
  }).sort((a,b)=>`${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`,'fr',{sensitivity:'base'}));
  const showPaiementCol = state.role!=='formateur';
  pdfHeader(doc, 'Liste des étudiants inscrits', `${list.length} étudiant(s)` + (filFilter ? ' — Filière : '+getFiliere(filFilter)?.nom : ''), font);
  doc.autoTable({
    startY: 50,
    head: [showPaiementCol ? ['Matricule','Nom & Prénom','Filière','Téléphone','Statut','Paiement'] : ['Matricule','Nom & Prénom','Filière','Téléphone','Statut']],
    body: list.map(e=>{
      const fin = etudiantFinance(e.id);
      const nomAffiche = `${e.nom} ${e.prenom}`;
      return showPaiementCol ? [e.matricule, nomAffiche, getFiliere(e.filiereId)?.nom||'—', e.telephone, e.statut, fin.statut] : [e.matricule, nomAffiche, getFiliere(e.filiereId)?.nom||'—', e.telephone, e.statut];
    }),
    styles:{font},
    headStyles:{fillColor:[22,35,63], textColor:255, fontSize:9, font},
    bodyStyles:{fontSize:8.5, font},
    alternateRowStyles:{fillColor:[245,246,248]},
  });
  pdfFooter(doc, font);
  doc.save('liste-etudiants-anadence.pdf');
}

async function exportFinancierPdf(){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const filterStatut = document.getElementById('filterStatutPaiement').value;
  const filterFil = document.getElementById('filterFilierePaiement').value;
  const filterStatutEt = document.getElementById('filterStatutEtudiantPaiement').value;
  const search = (document.getElementById('searchPaiement').value||'').toLowerCase();
  let finances = scopeEtudiants(DB.etudiants).map(e=>({e, fin:etudiantFinance(e.id)}))
    .filter(x=> !filterStatut || x.fin.statut===filterStatut)
    .filter(x=> !filterFil || x.e.filiereId===filterFil)
    .filter(x=> !filterStatutEt || x.e.statut===filterStatutEt)
    .filter(x=> nomComplet(x.e).toLowerCase().includes(search));
  finances.sort((a,b)=>nomComplet(a.e).localeCompare(nomComplet(b.e),'fr',{sensitivity:'base'}));
  const totalCollecte = finances.reduce((s,x)=>s+x.fin.paye,0);
  const totalDu = finances.reduce((s,x)=>s+x.fin.total,0);
  const totalReste = Math.max(totalDu-totalCollecte,0);
  const taux = totalDu>0 ? Math.round((totalCollecte/totalDu)*100) : 0;
  const statutEtLabel = {actif:'Actif', abandon:'Abandon', diplome:'Diplômé'}[filterStatutEt];
  const sousTitreParts = [
    filterFil ? 'Filière : '+(getFiliere(filterFil)?.nom||'') : null,
    filterStatut ? 'Statut paiement : '+filterStatut : null,
    statutEtLabel ? 'Statut étudiant : '+statutEtLabel : null,
  ].filter(Boolean);
  const sousTitre = `${finances.length} étudiant(s)` + (sousTitreParts.length ? ' — '+sousTitreParts.join(' — ') : '');
  const M = 14, W = 182;
  pdfHeader(doc, 'État des paiements des étudiants', sousTitre, font);
  let y = pdfStatsSection(doc, M, 50, W, 'Récapitulatif', [
    {label:'Montant dû', value:fmtCFA(totalDu), color:[22,35,63]},
    {label:'Collecté', value:fmtCFA(totalCollecte), color:[28,122,70]},
    {label:'Reste à recouvrer', value:fmtCFA(totalReste), color:[176,51,39]},
    {label:'Taux', value:taux+'%', color:[22,35,63]},
  ], font) + 6;
  doc.autoTable({
    startY: y,
    head: [['Étudiant','Filière','Montant dû','Payé','Reste','Statut']],
    body: finances.map(x=>[nomComplet(x.e), getFiliere(x.e.filiereId)?.nom||'—', fmtCFA(x.fin.total), fmtCFA(x.fin.paye), fmtCFA(x.fin.reste), x.fin.statut]),
    styles:{font},
    headStyles:{fillColor:[22,35,63], textColor:255, fontSize:9, font},
    bodyStyles:{fontSize:8.5, font},
    alternateRowStyles:{fillColor:[245,246,248]},
  });
  pdfFooter(doc, font);
  doc.save('etat-paiements-etudiants-anadence.pdf');
}

/* ---------- Historique des paiements (toutes transactions, filtrable par nom, filière et période) ---------- */
function scopedPaiements(){
  const scopedIds = scopeEtudiants(DB.etudiants).map(e=>e.id);
  return DB.paiements.filter(p=>scopedIds.includes(p.etudiantId));
}
function filteredHistoriquePeriode(){
  let list = scopedPaiements();
  // Les filtres (nom/filière/période) ne s'appliquent que pour direction/comptabilité :
  // côté étudiant la carte n'affiche déjà que ses propres versements.
  if(state.role!=='etudiant'){
    const search = (document.getElementById('searchHistoriquePeriode').value||'').toLowerCase();
    const filFilter = document.getElementById('filterFiliereHistoriquePeriode').value;
    const from = document.getElementById('filterHistoriquePeriodeDateDebut').value;
    const to = document.getElementById('filterHistoriquePeriodeDateFin').value;
    if(search) list = list.filter(p=>{
      const e = getEtudiant(p.etudiantId);
      return e && nomComplet(e).toLowerCase().includes(search);
    });
    if(filFilter) list = list.filter(p=>{
      const e = getEtudiant(p.etudiantId);
      return e && e.filiereId===filFilter;
    });
    if(from) list = list.filter(p=>p.date>=from);
    if(to) list = list.filter(p=>p.date<=to);
  }
  return list;
}
function renderHistoriquePeriode(){
  const editable = canEdit('paiements');
  // Pour un étudiant, cette section montre uniquement son propre historique
  // (scopedPaiements() est déjà filtré via scopeEtudiants sur son id) : les filtres n'ont pas lieu d'être.
  document.getElementById('historiquePeriodeTitle').textContent = state.role==='etudiant'
    ? 'Mon historique des paiements'
    : 'Historique des paiements';
  document.getElementById('historiquePeriodeFilters').style.display = state.role==='etudiant' ? 'none' : '';
  const list = filteredHistoriquePeriode().slice().sort((a,b)=> new Date(b.date)-new Date(a.date));
  const total = list.reduce((s,p)=>s+Number(p.montant),0);
  document.getElementById('historiquePeriodeSummary').textContent = `${list.length} versement(s) — Total collecté : ${fmtCFA(total)}`;
  document.getElementById('historiquePeriodeBody').innerHTML = list.length ? list.map(p=>{
    const e = getEtudiant(p.etudiantId);
    return `<tr>
      <td>${fmtDate(p.date)}</td>
      <td>${e?nomComplet(e):'—'}</td>
      <td class="d-none d-md-table-cell">${e?getFiliere(e.filiereId)?.nom||'—':'—'}</td>
      <td class="fw-semibold text-success">${fmtCFA(p.montant)}</td>
      <td class="d-none d-lg-table-cell">${p.mode||'—'}</td>
      <td class="d-none d-lg-table-cell">${p.type||'—'}</td>
      <td class="text-end">${editable ? `<button class="btn btn-sm btn-icon" onclick="editPaiement('${p.id}')" title="Modifier"><i class="bi bi-pencil"></i></button>
      <button class="btn btn-sm btn-icon text-danger" onclick="askDelete('paiements','${p.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>` : ''}</td>
    </tr>`;
  }).join('') : `<tr><td colspan="7"><div class="empty-state"><i class="bi bi-receipt"></i><p>Aucun versement</p></div></td></tr>`;
}
document.getElementById('searchHistoriquePeriode').addEventListener('input', renderHistoriquePeriode);
document.getElementById('filterFiliereHistoriquePeriode').addEventListener('change', renderHistoriquePeriode);
document.getElementById('filterHistoriquePeriodeDateDebut').addEventListener('change', renderHistoriquePeriode);
document.getElementById('filterHistoriquePeriodeDateFin').addEventListener('change', renderHistoriquePeriode);
document.getElementById('btnResetFilterHistoriquePeriode').addEventListener('click', ()=>{
  document.getElementById('searchHistoriquePeriode').value = '';
  document.getElementById('filterFiliereHistoriquePeriode').value = '';
  document.getElementById('filterHistoriquePeriodeDateDebut').value = '';
  document.getElementById('filterHistoriquePeriodeDateFin').value = '';
  renderHistoriquePeriode();
});
async function exportHistoriquePeriodePdf(){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const list = filteredHistoriquePeriode().slice().sort((a,b)=> new Date(a.date)-new Date(b.date));
  const total = list.reduce((s,p)=>s+Number(p.montant),0);
  pdfHeader(doc, 'Historique des paiements', `${list.length} versement(s)`, font);
  doc.autoTable({
    startY: 50,
    head: [['Date','Étudiant','Filière','Montant','Mode','Type']],
    body: list.map(p=>{
      const e = getEtudiant(p.etudiantId);
      return [fmtDate(p.date), e?nomComplet(e):'—', e?getFiliere(e.filiereId)?.nom||'—':'—', fmtCFA(p.montant), p.mode||'—', p.type||'—'];
    }),
    foot: [['','','Total', fmtCFA(total), '', '']],
    styles:{font},
    headStyles:{fillColor:[22,35,63], textColor:255, fontSize:9, font},
    bodyStyles:{fontSize:8.5, font},
    alternateRowStyles:{fillColor:[245,246,248]},
    footStyles:{fillColor:[240,240,240], textColor:[20,20,20], fontStyle:'bold', font},
  });
  pdfFooter(doc, font);
  doc.save('historique-paiements-anadence.pdf');
}
document.getElementById('btnExportHistoriquePeriodePdf').addEventListener('click', exportHistoriquePeriodePdf);

async function exportRapportPdf(id, etudiantId){
  const r = DB.rapports.find(x=>x.id===id);
  if(!r) return;
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const participants = r.participants||[];
  if(etudiantId){
    // Export du rapport d'un seul étudiant participant au chantier
    const p = getParticipant(r, etudiantId);
    if(!p) return;
    const M = 14, W = 182;
    pdfHeader(doc, 'Rapport de chantier / séance pratique', r.titre, font);
    const st = participantStatus(r, p);
    let y = pdfSection(doc, M, 50, W, 'Informations générales', [
      ['Filière', getFiliere(r.filiereId)?.nom||'—'],
      ['Formateur encadrant / responsable de chantier', r.formateurNom || nomComplet(getFormateur(r.formateurId))],
      ['Étudiant', nomComplet(getEtudiant(etudiantId))],
      ['Période', fmtPeriodeRapport(r)],
      ['Lieu / chantier', r.lieu||'—'],
      ['Participation', p.participation==='oui' ? 'A participé' : ('N\'a pas participé'+(p.motif?` (motif : ${p.motif})`:' (sans motif)'))],
      ['Statut / note', st.label],
    ], font) + 6;
    if(p.lockReason==='valide' && Array.isArray(p.appreciationsDetail) && p.appreciationsDetail.length){
      doc.autoTable({
        startY: y,
        head: [['Appréciations du responsable','Niveau']],
        body: p.appreciationsDetail.map(a=>[a.critere, APPRECIATION_LABELS[a.niveau]||a.niveau]),
        styles:{font, fontSize:9},
        headStyles:{fillColor:[22,35,63], textColor:255, font},
        bodyStyles:{font},
      });
      y = doc.lastAutoTable.finalY + 8;
    }
    const addBlock = (titre, texte) => {
      doc.setFont(font,'bold'); doc.setFontSize(11);
      doc.text(titre, 14, y); y += 6;
      doc.setFont(font,'normal'); doc.setFontSize(9.5);
      const lines = doc.splitTextToSize(texte || 'Néant', 180);
      doc.text(lines, 14, y); y += lines.length*5 + 8;
    };
    addBlock('Description des travaux réalisés', p.description);
    addBlock('Incidents / observations', p.incidents);
    addBlock('Recommandations', p.recommandations);
    if(p.appreciationRapport) addBlock('Commentaire du responsable', p.appreciationRapport);
    pdfFooter(doc, font);
    doc.save(`rapport-chantier-${(r.titre||'sans-titre').toLowerCase().replace(/[^a-z0-9]+/g,'-').slice(0,40)}-${(nomComplet(getEtudiant(etudiantId))||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').slice(0,30)}.pdf`);
    return;
  }
  // Export récapitulatif de tous les participants du chantier
  const M2 = 14, W2 = 182;
  pdfHeader(doc, 'Rapport de chantier / séance pratique', r.titre, font);
  const yRecap = pdfSection(doc, M2, 50, W2, 'Informations générales', [
    ['Filière', getFiliere(r.filiereId)?.nom||'—'],
    ['Formateur encadrant / responsable de chantier', r.formateurNom || nomComplet(getFormateur(r.formateurId))],
    ['Période', fmtPeriodeRapport(r)],
    ['Lieu / chantier', r.lieu||'—'],
    ['Nombre de participants', participants.length],
  ], font) + 6;
  doc.autoTable({
    startY: yRecap,
    head: [['Étudiant','Participation','Statut / Note']],
    body: participants.map(p=>[
      nomComplet(getEtudiant(p.etudiantId)),
      p.participation==='oui' ? 'Oui' : ('Non'+(p.motif?` (motif : ${p.motif})`:' (sans motif)')),
      participantStatus(r,p).label,
    ]),
    styles:{font, fontSize:9},
    headStyles:{fillColor:[22,35,63], textColor:255, font},
    bodyStyles:{font},
  });
  pdfFooter(doc, font);
  doc.save(`rapport-chantier-${(r.titre||'sans-titre').toLowerCase().replace(/[^a-z0-9]+/g,'-').slice(0,40)}.pdf`);
}

/* ---------- Persistence (Firebase Firestore) ---------- */
async function loadDB(){
  let snap;
  try{
    snap = await dbDocRef.get();
  }catch(e){
    // IMPORTANT : en cas d'erreur de connexion (réseau coupé, règles de sécurité Firestore expirées,
    // quota dépassé, etc.), on NE DOIT JAMAIS continuer avec une base vide, car l'étape suivante
    // (seedData() + saveDB()) écraserait alors définitivement les vraies données par la base de
    // démonstration. On bloque donc l'application avec un message clair plutôt que de risquer une perte
    // de données silencieuse.
    console.error('Erreur de connexion à Firebase', e);
    showDbErrorOverlay();
    throw e;
  }
  if(snap.exists){
    DB = snap.data().payload ? JSON.parse(snap.data().payload) : snap.data();
    migrateDB();
    return;
  }
  // Le document Firestore n'existe vraiment pas (toute première utilisation de l'application,
  // confirmée par une lecture réussie) : on initialise avec la base de démonstration.
  DB = seedData();
  migrateDB();
  await saveDB();
}
function showDbErrorOverlay(){
  const el = document.getElementById('dbErrorOverlay');
  if(el) el.style.display = 'flex';
}
function migrateDB(){
  // Ajoute les nouvelles collections aux bases déjà sauvegardées (versions précédentes)
  if(!DB.presences) DB.presences = [];
  if(!DB.documents) DB.documents = [];
  if(!DB.annonces) DB.annonces = [];
  if(!DB.messages) DB.messages = [];
  if(!DB.leads) DB.leads = [];
  if(!DB.modules) DB.modules = [];
  if(!DB.galerie) DB.galerie = [];
  if(!DB.parametres) DB.parametres = { logo:'img/logo.png' };
  // Migration : les anciennes bases avaient un formateur unique par filière (filiere.formateurId).
  // On convertit ce lien en un module par défaut, pour ne pas perdre l'information existante.
  if(DB.modules.length===0){
    (DB.filieres||[]).forEach(f=>{
      if(f.formateurId){
        DB.modules.push({id:uid(), nom:'Module principal', filiereId:f.id, formateurId:f.formateurId, description:''});
      }
    });
  }
  (DB.etudiants||[]).forEach(e=>{
    if(!e.moduleIds) e.moduleIds = [];
  });
  // Ajoute les autorisations par défaut et les liens formateur/étudiant aux comptes existants
  (DB.users||[]).forEach(u=>{
    if(!u.perms) u.perms = defaultPermsForRole(u.role);
    if(u.role==='formateur' && !u.formateurId){
      const match = DB.formateurs.find(f=> nomComplet(f).toLowerCase()===String(u.nom).toLowerCase());
      if(match) u.formateurId = match.id;
    }
    if(u.role==='etudiant' && !u.etudiantId){
      const match = DB.etudiants.find(e=> nomComplet(e).toLowerCase()===String(u.nom).toLowerCase());
      if(match) u.etudiantId = match.id;
    }
  });
  (DB.etudiants||[]).forEach(e=>{
    if(e.nomTuteur===undefined) e.nomTuteur='';
    if(e.telephoneTuteur===undefined) e.telephoneTuteur='';
    if(e.lienTuteur===undefined) e.lienTuteur='Parent';
    if(!e.echeancier) e.echeancier = []; // échéancier de paiement propre à chaque étudiant
  });
  (DB.presences||[]).forEach(p=>{
    if(p.motif===undefined) p.motif='';
  });
}
async function saveDB(){
  try{ await dbDocRef.set({ payload: JSON.stringify(DB), updatedAt: firebase.firestore.FieldValue.serverTimestamp() }); }
  catch(e){ console.error('Erreur de sauvegarde Firebase', e); toast("Échec de l'enregistrement sur Firebase"); }
}

function seedData(){
  const filiereIds = {elec: uid(), info: uid(), couture: uid(), plomberie: uid()};
  const formateurIds = {f1: uid(), f2: uid(), f3: uid()};
  const filieres = [
    {id:filiereIds.elec, nom:'Électricité Bâtiment', duree:'9 mois', prixTotal:350000, description:"Installation électrique domestique et industrielle.", debouches:"Électricien installateur, technicien de maintenance, chef d'équipe chantier, auto-entrepreneur en installation électrique."},
    {id:filiereIds.info, nom:'Informatique de Gestion', duree:'6 mois', prixTotal:250000, description:"Bureautique, réseaux, maintenance PC.", debouches:"Agent de saisie, assistant administratif, technicien de maintenance informatique, gérant de cybercentre."},
    {id:filiereIds.couture, nom:'Couture & Stylisme', duree:'12 mois', prixTotal:200000, description:"Coupe, couture, création de modèles.", debouches:"Couturier(ère), styliste-modéliste, chef d'atelier, création de sa propre marque."},
    {id:filiereIds.plomberie, nom:'Plomberie Sanitaire', duree:'6 mois', prixTotal:220000, description:"Installation et dépannage sanitaire.", debouches:"Plombier installateur, technicien de dépannage sanitaire, chef de chantier, auto-entrepreneur."},
  ];
  const formateurs = [
    {id:formateurIds.f1, nom:'HOUNSOU', prenom:'Adjovi', specialite:'Électricité / Plomberie', telephone:'97 12 34 56', email:'a.hounsou@anadence.bj'},
    {id:formateurIds.f2, nom:'DOSSOU', prenom:'Kokou', specialite:'Informatique', telephone:'96 45 67 89', email:'k.dossou@anadence.bj'},
    {id:formateurIds.f3, nom:'AGBODJAN', prenom:'Rose', specialite:'Couture', telephone:'95 78 90 12', email:'r.agbodjan@anadence.bj'},
  ];
  // Une filière peut avoir plusieurs modules ; un formateur peut être associé à plusieurs modules
  // (ici Adjovi HOUNSOU intervient à la fois en Électricité et en Plomberie).
  const modId = {elecCab:uid(), elecSec:uid(), infoBur:uid(), infoRes:uid(), coutCoupe:uid(), coutModele:uid(), plombInstall:uid()};
  const modules = [
    {id:modId.elecCab, nom:'Câblage domestique', filiereId:filiereIds.elec, formateurId:formateurIds.f1, description:"Installation et câblage des circuits domestiques."},
    {id:modId.elecSec, nom:'Normes de sécurité électrique', filiereId:filiereIds.elec, formateurId:formateurIds.f1, description:"Sécurité et prévention des risques électriques."},
    {id:modId.infoBur, nom:'Bureautique', filiereId:filiereIds.info, formateurId:formateurIds.f2, description:"Word, Excel, PowerPoint."},
    {id:modId.infoRes, nom:'Réseaux informatiques', filiereId:filiereIds.info, formateurId:formateurIds.f2, description:"Bases des réseaux et maintenance PC."},
    {id:modId.coutCoupe, nom:'Coupe de base', filiereId:filiereIds.couture, formateurId:formateurIds.f3, description:"Prise de mesures et patronage."},
    {id:modId.coutModele, nom:'Création de modèles', filiereId:filiereIds.couture, formateurId:formateurIds.f3, description:"Conception de modèles originaux."},
    {id:modId.plombInstall, nom:'Installation sanitaire', filiereId:filiereIds.plomberie, formateurId:formateurIds.f1, description:"Installation et dépannage sanitaire."},
  ];
  let seedOrdreMatricule = 0;
  const etu = (nom,prenom,sexe,fil,modIds,statut='actif') => { const ordre = ++seedOrdreMatricule; return {id:uid(),ordre,matricule:`${String(ordre).padStart(3,'0')}CF0226`,nom,prenom,sexe,dateNaissance:'2002-03-14',dateInscription:'2026-02-10',telephone:'01'+Math.floor(10000000+Math.random()*89999999),email:prenom.toLowerCase()+'.'+nom.toLowerCase()+'@mail.com',adresse:'Cotonou',filiereId:fil,statut,moduleIds:modIds||[],nomTuteur:'Parent de '+prenom,telephoneTuteur:'01'+Math.floor(10000000+Math.random()*89999999),lienTuteur:'Parent'}; };
  const etudiants = [
    // Chantal suit les deux modules de sa filière
    etu('ALAPINI','Chantal','F',filiereIds.elec,[modId.elecCab, modId.elecSec]),
    // Marius ne s'est inscrit qu'au module Bureautique, pas à Réseaux informatiques
    etu('ZINSOU','Marius','M',filiereIds.info,[modId.infoBur]),
    etu('SOSSOU','Bernadette','F',filiereIds.couture,[modId.coutCoupe, modId.coutModele]),
    etu('AGOSSOU','Fabrice','M',filiereIds.plomberie,[modId.plombInstall]),
    // Sandrine ne suit pour l'instant que Réseaux informatiques
    etu('KOUDJO','Sandrine','F',filiereIds.info,[modId.infoRes]),
    etu('TOSSOU','Éric','M',filiereIds.elec,[modId.elecCab, modId.elecSec],'diplome'),
  ];
  const paiements = [
    {id:uid(), etudiantId:etudiants[0].id, montant:150000, date:'2026-02-12', mode:'Mobile Money', type:"Frais d'inscription"},
    {id:uid(), etudiantId:etudiants[0].id, montant:100000, date:'2026-04-02', mode:'Espèces', type:'Tranche 1'},
    {id:uid(), etudiantId:etudiants[1].id, montant:250000, date:'2026-02-15', mode:'Virement bancaire', type:'Solde'},
    {id:uid(), etudiantId:etudiants[2].id, montant:50000, date:'2026-03-01', mode:'Espèces', type:"Frais d'inscription"},
    {id:uid(), etudiantId:etudiants[4].id, montant:100000, date:'2026-03-20', mode:'Mobile Money', type:"Frais d'inscription"},
  ];
  const evaluations = [
    {id:uid(), etudiantId:etudiants[0].id, filiereId:filiereIds.elec, module:'Câblage domestique', formateurId:formateurIds.f1, note:15, appreciation:'Bon niveau pratique', date:'2026-05-10'},
    {id:uid(), etudiantId:etudiants[1].id, filiereId:filiereIds.info, module:'Réseaux informatiques', formateurId:formateurIds.f2, note:12.5, appreciation:'Peut mieux faire', date:'2026-05-11'},
    {id:uid(), etudiantId:etudiants[2].id, filiereId:filiereIds.couture, module:'Coupe de base', formateurId:formateurIds.f3, note:17, appreciation:'Excellent travail', date:'2026-05-12'},
  ];
  const rapports = [
    (()=>{
      const r = {
        id:uid(), titre:'Installation tableau électrique — Atelier', filiereId:filiereIds.elec,
        formateurNom:'Adjovi HOUNSOU', formateurId:formateurIds.f1,
        dateDebut:'2026-05-15', dateFin:'2026-05-16', lieu:'Atelier ANADENCE CITY, Cotonou',
        auteurId:'', auteurNom:'Adjovi HOUNSOU', dateCreation:'2026-05-15T08:00:00.000Z',
        participants: [ creerParticipant(etudiants[0].id, 'oui', '') ],
      };
      const p = r.participants[0];
      p.soumis = true;
      p.dateSoumission = '2026-05-16';
      p.description = "Montage et câblage d'un tableau électrique domestique par groupes de 2.";
      p.incidents = "Aucun incident majeur.";
      p.recommandations = "Prévoir plus de disjoncteurs pour la prochaine session.";
      return r;
    })(),
  ];
  const users = [
    {id:uid(), nom:'Directeur Général', role:'direction', identifiant:'direction', motDePasse:'direction123', perms:defaultPermsForRole('direction')},
    {id:uid(), nom:'Secrétariat Académique', role:'secretariat', identifiant:'secretariat', motDePasse:'secret123', perms:defaultPermsForRole('secretariat')},
    {id:uid(), nom:'Service Comptabilité', role:'comptabilite', identifiant:'comptabilite', motDePasse:'compta123', perms:defaultPermsForRole('comptabilite')},
    {id:uid(), nom:'Adjovi HOUNSOU', role:'formateur', identifiant:'a.hounsou', motDePasse:'formateur123', formateurId:formateurIds.f1, perms:defaultPermsForRole('formateur')},
    {id:uid(), nom:'Chantal ALAPINI', role:'etudiant', identifiant:'c.alapini', motDePasse:'etudiant123', etudiantId:etudiants[0].id, perms:defaultPermsForRole('etudiant')},
  ];
  return {filieres, modules, formateurs, etudiants, paiements, evaluations, rapports, users, leads:[], presences:[], documents:[], galerie:[], parametres:{logo:'img/logo.png'}, annonces:[
    {id:uid(), titre:'Reprise des cours après les fêtes', contenu:"Les cours reprennent normalement le 5 janvier 2027 pour toutes les filières. Merci de vous présenter à l'heure.", auteur:'Direction Générale', date:'2026-12-20'}
  ], messages:[]};
}

/* ---------- Site public ---------- */
const SERVICES = [
  {id:'srv-formations', icon:'bi-mortarboard-fill', titre:'Formations qualifiantes', desc:"Des cursus pratiques et théoriques dans nos différentes filières, sanctionnés par une attestation de fin de formation.", detail:"Nos formations qualifiantes combinent cours théoriques et mise en pratique intensive, dans des groupes à taille humaine. Chaque filière est conçue avec des professionnels du secteur pour coller aux besoins réels du marché de l'emploi, et se termine par une attestation de fin de formation reconnue par le centre.", seed:'anadence-srv-formations'},
  {id:'srv-ateliers', icon:'bi-tools', titre:'Ateliers & chantiers école', desc:"Mise en pratique sur des chantiers réels et en atelier, encadrée par des formateurs expérimentés.", detail:"Dès les premières semaines, les apprenants mettent la main à la pâte : ateliers équipés et chantiers-écoles permettent de travailler sur des cas concrets, sous la supervision constante de formateurs expérimentés, pour être opérationnel dès la sortie du centre.", seed:'anadence-srv-ateliers'},
  {id:'srv-insertion', icon:'bi-briefcase-fill', titre:"Accompagnement à l'insertion", desc:"Aide à la recherche de stage et d'emploi, mise en relation avec des entreprises partenaires.", detail:"Le centre accompagne chaque étudiant dans la recherche de stage puis d'emploi : préparation aux entretiens, aide à la rédaction de CV, et mise en relation avec un réseau d'entreprises partenaires dans chacune des filières.", seed:'anadence-srv-insertion'},
  {id:'srv-certification', icon:'bi-award-fill', titre:'Certification', desc:"Délivrance d'attestations et de certificats reconnus à l'issue de chaque filière.", detail:"À l'issue de chaque filière, une évaluation finale permet de délivrer une attestation ou un certificat de fin de formation, valorisant les compétences acquises auprès des employeurs et partenaires du centre.", seed:'anadence-srv-certification'},
  {id:'srv-orientation', icon:'bi-person-lines-fill', titre:'Orientation & conseil', desc:"Un accompagnement personnalisé pour choisir la filière adaptée à votre projet professionnel.", detail:"Avant même l'inscription, notre équipe reçoit chaque candidat pour un entretien d'orientation : bilan des centres d'intérêt, des aptitudes et du projet professionnel, afin de l'orienter vers la filière la plus adaptée.", seed:'anadence-srv-orientation'},
  {id:'srv-continue', icon:'bi-arrow-repeat', titre:'Formation continue', desc:"Des modules courts pour les professionnels souhaitant se perfectionner ou se reconvertir.", detail:"Pour les professionnels déjà en activité, le centre propose des modules courts de perfectionnement ou de reconversion, organisés en horaires aménagés pour rester compatibles avec une activité professionnelle.", seed:'anadence-srv-continue'},
];
const BLOG_POSTS = [
  {id:'blog-1', titre:'Rentrée 2026 : ouverture des inscriptions', date:'2026-08-05', seed:'anadence-blog-rentree', excerpt:"Les inscriptions pour la nouvelle année de formation sont ouvertes dans toutes nos filières.", contenu:"Les inscriptions pour la nouvelle année de formation sont officiellement ouvertes dans toutes nos filières : Électricité Bâtiment, Informatique de Gestion, Couture & Stylisme et Plomberie Sanitaire.\n\nLes places étant limitées dans chaque atelier, nous invitons les candidats à se présenter au secrétariat ou à remplir le formulaire de contact du site pour être recontactés rapidement."},
  {id:'blog-2', titre:'Portes ouvertes : découvrez nos ateliers', date:'2026-07-18', seed:'anadence-blog-portes-ouvertes', excerpt:"Une journée portes ouvertes pour visiter nos ateliers et échanger avec nos formateurs.", contenu:"Le centre a organisé une journée portes ouvertes permettant aux futurs apprenants et à leurs familles de visiter les ateliers, d'échanger directement avec les formateurs et de découvrir le matériel utilisé pendant les formations.\n\nUn moment convivial qui a permis à de nombreux visiteurs de mieux cerner leur projet professionnel avant de s'inscrire."},
  {id:'blog-3', titre:'Nos étudiants en couture exposent leurs créations', date:'2026-06-22', seed:'anadence-blog-couture', excerpt:"Les apprenants de la filière Couture & Stylisme ont présenté leurs réalisations lors d'un défilé.", contenu:"Les apprenants de la filière Couture & Stylisme ont présenté leurs réalisations lors d'un petit défilé organisé dans l'enceinte du centre, en présence de la direction et de plusieurs partenaires.\n\nCet évènement annuel valorise le travail réalisé tout au long de l'année et permet aux étudiants de gagner en confiance avant leur entrée sur le marché du travail."},
];
function fallbackFlyer(seed){ return `https://picsum.photos/seed/${encodeURIComponent(seed)}/640/480`; }
const GALERIE = [
  {seed:'anadence-elec', legende:'Atelier électricité bâtiment'},
  {seed:'anadence-info', legende:'Salle informatique de gestion'},
  {seed:'anadence-couture', legende:'Atelier couture & stylisme'},
  {seed:'anadence-plomberie', legende:'Chantier école plomberie'},
  {seed:'anadence-diplome', legende:'Remise des attestations'},
  {seed:'anadence-campus', legende:'Le campus ANADENCE CITY'},
];
function renderPublicSite(){
  document.getElementById('servicesGrid').innerHTML = SERVICES.map(s=>`
    <div class="col-md-6 col-lg-4">
      <div class="flyer-card">
        <div class="flyer-img-wrap">
          <img src="${fallbackFlyer(s.seed)}" alt="${s.titre}" loading="lazy">
          <span class="flyer-badge"><i class="bi ${s.icon} me-1"></i>Service</span>
        </div>
        <div class="flyer-body">
          <div class="flyer-title">${s.titre}</div>
          <div class="flyer-desc">${s.desc}</div>
          <button type="button" class="btn btn-outline-secondary btn-sm mt-auto align-self-start" onclick="showServiceDetail('${s.id}')">Voir détails <i class="bi bi-arrow-right ms-1"></i></button>
        </div>
      </div>
    </div>`).join('');
  const galerieStatique = GALERIE.map(g=>`
    <div class="col-md-4 col-6">
      <div class="gallery-item">
        <img src="https://picsum.photos/seed/${g.seed}/500/380" alt="${g.legende}" loading="lazy">
        <div class="caption">${g.legende}</div>
      </div>
    </div>`).join('');
  const galerieMembres = (DB.galerie||[]).slice().reverse().map(g=>`
    <div class="col-md-4 col-6">
      <div class="gallery-item">
        <img src="${g.dataUrl}" alt="${g.legende||''}" loading="lazy">
        <div class="caption">${g.legende||''}</div>
      </div>
    </div>`).join('');
  document.getElementById('galerieGrid').innerHTML = galerieStatique + galerieMembres;
  document.getElementById('visitorFilieresGrid').innerHTML = DB.filieres.map(f=>`
    <div class="col-md-6 col-lg-3">
      <div class="flyer-card">
        <div class="flyer-img-wrap">
          <img src="${f.flyer || fallbackFlyer('anadence-fil-'+f.id)}" alt="${f.nom}" loading="lazy">
          <span class="flyer-badge"><i class="bi bi-mortarboard-fill me-1"></i>Formation</span>
        </div>
        <div class="flyer-body">
          <div class="flyer-title">${f.nom}</div>
          <div class="flyer-meta">
            <span class="badge text-bg-light border"><i class="bi bi-clock-history me-1"></i>${f.duree||'—'}</span>
            <span class="badge text-bg-light border"><i class="bi bi-cash-coin me-1"></i>${fmtCFA(f.prixTotal)}</span>
          </div>
          <div class="flyer-desc">${f.description||''}</div>
          <button type="button" class="btn btn-amber btn-sm mt-auto align-self-start" onclick="showFiliereDetail('${f.id}')">Voir détails <i class="bi bi-arrow-right ms-1"></i></button>
        </div>
      </div>
    </div>`).join('');
  document.getElementById('visitorLeadFiliere').innerHTML = DB.filieres.map(f=>`<option value="${f.id}">${f.nom}</option>`).join('');
  document.getElementById('blogGrid').innerHTML = BLOG_POSTS.map(b=>`
    <div class="col-md-6 col-lg-4">
      <div class="blog-card">
        <div class="blog-img-wrap"><img src="${fallbackFlyer(b.seed)}" alt="${b.titre}" loading="lazy"></div>
        <div class="blog-body">
          <div class="blog-date"><i class="bi bi-calendar-event me-1"></i>${fmtDate(b.date)}</div>
          <div class="blog-title">${b.titre}</div>
          <div class="blog-excerpt">${b.excerpt}</div>
          <button type="button" class="btn btn-outline-secondary btn-sm mt-auto align-self-start" onclick="showBlogDetail('${b.id}')">Lire la suite <i class="bi bi-arrow-right ms-1"></i></button>
        </div>
      </div>
    </div>`).join('');
}
function showFiliereDetail(id){
  const f = getFiliere(id);
  if(!f) return;
  document.getElementById('filiereDetailTitle').textContent = f.nom;
  document.getElementById('filiereDetailImg').src = f.flyer || fallbackFlyer('anadence-fil-'+f.id);
  document.getElementById('filiereDetailBadges').innerHTML = `
    <span class="badge text-bg-light border"><i class="bi bi-clock-history me-1"></i>${f.duree||'—'}</span>
    <span class="badge text-bg-light border"><i class="bi bi-cash-coin me-1"></i>${fmtCFA(f.prixTotal)}</span>`;
  document.getElementById('filiereDetailDesc').textContent = f.description || 'Aucune description disponible pour le moment.';
  document.getElementById('filiereDetailDebouches').textContent = f.debouches || 'Aucun débouché renseigné pour le moment.';
  document.getElementById('btnFiliereDetailInscrire').onclick = ()=>{
    bootstrap.Modal.getInstance(document.getElementById('modalFiliereDetail')).hide();
    document.getElementById('visitorLeadFiliere').value = f.id;
    document.getElementById('public-contact').scrollIntoView({behavior:'smooth'});
  };
  new bootstrap.Modal(document.getElementById('modalFiliereDetail')).show();
}
function showServiceDetail(id){
  const s = SERVICES.find(x=>x.id===id);
  if(!s) return;
  document.getElementById('serviceDetailTitle').textContent = s.titre;
  document.getElementById('serviceDetailImg').src = fallbackFlyer(s.seed);
  document.getElementById('serviceDetailDesc').textContent = s.detail || s.desc;
  new bootstrap.Modal(document.getElementById('modalServiceDetail')).show();
}
function showBlogDetail(id){
  const b = BLOG_POSTS.find(x=>x.id===id);
  if(!b) return;
  document.getElementById('blogDetailTitle').textContent = b.titre;
  document.getElementById('blogDetailImg').src = fallbackFlyer(b.seed);
  document.getElementById('blogDetailDate').innerHTML = `<i class="bi bi-calendar-event me-1"></i>${fmtDate(b.date)}`;
  document.getElementById('blogDetailContent').textContent = b.contenu || b.excerpt;
  new bootstrap.Modal(document.getElementById('modalBlogDetail')).show();
}
document.getElementById('formVisitorLead').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.id = uid(); data.date = new Date().toISOString();
  DB.leads.push(data);
  await saveDB();
  e.target.reset();
  toast("Votre demande a été envoyée. Nous vous recontactons sous 48h.");
});

/* ---------- Connexion ---------- */
document.getElementById('btnOpenLogin').addEventListener('click', ()=>{
  document.getElementById('formLogin').reset();
  document.getElementById('loginError').style.display='none';
  new bootstrap.Modal(document.getElementById('modalLogin')).show();
});
/* Menu latéral mobile du site public : ferme le menu puis exécute l'action choisie (défilement ou connexion) */
(function(){
  const offcanvasEl = document.getElementById('publicOffcanvasMenu');
  const offcanvas = bootstrap.Offcanvas.getOrCreateInstance(offcanvasEl);
  let pendingAction = null;
  document.querySelectorAll('#publicOffcanvasLinks .public-offcanvas-link').forEach(link=>{
    link.addEventListener('click', e=>{
      e.preventDefault();
      const targetSection = link.getAttribute('href');
      pendingAction = ()=>{
        const el = document.querySelector(targetSection);
        if(el) el.scrollIntoView({behavior:'smooth'});
      };
      offcanvas.hide();
    });
  });
  document.getElementById('btnOpenLoginOffcanvas').addEventListener('click', ()=>{
    pendingAction = ()=>{
      document.getElementById('formLogin').reset();
      document.getElementById('loginError').style.display='none';
      new bootstrap.Modal(document.getElementById('modalLogin')).show();
    };
    offcanvas.hide();
  });
  offcanvasEl.addEventListener('hidden.bs.offcanvas', ()=>{
    if(pendingAction){ const action = pendingAction; pendingAction = null; action(); }
  });
})();
document.getElementById('formLogin').addEventListener('submit', e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const identifiant = data.identifiant.trim().toLowerCase();
  const match = DB.users.find(u => (u.identifiant||'').toLowerCase()===identifiant && u.motDePasse===data.motDePasse);
  if(!match){
    document.getElementById('loginError').style.display='block';
    return;
  }
  bootstrap.Modal.getInstance(document.getElementById('modalLogin')).hide();
  enterApp(match);
});

function enterApp(user, skipSave){
  // Enregistre la date/heure de cette connexion (visible par la direction dans Comptes & rôles),
  // que ce soit une connexion explicite via le formulaire ou une reprise de session déjà ouverte.
  user.derniereConnexion = new Date().toISOString();
  saveDB();
  state.role = user.role;
  state.userName = user.nom;
  state.userId = user.id;
  if(!skipSave){
    try{ localStorage.setItem('anadenceSessionUserId', user.id); }catch(e){}
  }
  document.getElementById('publicSite').style.display='none';
  document.getElementById('appShell').style.display='block';
  const roleObj = ROLES.find(r=>r.id===state.role);
  const nameParts = String(state.userName||'').trim().split(/\s+/);
  const userInitials = initials(nameParts[0], nameParts.length>1 ? nameParts[nameParts.length-1] : '');
  document.getElementById('sideAvatar').textContent = userInitials;
  document.getElementById('topAvatar').textContent = userInitials;
  document.getElementById('sideAvatarMobile').textContent = userInitials;
  document.getElementById('sideUserName').textContent = state.userName;
  document.getElementById('sideUserNameMobile').textContent = state.userName;
  ['sideRoleBadge','topRoleBadge','sideRoleBadgeMobile'].forEach(id=>{
    const el = document.getElementById(id);
    el.textContent = roleObj ? roleObj.label : state.role;
    el.className = 'role-badge rb-'+state.role;
  });
  renderNav();
  populateAllSelects();
  // Le formateur ne gère que les étudiants actifs : les filtres Abandon/Diplômé n'ont pas de sens pour lui
  const optAbandon = document.getElementById('optAbandonEtudiant');
  const optDiplome = document.getElementById('optDiplomeEtudiant');
  if(optAbandon) optAbandon.style.display = state.role==='formateur' ? 'none' : '';
  if(optDiplome) optDiplome.style.display = state.role==='formateur' ? 'none' : '';
  // Par défaut, on n'affiche que les étudiants actifs (abandon/diplômé accessibles via les boutons dédiés)
  etudiantStatutFilter = 'actif';
  document.querySelectorAll('#filterStatutEtudiantGroup [data-statut]').forEach(b=>b.classList.toggle('active', b.dataset.statut==='actif'));
  checkBackupReminder();
  goSection('dashboard');
}

function logoutUser(){
  const oc = bootstrap.Offcanvas.getInstance(document.getElementById('offcanvasSidebar'));
  if(oc) oc.hide();
  document.getElementById('appShell').style.display='none';
  document.getElementById('publicSite').style.display='block';
  state.role = null; state.userName = '';
  try{ localStorage.removeItem('anadenceSessionUserId'); }catch(e){}
}
document.getElementById('btnLogout').addEventListener('click', logoutUser);
document.getElementById('btnLogoutMobile').addEventListener('click', logoutUser);

/* Empêche la fermeture des fenêtres modales en cliquant en dehors (fond) :
   seule une action explicite (Fermer / Annuler / croix) ferme la fenêtre. */
document.querySelectorAll('.modal').forEach(m=>{
  m.setAttribute('data-bs-backdrop','static');
});

/* ---------- Navigation ---------- */
// Nombre de chantiers pour lesquels le formateur/la direction a demandé une correction à l'étudiant connecté.
function countRapportsCorrectionEtudiant(){
  if(state.role!=='etudiant' || !DB || !DB.rapports) return 0;
  const u = currentUser();
  if(!u) return 0;
  return DB.rapports.reduce((n,r)=>{
    const p = getParticipant(r, u.etudiantId);
    return n + (p && p.correctionDemandee ? 1 : 0);
  }, 0);
}
function renderNav(){
  const items = NAV.filter(n=> n.section==='dashboard' ? true : n.section==='parametres' ? state.role==='direction' : n.section==='monprofil' ? (state.role==='formateur'||state.role==='etudiant') : hasPerm(n.section,'view'));
  const html = `<div class="nav-section-title">Menu</div>` + items.map(n=>{
    const corrCount = n.section==='rapports' ? countRapportsCorrectionEtudiant() : 0;
    const badge = corrCount>0 ? `<span class="badge bg-danger rounded-pill ms-auto">${corrCount}</span>` : '';
    return `<a href="#" class="side-link" data-section="${n.section}"><i class="bi ${n.icon}"></i> ${n.label}${badge}</a>`;
  }).join('');
  document.getElementById('navContainer').innerHTML = html;
  document.getElementById('navContainerMobile').innerHTML = html;
  document.querySelectorAll('[data-section]').forEach(a=>{
    a.addEventListener('click', e=>{ e.preventDefault(); goSection(a.dataset.section); });
  });
}
function goSection(section){
  state.section = section;
  document.querySelectorAll('.section-panel').forEach(p=>p.classList.remove('active'));
  document.getElementById('panel-'+section).classList.add('active');
  document.querySelectorAll('[data-section]').forEach(a=> a.classList.toggle('active', a.dataset.section===section));
  const nav = NAV.find(n=>n.section===section);
  document.getElementById('pageTitle').textContent = nav ? nav.label : '';
  const oc = bootstrap.Offcanvas.getInstance(document.getElementById('offcanvasSidebar'));
  if(oc) oc.hide();
  renderSection(section);
}
function renderSection(section){
  if(section==='dashboard') renderDashboard();
  if(section==='etudiants') renderEtudiants();
  if(section==='filieres') renderFilieres();
  if(section==='formateurs') renderFormateurs();
  if(section==='paiements'){ renderPaiements(); renderHistoriquePeriode(); }
  if(section==='evaluations') renderEvaluations();
  if(section==='rapports') renderRapports();
  if(section==='presences') renderPresences();
  if(section==='documents') renderDocuments();
  if(section==='annonces') renderAnnonces();
  if(section==='messagerie') renderMessagerie();
  if(section==='monprofil') renderMonProfil();
  if(section==='parametres'){ renderUtilisateurs(); renderParametres(); }
}

function canEdit(module){
  return hasPerm(module, 'manage');
}

/* ---------- Selects population ---------- */
function populateAllSelects(){
  const filOpts = scopeFilieres(DB.filieres).map(f=>`<option value="${f.id}">${f.nom}</option>`).join('');
  const modOpts = scopeModules(DB.modules).map(m=>`<option value="${m.id}">${m.nom} — ${getFiliere(m.filiereId)?.nom||''}</option>`).join('');
  const forOpts = DB.formateurs.map(f=>`<option value="${f.id}">${nomComplet(f)}</option>`).join('');
  const etOpts = scopeEtudiants(DB.etudiants).slice().sort((a,b)=>nomComplet(a).localeCompare(nomComplet(b),'fr',{sensitivity:'base'})).map(e=>`<option value="${e.id}">${nomComplet(e)} — ${e.matricule}</option>`).join('');
  const scopedForm = scopedFormateurOptionsHTML();

  document.getElementById('selectFiliereEtudiant').innerHTML = filOpts;
  document.getElementById('selectEtudiantPaiement').innerHTML = etOpts;
  document.getElementById('evalBulkFiliere').innerHTML = filOpts;
  document.getElementById('evalBulkFormateur').innerHTML = scopedForm!==null ? scopedForm : forOpts;
  document.getElementById('selectFiliereRapport').innerHTML = filOpts;
  document.getElementById('visitorLeadFiliere').innerHTML = filOpts;
  document.getElementById('selectEtudiantDocument').innerHTML = etOpts;
  document.getElementById('presenceModule').innerHTML = modOpts;
  document.getElementById('selectMessageDestinataire').innerHTML = DB.users.filter(u=>u.id!==state.userId).map(u=>`<option value="${u.id}">${u.nom} (${ROLES.find(r=>r.id===u.role)?.label||u.role})</option>`).join('');

  const filterFil = document.getElementById('filterFiliereEtudiant');
  filterFil.innerHTML = '<option value="">Toutes les filières</option>'+filOpts;
  const filterFilEval = document.getElementById('filterFiliereEval');
  filterFilEval.innerHTML = '<option value="">Toutes les filières</option>'+filOpts;
  const presenceHistMod = document.getElementById('presenceHistModule');
  presenceHistMod.innerHTML = '<option value="">Tous les modules</option>'+modOpts;
  const filterFilPai = document.getElementById('filterFilierePaiement');
  filterFilPai.innerHTML = '<option value="">Toutes les filières</option>'+filOpts;
  const filterFilHistPeriode = document.getElementById('filterFiliereHistoriquePeriode');
  filterFilHistPeriode.innerHTML = '<option value="">Toutes les filières</option>'+filOpts;
}

/* ---------- DASHBOARD ---------- */
// Notifications de l'étudiant concernant ses rapports de chantier (bandeau rouge en haut du tableau de bord).
function getEtudiantNotifications(){
  if(state.role!=='etudiant' || !DB || !DB.rapports) return [];
  const u = currentUser();
  if(!u) return [];
  const notifs = [];
  DB.rapports.forEach(r=>{
    const p = getParticipant(r, u.etudiantId);
    if(!p || p.participation==='non') return;
    if(p.locked) return; // rapport verrouillé (validé ou expiré) : plus d'action requise
    if(p.correctionDemandee){
      notifs.push({
        icon:'bi-arrow-repeat',
        target:'rapports',
        text:`Correction demandée pour le rapport « ${r.titre} »${p.motifCorrection?' — '+p.motifCorrection:''}`
      });
    } else if(!p.soumis){
      notifs.push({
        icon:'bi-hourglass-split',
        target:'rapports',
        text:`Rapport « ${r.titre} » à compléter — ${deadlineRemainingHTML(r).replace(/<[^>]+>/g,'')}`
      });
    }
  });
  return notifs.concat(getEtudiantPaiementNotifications(), getAnnonceNotifications(), getMessageNotifications());
}
// Notifications du formateur : annonces internes et messages reçus (mêmes règles que pour l'étudiant).
function getFormateurNotifications(){
  if(state.role!=='formateur') return [];
  return [].concat(getAnnonceNotifications(), getMessageNotifications());
}
// Annonces publiées depuis la dernière visite de l'utilisateur sur le menu Annonces (étudiant ou formateur).
function getAnnonceNotifications(){
  if((state.role!=='etudiant' && state.role!=='formateur') || !DB || !DB.annonces) return [];
  const u = currentUser();
  if(!u) return [];
  const lastSeen = u.lastSeenAnnonces || null;
  const nouvelles = DB.annonces.filter(a=> !lastSeen || new Date(a.date) > new Date(lastSeen));
  if(!nouvelles.length) return [];
  return [{
    icon:'bi-megaphone-fill',
    target:'annonces',
    text: nouvelles.length===1 ? `Nouvelle annonce : « ${nouvelles[0].titre} »` : `${nouvelles.length} nouvelles annonces publiées`
  }];
}
// Messages reçus par l'utilisateur et pas encore lus (étudiant ou formateur).
function getMessageNotifications(){
  if((state.role!=='etudiant' && state.role!=='formateur') || !DB || !DB.messages) return [];
  const nonLus = DB.messages.filter(m=>m.destinataireId===state.userId && !m.lu);
  if(!nonLus.length) return [];
  return [{
    icon:'bi-chat-dots-fill',
    target:'messagerie',
    text: nonLus.length===1 ? `1 nouveau message reçu` : `${nonLus.length} nouveaux messages reçus`
  }];
}
// Rappels de paiement de l'étudiant : une échéance non soldée est signalée dès qu'il reste 30 jours
// ou moins avant sa date limite (et tant qu'elle n'a pas été soldée, y compris si elle est déjà en retard).
function getEtudiantPaiementNotifications(){
  if(state.role!=='etudiant') return [];
  const u = currentUser();
  if(!u || !u.etudiantId) return [];
  const et = getEtudiant(u.etudiantId);
  if(!et || !et.echeancier || !et.echeancier.length) return [];
  return echeancesARappeler(u.etudiantId).map(r=>{
    const delai = r.diffJours<0 ? `en retard de ${Math.abs(r.diffJours)} jour(s)` : r.diffJours===0 ? "échéance aujourd'hui" : `dans ${r.diffJours} jour(s)`;
    return {
      icon: r.statut==='En retard' ? 'bi-exclamation-triangle-fill' : 'bi-alarm-fill',
      target:'paiements',
      text:`Échéance « ${r.libelle} » du ${fmtDate(r.date)} (${delai}) — ${fmtCFA(r.reste)} restant à régler`
    };
  });
}
function renderDashNotifBanner(){
  const el = document.getElementById('dashNotifBanner');
  if(!el) return;
  const notifs = state.role==='formateur' ? getFormateurNotifications() : getEtudiantNotifications();
  if(!notifs.length){ el.style.display='none'; el.innerHTML=''; return; }
  el.style.display='block';
  el.innerHTML = `
    <div class="alert alert-danger mb-3">
      <div class="fw-bold mb-2"><i class="bi bi-bell-fill me-1"></i> Notifications</div>
      <div class="d-flex flex-column gap-2">
        ${notifs.map(n=>`
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span class="small"><i class="bi ${n.icon} me-1"></i>${n.text}</span>
            <button type="button" class="btn btn-sm btn-outline-danger flex-shrink-0" onclick="goSection('${n.target||'rapports'}')"><i class="bi bi-eye"></i> Afficher</button>
          </div>`).join('')}
      </div>
    </div>`;
}
// Même bandeau de rappel de paiement, réaffiché dans le menu Paiement lui-même (pas de bouton, l'étudiant y est déjà).
function renderPaiementNotifBanner(){
  const el = document.getElementById('paiementNotifBanner');
  if(!el) return;
  const notifs = getEtudiantPaiementNotifications();
  if(!notifs.length){ el.style.display='none'; el.innerHTML=''; return; }
  el.style.display='block';
  el.innerHTML = `
    <div class="alert alert-danger mb-3">
      <div class="fw-bold mb-2"><i class="bi bi-bell-fill me-1"></i> Rappel de paiement</div>
      <div class="d-flex flex-column gap-2">
        ${notifs.map(n=>`<span class="small"><i class="bi ${n.icon} me-1"></i>${n.text}</span>`).join('')}
      </div>
    </div>`;
}
let chartFilieresInstance = null;
function renderDashboard(){
  renderDashNotifBanner();
  const dashEtudiants = scopeEtudiants(DB.etudiants);
  const dashFilieres = scopeFilieres(DB.filieres);
  const totalEtudiants = dashEtudiants.filter(e=>e.statut==='actif').length;
  const totalFormateurs = DB.formateurs.length;
  const totalFilieres = dashFilieres.length;
  const finances = dashEtudiants.map(e=>etudiantFinance(e.id));
  const dashEtIds = dashEtudiants.map(e=>e.id);
  const totalCollecte = DB.paiements.filter(p=>dashEtIds.includes(p.etudiantId)).reduce((s,p)=>s+Number(p.montant),0);
  const totalDu = finances.reduce((s,f)=>s+f.total,0);
  const tauxRecouvrement = totalDu>0 ? Math.round((totalCollecte/totalDu)*100) : 0;

  const isFinanceUser = hasPerm('paiements','view') && state.role!=='etudiant'; // vue globale des paiements (direction/comptabilité)
  const isEtudiantFinance = state.role==='etudiant' && hasPerm('paiements','view');

  const cards = [];
  if(state.role!=='etudiant'){
    cards.push(
      {label:'Étudiants actifs', num:totalEtudiants, icon:'bi-people-fill'},
      {label:'Filières', num:totalFilieres, icon:'bi-mortarboard-fill'},
      {label:'Formateurs', num:totalFormateurs, icon:'bi-person-workspace'},
    );
  }
  if(isFinanceUser){
    cards.push({label:'Taux de recouvrement', num:tauxRecouvrement+'%', icon:'bi-graph-up-arrow'});
  }
  document.getElementById('statCards').innerHTML = cards.map(c=>`
    <div class="col-6 col-lg-3">
      <div class="stat-card">
        <div class="stat-icon"><i class="bi ${c.icon}"></i></div>
        <div class="stat-num">${c.num}</div>
        <div class="stat-label">${c.label}</div>
      </div>
    </div>`).join('');

  // chart
  const ctx = document.getElementById('chartFilieres');
  const labels = dashFilieres.map(f=>f.nom);
  const data = dashFilieres.map(f=>dashEtudiants.filter(e=>e.filiereId===f.id).length);
  if(chartFilieresInstance) chartFilieresInstance.destroy();
  chartFilieresInstance = new Chart(ctx, {
    type:'doughnut',
    data:{ labels, datasets:[{ data, backgroundColor:['#16233F','#E8A33D','#2C7873','#8B96B4','#C1443B','#2E4EA6'] }]},
    options:{ maintainAspectRatio:false, plugins:{ legend:{ position:'bottom', labels:{ boxWidth:10, font:{size:10} } } } }
  });

  // panneau latéral : contenu selon le profil (aucune info financière pour le formateur)
  const dashSideCol = document.getElementById('dashSideCol');
  const dashChartCol = document.getElementById('dashChartCol');
  const dashSideTitle = document.getElementById('dashSideTitle');
  const dashSideContent = document.getElementById('dashSideContent');
  // La répartition des étudiants par filière n'est pas pertinente pour un étudiant : on masque la carte.
  const hideFiliereChart = state.role==='etudiant';
  dashChartCol.style.display = hideFiliereChart ? 'none' : '';
  if(isFinanceUser){
    dashSideCol.style.display=''; dashSideCol.className='col-lg-5'; dashChartCol.className='col-lg-7';
    dashSideTitle.textContent = 'Alertes impayés';
    const impayes = dashEtudiants.map(e=>({e, f:etudiantFinance(e.id)})).filter(x=>x.f.reste>0).sort((a,b)=>b.f.reste-a.f.reste).slice(0,6);
    dashSideContent.innerHTML = impayes.length ? impayes.map(x=>`
      <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom:1px solid var(--border);">
        <div>
          <div class="fw-semibold" style="font-size:.85rem;">${nomComplet(x.e)}</div>
          <div class="text-muted" style="font-size:.75rem;">${getFiliere(x.e.filiereId)?.nom||''}</div>
        </div>
        <span class="fw-bold text-danger" style="font-size:.85rem;">${fmtCFA(x.f.reste)}</span>
      </div>`).join('') : `<div class="empty-state py-3"><i class="bi bi-check-circle"></i><p class="mb-0 mt-2">Aucun impayé notable</p></div>`;
  } else if(isEtudiantFinance && dashEtudiants[0]){
    dashSideCol.style.display=''; dashSideCol.className = hideFiliereChart ? 'col-lg-12' : 'col-lg-5'; dashChartCol.className='col-lg-7';
    dashSideTitle.textContent = 'Mon état financier';
    const mine = etudiantFinance(dashEtudiants[0].id);
    dashSideContent.innerHTML = `
      <div class="d-flex justify-content-between py-2" style="border-bottom:1px solid var(--border);"><span class="text-muted small">Montant dû</span><span class="fw-semibold">${fmtCFA(mine.total)}</span></div>
      <div class="d-flex justify-content-between py-2" style="border-bottom:1px solid var(--border);"><span class="text-muted small">Payé</span><span class="fw-semibold text-success">${fmtCFA(mine.paye)}</span></div>
      <div class="d-flex justify-content-between py-2"><span class="text-muted small">Reste à payer</span><span class="fw-semibold text-danger">${fmtCFA(mine.reste)}</span></div>`;
  } else {
    // pas d'accès aux paiements (ex : formateur) : on masque totalement le volet financier
    dashSideCol.style.display='none'; dashChartCol.className='col-lg-12';
  }

  // Ma galerie (étudiant / formateur) : aperçu des photos publiées, visibles également dans la galerie publique
  const dashGalerieRow = document.getElementById('dashGalerieRow');
  if(state.role==='etudiant' || state.role==='formateur'){
    dashGalerieRow.style.display='';
    const mesPhotos = monGaleriePhotos();
    document.getElementById('dashGalerieContent').innerHTML = mesPhotos.length ? mesPhotos.slice(0,8).map(p=>`
      <div class="col-4 col-md-2">
        <img src="${p.dataUrl}" style="width:100%;height:80px;object-fit:cover;border-radius:8px;" alt="">
      </div>`).join('') + `<div class="col-12 mt-1"><a href="#" onclick="goSection('monprofil');return false;" class="small">Gérer mes photos dans « Mon profil » →</a></div>`
      : `<div class="col-12 text-muted small">Vous n'avez pas encore publié de photo. Rendez-vous dans « Mon profil » pour en ajouter.</div>`;
  } else {
    dashGalerieRow.style.display='none';
  }

  // derniers paiements (masqué si pas d'accès aux paiements, et jamais affiché pour l'étudiant)
  const dashPaiementsRow = document.getElementById('dashPaiementsRow');
  if(hasPerm('paiements','view') && state.role!=='etudiant'){
    dashPaiementsRow.style.display='';
    document.getElementById('dashPaiementsTitle').textContent = 'Derniers paiements enregistrés';
    const last = [...DB.paiements].filter(p=>dashEtIds.includes(p.etudiantId)).sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,6);
    document.getElementById('dashPaiementsBody').innerHTML = last.map(p=>{
      const et = getEtudiant(p.etudiantId);
      return `<tr>
        <td>${nomComplet(et)}</td>
        <td class="d-none d-md-table-cell">${getFiliere(et?.filiereId)?.nom||'—'}</td>
        <td class="fw-semibold">${fmtCFA(p.montant)}</td>
        <td class="d-none d-lg-table-cell">${p.mode}</td>
        <td class="d-none d-lg-table-cell">${p.type}</td>
        <td class="d-none d-md-table-cell">${fmtDate(p.date)}</td>
      </tr>`;
    }).join('') || `<tr><td colspan="6" class="text-center text-muted py-3">Aucun paiement enregistré</td></tr>`;
  } else {
    dashPaiementsRow.style.display='none';
  }
}

/* ---------- ETUDIANTS ---------- */
let etudiantStatutFilter = 'actif'; // Par défaut, seuls les étudiants actifs sont affichés
function renderEtudiants(){
  const search = (document.getElementById('searchEtudiant').value||'').toLowerCase();
  const filFilter = document.getElementById('filterFiliereEtudiant').value;
  const statutFilter = etudiantStatutFilter;
  let list = scopeEtudiants(DB.etudiants).filter(e=>{
    const matchSearch = (nomComplet(e)+e.matricule).toLowerCase().includes(search);
    const matchFil = !filFilter || e.filiereId===filFilter;
    const matchStatut = !statutFilter || e.statut===statutFilter;
    return matchSearch && matchFil && matchStatut;
  });
  list.sort((a,b)=> `${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`, 'fr', {sensitivity:'base'}));
  const editable = canEdit('etudiants');
  const showPaiementCol = state.role!=='formateur';
  document.getElementById('etudiantsBody').innerHTML = list.length ? list.map(e=>{
    const fin = etudiantFinance(e.id);
    const statutCls = {actif:'badge-statut-actif',diplome:'badge-statut-diplome',abandon:'badge-statut-abandon'}[e.statut];
    const payCls = {'Payé':'badge-statut-paye','Partiel':'badge-statut-partiel','Impayé':'badge-statut-impaye'}[fin.statut];
    return `<tr>
      <td><div class="d-flex align-items-center gap-2">${avatarHTML(e,34,'square')}<div><div class="fw-semibold">${e.nom} ${e.prenom}</div><div class="text-muted d-md-none" style="font-size:.75rem;">${getFiliere(e.filiereId)?.nom||'—'}</div></div></div></td>
      <td class="text-mono d-none d-md-table-cell">${e.matricule}</td>
      <td class="d-none d-md-table-cell">${getFiliere(e.filiereId)?.nom||'—'}</td>
      <td class="d-none d-lg-table-cell">${e.telephone}</td>
      <td class="d-none d-lg-table-cell">${fmtDate(e.dateInscription)}</td>
      <td class="d-none d-md-table-cell"><span class="badge ${statutCls}">${e.statut}</span></td>
      ${showPaiementCol ? `<td class="d-none d-lg-table-cell"><span class="badge ${payCls}">${fin.statut}</span></td>` : ''}
      <td class="text-end">
        <button class="btn btn-sm btn-amber d-inline-flex d-md-none align-items-center gap-1" onclick="viewEtudiant('${e.id}')"><i class="bi bi-eye"></i> Afficher</button>
        <button class="btn btn-sm btn-icon d-none d-md-inline-flex" onclick="viewEtudiant('${e.id}')" title="Voir"><i class="bi bi-eye"></i></button>
        ${editable ? `<button class="btn btn-sm btn-icon d-none d-md-inline-flex" onclick="editEtudiant('${e.id}')" title="Modifier"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-icon text-danger d-none d-md-inline-flex" onclick="askDelete('etudiants','${e.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>` : ''}
      </td>
    </tr>`;
  }).join('') : `<tr><td colspan="${showPaiementCol?8:7}"><div class="empty-state"><i class="bi bi-inboxes"></i><p>Aucun étudiant trouvé</p></div></td></tr>`;
  document.getElementById('etudiantsCountBadge').textContent = list.length;
  document.getElementById('btnNewEtudiant').style.display = editable ? 'inline-block':'none';
  document.getElementById('thPaiementEtudiant').style.display = showPaiementCol ? '' : 'none';
}
document.getElementById('btnExportEtudiantsPdf').addEventListener('click', exportEtudiantsListPdf);
document.getElementById('searchEtudiant').addEventListener('input', renderEtudiants);
document.getElementById('filterFiliereEtudiant').addEventListener('change', renderEtudiants);
document.querySelectorAll('#filterStatutEtudiantGroup [data-statut]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    etudiantStatutFilter = btn.dataset.statut;
    document.querySelectorAll('#filterStatutEtudiantGroup [data-statut]').forEach(b=>b.classList.toggle('active', b===btn));
    renderEtudiants();
  });
});

function resetPhotoBox(){
  document.getElementById('photoInput').value='';
  document.getElementById('etudiantPhotoData').value='';
  document.getElementById('photoPreview').style.display='none';
  document.getElementById('photoPreview').src='';
  document.getElementById('photoPlaceholderIcon').style.display='block';
}
function setPhotoBox(dataUrl){
  document.getElementById('etudiantPhotoData').value = dataUrl || '';
  const img = document.getElementById('photoPreview');
  const icon = document.getElementById('photoPlaceholderIcon');
  if(dataUrl){ img.src = dataUrl; img.style.display='block'; icon.style.display='none'; }
  else { img.style.display='none'; icon.style.display='block'; }
}
document.getElementById('photoUploadBox').addEventListener('click', ()=> document.getElementById('photoInput').click());
document.getElementById('photoInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  setPhotoBox(URL.createObjectURL(file)); // aperçu instantané en local
  document.getElementById('etudiantPhotoData').value = '';
  const uploadPromise = uploadToCloudinary(file)
    .then(url => { document.getElementById('etudiantPhotoData').value = url; })
    .catch(err => { console.error(err); toast("Échec de l'envoi de la photo — réessayez"); resetPhotoBox(); });
  trackPendingUpload('etudiantPhotoData', uploadPromise);
});
/* ---------- Upload multi-images (preuve d'abandon / fichiers diplôme), limité à 3 fichiers ---------- */
const MULTI_UPLOADS = {};
function setupMultiImageUpload(inputId, hiddenId, previewId, max){
  const input = document.getElementById(inputId);
  const hidden = document.getElementById(hiddenId);
  const preview = document.getElementById(previewId);
  const getFiles = () => { try{ return JSON.parse(hidden.value||'[]'); }catch(err){ return []; } };
  const render = () => {
    const files = getFiles();
    preview.innerHTML = files.map((f,i)=>`
      <div class="position-relative">
        <img src="${f}" style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">
        <button type="button" class="btn-close btn-close-white position-absolute" style="top:-4px;right:-4px;width:8px;height:8px;padding:4px;background-color:var(--danger);border-radius:50%;" title="Retirer" onclick="removeMultiImage('${hiddenId}',${i})"></button>
      </div>`).join('') + (files.length<max ? `<div class="d-flex align-items-center text-muted" style="font-size:.72rem;">${files.length}/${max} image(s)</div>` : '');
  };
  input.addEventListener('change', ()=>{
    const files = getFiles();
    const toAdd = Array.from(input.files).slice(0, Math.max(0, max-files.length));
    if(!toAdd.length){ input.value=''; return; }
    // Aperçus locaux instantanés, remplacés par les URL Cloudinary une fois l'envoi terminé
    const startIdx = files.length;
    const merged = files.concat(toAdd.map(file=>URL.createObjectURL(file)));
    hidden.value = JSON.stringify(merged.slice(0,max));
    render();
    input.value = '';
    const uploadPromise = Promise.all(toAdd.map(file=>uploadToCloudinary(file)))
      .then(urls=>{
        const current = getFiles();
        urls.forEach((url,i)=>{ if(current[startIdx+i]!==undefined) current[startIdx+i] = url; });
        hidden.value = JSON.stringify(current.slice(0,max));
        render();
      })
      .catch(err=>{
        console.error(err);
        toast("Échec de l'envoi d'une image — réessayez");
        const current = getFiles().filter((_,i)=> i<startIdx || i>=startIdx+toAdd.length);
        hidden.value = JSON.stringify(current);
        render();
      });
    trackPendingUpload(hiddenId, uploadPromise);
  });
  const api = { render, reset: ()=>{ hidden.value=''; input.value=''; render(); } };
  MULTI_UPLOADS[hiddenId] = api;
  return api;
}
function removeMultiImage(hiddenId, idx){
  const hidden = document.getElementById(hiddenId);
  let files = []; try{ files = JSON.parse(hidden.value||'[]'); }catch(err){}
  files.splice(idx,1);
  hidden.value = JSON.stringify(files);
  MULTI_UPLOADS[hiddenId] && MULTI_UPLOADS[hiddenId].render();
}
setupMultiImageUpload('preuveAbandonInput','preuveAbandonData','preuveAbandonPreview',3);
setupMultiImageUpload('diplomeFichiersInput','diplomeFichiersData','diplomeFichiersPreview',3);
/* Affiche le bloc "Abandon" ou "Diplôme" selon le statut sélectionné */
function updateEtudiantStatutBlocs(){
  const v = document.querySelector('#formEtudiant [name="statut"]').value;
  document.getElementById('blocAbandon').style.display = v==='abandon' ? '' : 'none';
  document.getElementById('blocDiplome').style.display = v==='diplome' ? '' : 'none';
}
document.querySelector('#formEtudiant [name="statut"]').addEventListener('change', updateEtudiantStatutBlocs);
/* Un étudiant peut ne pas s'inscrire à tous les modules de sa filière : on affiche
   les modules de la filière choisie sous forme de cases à cocher, sans obligation de tout cocher. */
function renderEtudiantModulesCheckboxes(filId, selectedIds){
  selectedIds = selectedIds || [];
  const mods = modulesOfFiliere(filId);
  const wrap = document.getElementById('etudiantModulesList');
  wrap.innerHTML = mods.length ? mods.map(m=>`
    <div class="form-check">
      <input class="form-check-input" type="checkbox" name="moduleIds" value="${m.id}" id="modChk_${m.id}" ${selectedIds.includes(m.id)?'checked':''}>
      <label class="form-check-label small" for="modChk_${m.id}">${m.nom}${m.formateurId?` <span class="text-muted">— ${nomComplet(getFormateur(m.formateurId))}</span>`:''}</label>
    </div>`).join('') : `<div class="text-muted small">Aucun module défini pour cette filière pour le moment.</div>`;
}
document.getElementById('selectFiliereEtudiant').addEventListener('change', e=>{
  renderEtudiantModulesCheckboxes(e.target.value, []);
  // Pré-remplit le coût et la durée depuis la filière (l'utilisateur peut ensuite les modifier librement).
  const fil = getFiliere(e.target.value);
  if(fil){
    const coutEl = document.getElementById('etudiantCoutFormation');
    const dureeEl = document.getElementById('etudiantDureeFormation');
    if(coutEl && !coutEl.value) coutEl.value = fil.prixTotal || '';
    if(dureeEl && !dureeEl.value) dureeEl.value = fil.duree || '';
  }
});

/* ---- Assistant en 3 étapes du formulaire étudiant ---- */
const ETUDIANT_WIZARD_STEPS = 3;
let etudiantWizardStep = 1;
function goToEtudiantWizardStep(step){
  etudiantWizardStep = step;
  document.querySelectorAll('#formEtudiant .wizard-step').forEach(el=>{
    el.classList.toggle('active', Number(el.dataset.step)===step);
  });
  document.querySelectorAll('#etudiantWizardSteps .wizard-step-item').forEach(el=>{
    const n = Number(el.dataset.stepIndicator);
    el.classList.toggle('active', n===step);
    el.classList.toggle('done', n<step);
  });
  document.getElementById('btnEtudiantWizardPrev').style.display = step>1 ? 'inline-block' : 'none';
  document.getElementById('btnEtudiantWizardNext').style.display = step<ETUDIANT_WIZARD_STEPS ? 'inline-block' : 'none';
  document.getElementById('btnEtudiantWizardSubmit').style.display = step===ETUDIANT_WIZARD_STEPS ? 'inline-block' : 'none';
  const body = document.querySelector('#modalEtudiant .modal-body');
  if(body) body.scrollTop = 0;
}
function validateEtudiantWizardStep(step){
  const stepEl = document.querySelector(`#formEtudiant .wizard-step[data-step="${step}"]`);
  const invalid = [...stepEl.querySelectorAll('[required]')].find(el=>!el.checkValidity());
  if(invalid){ invalid.reportValidity(); invalid.focus(); return false; }
  return true;
}
document.getElementById('btnEtudiantWizardNext').addEventListener('click', ()=>{
  if(!validateEtudiantWizardStep(etudiantWizardStep)) return;
  goToEtudiantWizardStep(Math.min(etudiantWizardStep+1, ETUDIANT_WIZARD_STEPS));
});
document.getElementById('btnEtudiantWizardPrev').addEventListener('click', ()=>{
  goToEtudiantWizardStep(Math.max(etudiantWizardStep-1, 1));
});
// Seule la direction peut modifier manuellement le n° d'ordre du matricule d'un étudiant.
// Le matricule est affiché en lecture seule ; un clic sur le crayon ouvre l'édition du n° d'ordre.
function applyOrdreEtudiantEditability(){
  const btn = document.getElementById('btnEditOrdreEtudiant');
  if(!btn) return;
  const peutModifier = state.role==='direction';
  btn.style.display = peutModifier ? 'inline-flex' : 'none';
  closeOrdreEditWrap();
}
function openOrdreEditWrap(){
  const wrap = document.getElementById('ordreEditWrap');
  const btn = document.getElementById('btnEditOrdreEtudiant');
  const ordreEl = document.getElementById('inputEtudiantOrdre');
  const editInput = document.getElementById('inputEtudiantOrdreEdit');
  document.getElementById('ordreEditError').textContent = '';
  editInput.value = ordreEl.value || nextOrdreEtudiant();
  wrap.classList.remove('d-none');
  wrap.classList.add('d-flex');
  btn.style.display = 'none';
  editInput.focus();
  editInput.select();
}
function closeOrdreEditWrap(){
  const wrap = document.getElementById('ordreEditWrap');
  const btn = document.getElementById('btnEditOrdreEtudiant');
  wrap.classList.add('d-none');
  wrap.classList.remove('d-flex');
  if(state.role==='direction') btn.style.display = 'inline-flex';
  document.getElementById('ordreEditError').textContent = '';
}
document.getElementById('btnEditOrdreEtudiant').addEventListener('click', openOrdreEditWrap);
document.getElementById('btnCancelOrdreEtudiant').addEventListener('click', ()=>{ closeOrdreEditWrap(); updateMatriculeDisplay(); });
document.getElementById('inputEtudiantOrdreEdit').addEventListener('input', updateMatriculeDisplay);
document.getElementById('btnConfirmOrdreEtudiant').addEventListener('click', ()=>{
  const editInput = document.getElementById('inputEtudiantOrdreEdit');
  const errEl = document.getElementById('ordreEditError');
  const val = parseInt(editInput.value, 10);
  const f = document.getElementById('formEtudiant');
  if(!val || val<1){ errEl.textContent = 'N° invalide.'; return; }
  if(ordreEtudiantDejaUtilise(val, f.elements['id'].value || null)){
    errEl.textContent = 'N° déjà utilisé par un autre étudiant.';
    return;
  }
  document.getElementById('inputEtudiantOrdre').value = val;
  updateMatriculeDisplay();
  closeOrdreEditWrap();
});
document.getElementById('inputEtudiantOrdreEdit').addEventListener('keydown', ev=>{
  if(ev.key==='Enter'){ ev.preventDefault(); document.getElementById('btnConfirmOrdreEtudiant').click(); }
  else if(ev.key==='Escape'){ ev.preventDefault(); closeOrdreEditWrap(); }
});
document.getElementById('inputEtudiantDateInscription').addEventListener('input', updateMatriculeDisplay);
document.getElementById('btnNewEtudiant').addEventListener('click', ()=>{
  document.getElementById('formEtudiant').reset();
  document.getElementById('formEtudiant').elements['id'].value='';
  document.getElementById('inputEtudiantOrdre').value = nextOrdreEtudiant();
  // Date d'inscription pré-remplie avec aujourd'hui pour que le matricule s'affiche dès l'ouverture du formulaire
  document.getElementById('inputEtudiantDateInscription').value = new Date().toISOString().slice(0,10);
  resetPhotoBox();
  MULTI_UPLOADS['preuveAbandonData'].reset();
  MULTI_UPLOADS['diplomeFichiersData'].reset();
  updateEtudiantStatutBlocs();
  renderEtudiantModulesCheckboxes(document.getElementById('selectFiliereEtudiant').value, []);
  goToEtudiantWizardStep(1);
  document.getElementById('modalEtudiantTitle').textContent='Nouvel étudiant';
  applyOrdreEtudiantEditability();
  updateMatriculeDisplay();
  new bootstrap.Modal(document.getElementById('modalEtudiant')).show();
});
function editEtudiant(id){
  const e = getEtudiant(id);
  const f = document.getElementById('formEtudiant');
  f.reset();
  Object.keys(e).forEach(k=>{ if(f.elements[k]) f.elements[k].value = e[k]; });
  document.getElementById('inputEtudiantOrdre').value = e.ordre!=null ? e.ordre : nextOrdreEtudiant();
  setPhotoBox(e.photo || '');
  MULTI_UPLOADS['preuveAbandonData'].render();
  MULTI_UPLOADS['diplomeFichiersData'].render();
  updateEtudiantStatutBlocs();
  renderEtudiantModulesCheckboxes(e.filiereId, e.moduleIds||[]);
  goToEtudiantWizardStep(1);
  document.getElementById('modalEtudiantTitle').textContent='Modifier étudiant';
  applyOrdreEtudiantEditability();
  updateMatriculeDisplay();
  new bootstrap.Modal(document.getElementById('modalEtudiant')).show();
}
function viewEtudiant(id){
  const e = getEtudiant(id);
  const fin = etudiantFinance(id);
  const autresFin = etudiantAutresFrais(id);
  const notes = DB.evaluations.filter(ev=>ev.etudiantId===id);
  const moy = notes.length ? (notes.reduce((s,n)=>s+Number(n.note),0)/notes.length).toFixed(1) : '—';
  const editable = canEdit('etudiants');
  const showFinance = hasPerm('paiements','view') && state.role!=='formateur';
  const isFormateur = state.role==='formateur';
  const pres = DB.presences.filter(p=>p.etudiantId===id);
  const totalPres = pres.length;
  const nbPresent = pres.filter(p=>p.statut==='present').length;
  const nbRetard = pres.filter(p=>p.statut==='retard').length;
  const nbAbsent = pres.filter(p=>p.statut==='absent').length;
  const tauxPres = totalPres>0 ? Math.round((nbPresent/totalPres)*100) : 0;
  const fil = getFiliere(e.filiereId);
  const modsFil = fil ? modulesOfFiliere(fil.id) : [];
  const modsEt = (e.moduleIds||[]).map(getModule).filter(Boolean);
  const statutCls = {actif:'badge-statut-actif',diplome:'badge-statut-diplome',abandon:'badge-statut-abandon'}[e.statut];

  const noteCls = n => n>=14 ? 'note-good' : n>=10 ? 'note-avg' : 'note-bad';

  document.getElementById('ficheEtudiantBody').innerHTML = `
    <div class="fiche-banner mb-3">
      ${ficheLogoBadgeHTML()}
      <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
          <div style="border-radius:14px;padding:3px;background:rgba(255,255,255,.18);flex-shrink:0;">${avatarHTML(e, 60, 'square')}</div>
          <div>
            <div class="fiche-name">${nomComplet(e)}</div>
            <div class="fiche-sub">${e.matricule} · ${fil?.nom||'—'}</div>
            <span class="badge ${statutCls} mt-1">${e.statut}</span>
          </div>
        </div>
        <div class="d-flex gap-2 flex-wrap fiche-actions">
          ${e.telephone ? `<a class="btn btn-sm btn-outline-light" href="tel:${e.telephone}" title="Appeler"><i class="bi bi-telephone-fill"></i></a>` : ''}
          ${e.telephone ? `<a class="btn btn-sm btn-outline-light" href="${waLink(e.telephone)}" target="_blank" title="WhatsApp"><i class="bi bi-whatsapp"></i></a>` : ''}
          ${editable ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheEtudiant')).hide(); editEtudiant('${e.id}')" title="Modifier"><i class="bi bi-pencil"></i></button>` : ''}
          ${editable && showFinance ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheEtudiant')).hide(); openEcheancierModal('${e.id}')" title="Échéancier de paiement"><i class="bi bi-calendar2-week"></i></button>` : ''}
          ${editable ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheEtudiant')).hide(); askDelete('etudiants','${e.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>` : ''}
          <button class="btn btn-sm btn-amber" onclick="exportFicheEtudiantPdf('${e.id}')" title="Enregistrer en PDF"><i class="bi bi-file-earmark-pdf"></i> PDF</button>
        </div>
      </div>
    </div>

    <div class="row g-3 mb-1">
      <div class="${isFormateur ? 'col-12' : 'col-md-6'}">
        <div class="fiche-section h-100">
          <h6><i class="bi bi-person-vcard me-1"></i> Informations personnelles</h6>
          <div class="row g-2">
            <div class="col-6 fiche-field"><span class="fiche-label">Sexe</span><span class="fiche-value">${e.sexe==='F'?'Féminin':'Masculin'}</span></div>
            ${!isFormateur ? `<div class="col-6 fiche-field"><span class="fiche-label">Date de naissance</span><span class="fiche-value">${fmtDate(e.dateNaissance)}</span></div>` : ''}
            <div class="col-6 fiche-field"><span class="fiche-label">Téléphone</span><span class="fiche-value">${e.telephone||'—'}</span></div>
            <div class="col-6 fiche-field"><span class="fiche-label">Email</span><span class="fiche-value">${e.email||'—'}</span></div>
            ${!isFormateur ? `<div class="col-6 fiche-field"><span class="fiche-label">Lieu de résidence</span><span class="fiche-value">${e.adresse||'—'}</span></div>` : ''}
            <div class="col-6 fiche-field"><span class="fiche-label">Niveau d'étude</span><span class="fiche-value">${e.niveauEtude||'—'}</span></div>
            <div class="col-12 fiche-field mb-0"><span class="fiche-label">Compétences / formations suivies</span><span class="fiche-value">${e.competences||'—'}</span></div>
          </div>
        </div>
      </div>
      ${!isFormateur ? `<div class="col-md-6">
        <div class="fiche-section h-100">
          <h6><i class="bi bi-people-fill me-1"></i> Tuteur / Parent</h6>
          <div class="row g-2">
            <div class="col-6 fiche-field"><span class="fiche-label">Nom</span><span class="fiche-value">${e.nomTuteur||'—'}</span></div>
            <div class="col-6 fiche-field"><span class="fiche-label">Lien</span><span class="fiche-value">${e.lienTuteur||'—'}</span></div>
            <div class="col-12 fiche-field">
              <span class="fiche-label">Téléphone</span>
              <div class="d-flex align-items-center flex-wrap gap-2">
                <span class="fiche-value">${e.telephoneTuteur||'—'}</span>
                ${e.telephoneTuteur ? `<a class="btn btn-sm btn-icon" href="tel:${e.telephoneTuteur}" title="Appeler le tuteur"><i class="bi bi-telephone-fill"></i></a>
                <a class="btn btn-sm btn-icon text-success" href="${waLink(e.telephoneTuteur)}" target="_blank" title="WhatsApp tuteur"><i class="bi bi-whatsapp"></i></a>` : ''}
              </div>
            </div>
            <div class="col-12 fiche-field mb-0"><span class="fiche-label">Adresse du tuteur</span><span class="fiche-value">${e.adresseTuteur||'—'}</span></div>
          </div>
        </div>
      </div>` : ''}
    </div>

    <div class="fiche-section">
      <h6><i class="bi bi-mortarboard-fill me-1"></i> Formation</h6>
      <div class="row g-2">
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Filière</span><span class="fiche-value">${fil?.nom||'—'}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Modules suivis</span><span class="fiche-value">${modsEt.length}/${modsFil.length}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Date d'inscription</span><span class="fiche-value">${fmtDate(e.dateInscription)}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Moyenne générale</span><span class="fiche-value">${moy}/20</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Date de démarrage</span><span class="fiche-value">${e.dateDemarrage?fmtDate(e.dateDemarrage):'—'}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Durée de la formation</span><span class="fiche-value">${e.dureeFormation||'—'}</span></div>
        ${showFinance ? `<div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Coût de la formation</span><span class="fiche-value">${e.coutFormation?fmtCFA(e.coutFormation):'—'}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Frais d'inscription</span><span class="fiche-value">${e.fraisInscription?fmtCFA(e.fraisInscription):'—'}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">Frais d'uniforme</span><span class="fiche-value">${e.fraisUniforme?fmtCFA(e.fraisUniforme):'—'}</span></div>
        <div class="col-6 col-md-3 fiche-field mb-0"><span class="fiche-label">${e.autresFraisLibelle||'Autres frais'}</span><span class="fiche-value">${e.autresFraisMontant?fmtCFA(e.autresFraisMontant):'—'}</span></div>` : ''}
        <div class="col-12 fiche-field mb-0">
          <span class="fiche-label d-block mb-1">Modules suivis</span>
          ${modsEt.length ? `<div class="d-flex flex-wrap gap-2">${modsEt.map(m=>`<span class="badge bg-light text-dark border">${m.nom}</span>`).join('')}</div>` : '<p class="text-muted small mb-0">Aucun module sélectionné pour le moment.</p>'}
        </div>
      </div>
    </div>

    ${e.statut==='abandon' ? `
    <div class="fiche-section">
      <h6><i class="bi bi-x-octagon-fill me-1"></i> Détails de l'abandon</h6>
      <div class="fiche-field mb-2"><span class="fiche-label">Motif</span><span class="fiche-value">${e.motifAbandon||'—'}</span></div>
      ${(()=>{ const imgs = (()=>{try{return JSON.parse(e.preuveAbandon||'[]');}catch(err){return [];}})(); return imgs.length ? `<span class="fiche-label d-block mb-1">Preuve</span><div class="d-flex flex-wrap gap-2">${imgs.map(src=>`<img src="${src}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">`).join('')}</div>` : '<p class="text-muted small mb-0">Aucune preuve jointe.</p>'; })()}
    </div>` : ''}
    ${e.statut==='diplome' ? `
    <div class="fiche-section">
      <h6><i class="bi bi-award-fill me-1"></i> Détails du diplôme</h6>
      <div class="fiche-field mb-2"><span class="fiche-label">Date de fin de formation</span><span class="fiche-value">${e.dateFin?fmtDate(e.dateFin):'—'}</span></div>
      ${(()=>{ const imgs = (()=>{try{return JSON.parse(e.diplomeFichiers||'[]');}catch(err){return [];}})(); return imgs.length ? `<span class="fiche-label d-block mb-1">Fichiers diplôme</span><div class="d-flex flex-wrap gap-2">${imgs.map(src=>`<img src="${src}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">`).join('')}</div>` : '<p class="text-muted small mb-0">Aucun fichier joint.</p>'; })()}
    </div>` : ''}

    <div class="fiche-section">
      <h6><i class="bi bi-clipboard-check-fill me-1"></i> Évaluations</h6>
      ${notes.length? `<div class="d-flex flex-column gap-2">${notes.map(n=>`<div class="d-flex align-items-center justify-content-between"><span style="font-size:.87rem;">${n.module}</span><span class="note-pill ${noteCls(Number(n.note))}">${n.note}/20</span></div>`).join('')}</div>` : '<p class="text-muted small mb-0">Aucune évaluation enregistrée.</p>'}
    </div>

    <div class="fiche-section">
      <h6><i class="bi bi-calendar-check-fill me-1"></i> État de présence</h6>
      <div class="row g-2">
        <div class="col-6 col-md-3"><div class="fiche-mini-stat"><div class="stat-num" style="color:#1C7A46;">${nbPresent}</div><div class="stat-label">Présences</div></div></div>
        <div class="col-6 col-md-3"><div class="fiche-mini-stat"><div class="stat-num" style="color:#B4700B;">${nbRetard}</div><div class="stat-label">Retards</div></div></div>
        <div class="col-6 col-md-3"><div class="fiche-mini-stat"><div class="stat-num" style="color:#B03327;">${nbAbsent}</div><div class="stat-label">Absences</div></div></div>
        <div class="col-6 col-md-3"><div class="fiche-mini-stat"><div class="stat-num">${tauxPres}%</div><div class="stat-label">Taux présence</div></div></div>
      </div>
    </div>

    ${showFinance ? `<div class="fiche-section">
      <h6><i class="bi bi-cash-stack me-1"></i> Frais de formation</h6>
      <div class="row g-3">
        <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num">${fmtCFA(fin.total)}</div><div class="stat-label">Montant dû</div></div></div>
        <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="color:#1C7A46;">${fmtCFA(fin.paye)}</div><div class="stat-label">Payé</div></div></div>
        <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="color:#B03327;">${fmtCFA(fin.reste)}</div><div class="stat-label">Reste à payer</div></div></div>
      </div>
    </div>` : ''}

    ${showFinance ? `<div class="fiche-section">
      <h6><i class="bi bi-wallet2 me-1"></i> Autres frais</h6>
      <div class="row g-3">
        <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num">${fmtCFA(autresFin.total)}</div><div class="stat-label">Montant dû</div></div></div>
        <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="color:#1C7A46;">${fmtCFA(autresFin.paye)}</div><div class="stat-label">Payé</div></div></div>
        <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="color:#B03327;">${fmtCFA(autresFin.reste)}</div><div class="stat-label">Reste à payer</div></div></div>
      </div>
    </div>` : ''}

    ${showFinance && e.echeancier && e.echeancier.length ? (()=>{
      const statutCls = {'Payé':'badge-statut-paye','À échoir':'badge-statut-partiel','En retard':'badge-statut-impaye','À venir':'badge-statut-avenir'};
      const rows = computeEcheancier(e.id);
      return `<div class="fiche-section">
        <h6><i class="bi bi-calendar2-week me-1"></i> Échéancier de paiement</h6>
        <div class="table-responsive"><table class="table table-sm align-middle mb-0">
          <thead><tr><th>Tranche</th><th>Montant</th><th>Payé</th><th>Reste</th><th>Date limite</th><th>Statut</th></tr></thead>
          <tbody>${rows.map(r=>`<tr>
            <td>${r.libelle}</td><td>${fmtCFA(r.montant)}</td>
            <td class="text-success">${fmtCFA(r.paye)}</td>
            <td class="${r.reste>0?'text-danger fw-semibold':''}">${r.reste>0?fmtCFA(r.reste):'—'}</td>
            <td>${fmtDate(r.date)}</td>
            <td><span class="badge ${statutCls[r.statut]}">${r.statut}</span></td>
          </tr>`).join('')}</tbody>
        </table></div>
      </div>`;
    })() : ''}

    ${showFinance ? (()=>{
      const listPaiements = DB.paiements.filter(p=>p.etudiantId===e.id).sort((a,b)=>new Date(b.date)-new Date(a.date));
      return `<div class="fiche-section mb-0">
        <h6><i class="bi bi-cash-coin me-1"></i> Historique des paiements</h6>
        ${listPaiements.length ? `<ul class="list-group list-group-flush">${listPaiements.map(p=>`
          <li class="list-group-item d-flex justify-content-between align-items-center px-0">
            <div><div class="fw-semibold small">${p.type}</div><div class="text-muted" style="font-size:.75rem;">${fmtDate(p.date)} · ${p.mode}</div></div>
            <span class="fw-bold">${fmtCFA(p.montant)}</span>
          </li>`).join('')}</ul>` : `<p class="text-muted small mb-0">Aucun versement enregistré.</p>`}
      </div>`;
    })() : ''}
  `;
  new bootstrap.Modal(document.getElementById('modalFicheEtudiant')).show();
}
async function exportFicheEtudiantPdf(id){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const e = getEtudiant(id);
  const fin = etudiantFinance(id);
  const notes = DB.evaluations.filter(ev=>ev.etudiantId===id);
  const moy = notes.length ? (notes.reduce((s,n)=>s+Number(n.note),0)/notes.length).toFixed(1) : '—';
  const showFinance = hasPerm('paiements','view') && state.role!=='formateur';
  const isFormateur = state.role==='formateur';
  const pres = DB.presences.filter(p=>p.etudiantId===id);
  const totalPres = pres.length;
  const nbPresent = pres.filter(p=>p.statut==='present').length;
  const nbRetard = pres.filter(p=>p.statut==='retard').length;
  const nbAbsent = pres.filter(p=>p.statut==='absent').length;
  const tauxPres = totalPres>0 ? Math.round((nbPresent/totalPres)*100) : 0;
  const fil = getFiliere(e.filiereId);
  const modsEt = (e.moduleIds||[]).map(getModule).filter(Boolean);
  const M = 14, W = 182; // marge gauche & largeur utile de la page A4

  pdfHeader(doc, 'Fiche étudiant', `Document généré le ${new Date().toLocaleDateString('fr-FR')}`, font);

  // ----- Bandeau d'identité (photo, nom, matricule, filière, statut) -----
  let y = 50;
  doc.setFillColor(22,35,63);
  doc.roundedRect(M, y, W, 22, 3, 3, 'F');
  let photoDrawn = false;
  if(e.photo){
    try{
      doc.setFillColor(255,255,255);
      doc.roundedRect(M+6, y+3, 16, 16, 2.5, 2.5, 'F');
      doc.addImage(e.photo, pdfImgFormat(e.photo), M+6.8, y+3.8, 14.4, 14.4);
      photoDrawn = true;
    }catch(err){ photoDrawn = false; }
  }
  if(!photoDrawn){
    doc.setFillColor(232,163,61);
    doc.circle(M+14, y+11, 8, 'F');
    doc.setFont(font,'bold'); doc.setFontSize(10.5); doc.setTextColor(22,35,63);
    doc.text(initials(e.prenom,e.nom), M+14, y+13, {align:'center'});
  }
  doc.setFont(font,'bold'); doc.setFontSize(13); doc.setTextColor(255,255,255);
  doc.text(nomComplet(e), M+28, y+9.5);
  doc.setFont(font,'normal'); doc.setFontSize(9); doc.setTextColor(190,198,220);
  doc.text(`${e.matricule}  ·  ${fil?.nom||'—'}`, M+28, y+15.5);
  const statutLabel = {actif:'Actif',diplome:'Diplômé',abandon:'Abandon'}[e.statut]||e.statut||'—';
  const statutColor = {actif:[28,122,70],diplome:[46,78,166],abandon:[176,51,39]}[e.statut]||[22,35,63];
  doc.setFont(font,'bold'); doc.setFontSize(8);
  const badgeW = doc.getTextWidth(statutLabel)+10;
  doc.setFillColor(255,255,255);
  doc.roundedRect(M+W-badgeW-6, y+7, badgeW, 8, 4, 4, 'F');
  doc.setTextColor.apply(doc, statutColor);
  doc.text(statutLabel, M+W-badgeW-6+badgeW/2, y+12.3, {align:'center'});
  y += 22 + 7;

  // ----- Rubriques -----
  const infosPersoRows = [
    ['Sexe', e.sexe==='F'?'Féminin':'Masculin'],
  ];
  if(!isFormateur) infosPersoRows.push(['Date de naissance', fmtDate(e.dateNaissance)]);
  infosPersoRows.push(['Téléphone', e.telephone||'—'], ['Email', e.email||'—']);
  if(!isFormateur) infosPersoRows.push(['Lieu de résidence', e.adresse||'—']);
  infosPersoRows.push(["Niveau d'étude", e.niveauEtude||'—'], ['Compétences / formations suivies', e.competences||'—']);
  y = pdfSection(doc, M, y, W, 'Informations personnelles', infosPersoRows, font) + 6;

  if(!isFormateur){
    y = pdfSection(doc, M, y, W, 'Tuteur / Parent', [
      ['Nom', e.nomTuteur||'—'],
      ['Lien', e.lienTuteur||'—'],
      ['Téléphone', e.telephoneTuteur||'—'],
      ['Adresse', e.adresseTuteur||'—'],
    ], font) + 6;
  }

  const formationRows = [
    ['Filière', fil?.nom||'—'],
    ["Date d'inscription", fmtDate(e.dateInscription)],
    ['Date de démarrage', e.dateDemarrage?fmtDate(e.dateDemarrage):'—'],
    ['Durée de la formation', e.dureeFormation||'—'],
  ];
  if(showFinance){
    formationRows.push(
      ['Coût de la formation', e.coutFormation?fmtCFA(e.coutFormation):'—'],
      ["Frais d'inscription", e.fraisInscription?fmtCFA(e.fraisInscription):'—'],
      ["Frais d'uniforme", e.fraisUniforme?fmtCFA(e.fraisUniforme):'—'],
      [e.autresFraisLibelle||'Autres frais', e.autresFraisMontant?fmtCFA(e.autresFraisMontant):'—'],
    );
  }
  formationRows.push(['Moyenne générale', moy+'/20']);
  formationRows.push(['Modules suivis', modsEt.length ? modsEt.map(m=>m.nom).join(', ') : 'Aucun module sélectionné pour le moment.']);
  y = pdfSection(doc, M, y, W, 'Formation', formationRows, font) + 6;

  // ----- Rubrique conditionnelle selon le statut -----
  if(e.statut==='abandon'){
    y = pdfSectionWithImages(doc, M, y, W, "Détails de l'abandon", [
      ['Motif', e.motifAbandon||'—'],
    ], pdfParseImages(e.preuveAbandon), font) + 6;
  } else if(e.statut==='diplome'){
    y = pdfSectionWithImages(doc, M, y, W, 'Détails du diplôme', [
      ['Date de fin de formation', e.dateFin?fmtDate(e.dateFin):'—'],
    ], pdfParseImages(e.diplomeFichiers), font) + 6;
  }

  // ----- Évaluations -----
  if(notes.length){
    if(y > 255){ doc.addPage(); y = 20; }
    doc.autoTable({
      startY: y,
      margin:{left:M,right:210-M-W},
      tableWidth:W,
      theme:'grid',
      head: [
        [{content:'ÉVALUATIONS', colSpan:4, styles:{fillColor:[22,35,63], textColor:255, fontStyle:'bold', fontSize:9, halign:'left', cellPadding:{top:3.2,bottom:3.2,left:4,right:4}}}],
        ['Module','Note /20','Appréciation','Date'].map(t=>({content:t, styles:{fillColor:[240,241,244], textColor:[90,95,105], fontStyle:'bold', fontSize:7.3}})),
      ],
      body: notes.map(n=>[n.module, n.note, n.appreciation||'—', fmtDate(n.date)]),
      styles:{font, lineColor:[228,231,236], lineWidth:0.15, cellPadding:{top:2.8,bottom:2.8,left:4,right:3}},
      bodyStyles:{fontSize:8.5, textColor:[26,29,35]},
      alternateRowStyles:{fillColor:[248,249,251]},
    });
    y = doc.lastAutoTable.finalY + 6;
  }

  // ----- Présence -----
  if(y > 250){ doc.addPage(); y = 20; }
  y = pdfStatsSection(doc, M, y, W, 'Présence', [
    {label:'Présences', value:nbPresent, color:[28,122,70]},
    {label:'Retards', value:nbRetard, color:[180,112,11]},
    {label:'Absences', value:nbAbsent, color:[176,51,39]},
    {label:'Taux présence', value:tauxPres+'%', color:[22,35,63]},
  ], font) + 6;

  // ----- Frais de formation -----
  if(showFinance){
    if(y > 250){ doc.addPage(); y = 20; }
    y = pdfStatsSection(doc, M, y, W, 'Frais de formation', [
      {label:'Montant dû', value:fmtCFA(fin.total), color:[22,35,63]},
      {label:'Payé', value:fmtCFA(fin.paye), color:[28,122,70]},
      {label:'Reste à payer', value:fmtCFA(fin.reste), color:[176,51,39]},
    ], font) + 6;

    if(y > 250){ doc.addPage(); y = 20; }
    const autresFin = etudiantAutresFrais(id);
    y = pdfStatsSection(doc, M, y, W, 'Autres frais', [
      {label:'Montant dû', value:fmtCFA(autresFin.total), color:[22,35,63]},
      {label:'Payé', value:fmtCFA(autresFin.paye), color:[28,122,70]},
      {label:'Reste à payer', value:fmtCFA(autresFin.reste), color:[176,51,39]},
    ], font) + 6;

    const echRows = computeEcheancier(id);
    if(echRows.length){
      if(y > 250){ doc.addPage(); y = 20; }
      doc.autoTable({
        startY: y,
        margin:{left:M,right:210-M-W},
        tableWidth:W,
        theme:'grid',
        head: [
          [{content:'ÉCHÉANCIER DE PAIEMENT', colSpan:6, styles:{fillColor:[22,35,63], textColor:255, fontStyle:'bold', fontSize:9, halign:'left', cellPadding:{top:3.2,bottom:3.2,left:4,right:4}}}],
          ['Tranche','Montant','Payé','Reste','Date limite','Statut'].map(t=>({content:t, styles:{fillColor:[240,241,244], textColor:[90,95,105], fontStyle:'bold', fontSize:7.3}})),
        ],
        body: echRows.map(r=>[r.libelle, fmtCFA(r.montant), fmtCFA(r.paye), r.reste>0?fmtCFA(r.reste):'—', fmtDate(r.date), r.statut]),
        styles:{font, lineColor:[228,231,236], lineWidth:0.15, cellPadding:{top:2.8,bottom:2.8,left:4,right:3}},
        bodyStyles:{fontSize:8.5, textColor:[26,29,35]},
        alternateRowStyles:{fillColor:[248,249,251]},
      });
      y = doc.lastAutoTable.finalY + 6;
    }

    // ----- Historique des paiements -----
    const listPaiements = DB.paiements.filter(p=>p.etudiantId===id).sort((a,b)=>new Date(b.date)-new Date(a.date));
    if(listPaiements.length){
      if(y > 250){ doc.addPage(); y = 20; }
      doc.autoTable({
        startY: y,
        margin:{left:M,right:210-M-W},
        tableWidth:W,
        theme:'grid',
        head: [
          [{content:'HISTORIQUE DES PAIEMENTS', colSpan:4, styles:{fillColor:[22,35,63], textColor:255, fontStyle:'bold', fontSize:9, halign:'left', cellPadding:{top:3.2,bottom:3.2,left:4,right:4}}}],
          ['Date','Type','Mode','Montant'].map(t=>({content:t, styles:{fillColor:[240,241,244], textColor:[90,95,105], fontStyle:'bold', fontSize:7.3}})),
        ],
        body: listPaiements.map(p=>[fmtDate(p.date), p.type||'—', p.mode||'—', fmtCFA(p.montant)]),
        styles:{font, lineColor:[228,231,236], lineWidth:0.15, cellPadding:{top:2.8,bottom:2.8,left:4,right:3}},
        bodyStyles:{fontSize:8.5, textColor:[26,29,35]},
        alternateRowStyles:{fillColor:[248,249,251]},
      });
      y = doc.lastAutoTable.finalY + 6;
    }
  }

  pdfFooter(doc, font);
  doc.save(`fiche-${e.matricule}.pdf`);
}
document.getElementById('formEtudiant').addEventListener('submit', async e=>{
  e.preventDefault();
  const f = e.target;
  await resolvePendingUpload('etudiantPhotoData');
  await resolvePendingUpload('preuveAbandonData');
  await resolvePendingUpload('diplomeFichiersData');
  const fd = new FormData(f);
  const data = Object.fromEntries(fd.entries());
  data.moduleIds = fd.getAll('moduleIds'); // plusieurs cases peuvent être cochées (ou aucune)

  // Le n° d'ordre doit être unique (jamais partagé par 2 étudiants), même si le mois/année
  // d'inscription (partie après "CF") peut se répéter d'un étudiant à l'autre.
  let ordreNum = parseInt(data.ordre, 10);
  if(!ordreNum || ordreNum < 1){ ordreNum = nextOrdreEtudiant(); }
  if(ordreEtudiantDejaUtilise(ordreNum, data.id || null)){
    toast(`Le n° d'ordre ${String(ordreNum).padStart(3,'0')} est déjà utilisé par un autre étudiant. Veuillez en choisir un autre.`);
    document.getElementById('btnEditOrdreEtudiant').click();
    return;
  }
  data.ordre = ordreNum;
  data.matricule = computeMatricule(ordreNum, data.dateInscription);

  if(data.id){
    const idx = DB.etudiants.findIndex(x=>x.id===data.id);
    DB.etudiants[idx] = {...DB.etudiants[idx], ...data};
  } else {
    data.id = uid();
    DB.etudiants.push(data);
  }
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalEtudiant')).hide();
  toast('Étudiant enregistré avec succès');
  populateAllSelects(); renderEtudiants();
});

/* ---------- FILIERES ---------- */
function renderFilieres(){
  const editable = canEdit('filieres');
  document.getElementById('btnNewFiliere').style.display = editable?'inline-block':'none';
  const list = scopeFilieres(DB.filieres).slice().sort((a,b)=>(a.nom||'').localeCompare(b.nom||'','fr',{sensitivity:'base'}));
  document.getElementById('filieresGrid').innerHTML = list.length ? list.map(f=>{
    const nbEt = DB.etudiants.filter(e=>e.filiereId===f.id).length;
    return `<tr>
      <td><span class="fw-semibold">${f.nom}</span></td>
      <td class="d-none d-md-table-cell">${f.duree||'—'}</td>
      <td class="d-none d-lg-table-cell">${fmtCFA(f.prixTotal)}</td>
      <td class="d-none d-lg-table-cell">${nbEt}</td>
      <td class="text-end">
        <button class="btn btn-sm btn-amber d-inline-flex d-md-none align-items-center gap-1" onclick="viewFiliere('${f.id}')"><i class="bi bi-eye"></i> Afficher</button>
        <button class="btn btn-sm btn-icon d-none d-md-inline-flex" onclick="viewFiliere('${f.id}')" title="Afficher"><i class="bi bi-eye"></i></button>
        ${editable ? `<button class="btn btn-sm btn-icon d-none d-md-inline-flex" onclick="editFiliere('${f.id}')" title="Modifier"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-icon text-danger d-none d-md-inline-flex" onclick="askDelete('filieres','${f.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>` : ''}
      </td>
    </tr>`;
  }).join('') : `<tr><td colspan="5"><div class="empty-state"><i class="bi bi-mortarboard"></i><p>Aucune filière</p></div></td></tr>`;
}
function viewFiliere(id){
  const f = getFiliere(id);
  if(!f) return;
  const nbEt = DB.etudiants.filter(e=>e.filiereId===f.id).length;
  const mods = modulesOfFiliere(f.id);
  const editable = canEdit('filieres');
  document.getElementById('ficheFiliereBody').innerHTML = `
    <div class="fiche-banner mb-3">
      ${ficheLogoBadgeHTML()}
      <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
          ${f.flyer ? `<img src="${f.flyer}" style="width:60px;height:60px;object-fit:cover;border-radius:12px;">` : `<div style="width:60px;height:60px;border-radius:12px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;"><i class="bi bi-mortarboard-fill" style="font-size:1.5rem;"></i></div>`}
          <div>
            <div class="fiche-name">${f.nom}</div>
            <div class="fiche-sub">${f.duree||'—'}</div>
          </div>
        </div>
        <div class="d-flex gap-2 flex-wrap fiche-actions">
          <button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheFiliere')).hide(); openModulesModal('${f.id}')" title="Modules"><i class="bi bi-collection"></i> Modules (${mods.length})</button>
          ${editable ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheFiliere')).hide(); editFiliere('${f.id}')" title="Modifier"><i class="bi bi-pencil"></i></button>` : ''}
          ${editable ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheFiliere')).hide(); askDelete('filieres','${f.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>` : ''}
        </div>
      </div>
    </div>
    <div class="fiche-section">
      <h6><i class="bi bi-info-circle me-1"></i> Informations</h6>
      <div class="row g-2">
        <div class="col-6 fiche-field"><span class="fiche-label">Durée</span><span class="fiche-value">${f.duree||'—'}</span></div>
        <div class="col-6 fiche-field"><span class="fiche-label">Prix total</span><span class="fiche-value">${fmtCFA(f.prixTotal)}</span></div>
        <div class="col-6 fiche-field mb-0"><span class="fiche-label">Étudiants inscrits</span><span class="fiche-value">${nbEt}</span></div>
      </div>
    </div>
    ${f.description ? `<div class="fiche-section">
      <h6><i class="bi bi-file-text me-1"></i> Description</h6>
      <p class="mb-0 small">${f.description}</p>
    </div>` : ''}
    ${f.debouches ? `<div class="fiche-section mb-0">
      <h6><i class="bi bi-briefcase-fill me-1"></i> Débouchés</h6>
      <p class="mb-0 small">${f.debouches}</p>
    </div>` : ''}
  `;
  new bootstrap.Modal(document.getElementById('modalFicheFiliere')).show();
}
function resetFiliereImageBox(){
  document.getElementById('filiereImageInput').value='';
  document.getElementById('filiereImageData').value='';
  document.getElementById('filiereImagePreview').style.display='none';
  document.getElementById('filiereImagePreview').src='';
  document.getElementById('filiereImagePlaceholderIcon').style.display='block';
}
function setFiliereImageBox(dataUrl){
  document.getElementById('filiereImageData').value = dataUrl || '';
  const img = document.getElementById('filiereImagePreview');
  const icon = document.getElementById('filiereImagePlaceholderIcon');
  if(dataUrl){ img.src = dataUrl; img.style.display='block'; icon.style.display='none'; }
  else { img.style.display='none'; icon.style.display='block'; }
}
document.getElementById('filiereImageUploadBox').addEventListener('click', ()=> document.getElementById('filiereImageInput').click());
document.getElementById('filiereImageInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  setFiliereImageBox(URL.createObjectURL(file));
  document.getElementById('filiereImageData').value = '';
  const uploadPromise = uploadToCloudinary(file)
    .then(url => { document.getElementById('filiereImageData').value = url; })
    .catch(err => { console.error(err); toast("Échec de l'envoi de l'image — réessayez"); resetFiliereImageBox(); });
  trackPendingUpload('filiereImageData', uploadPromise);
});
document.getElementById('btnNewFiliere').addEventListener('click', ()=>{
  document.getElementById('formFiliere').reset();
  document.getElementById('formFiliere').elements['id'].value='';
  resetFiliereImageBox();
  document.getElementById('modalFiliereTitle').textContent='Nouvelle filière';
  new bootstrap.Modal(document.getElementById('modalFiliere')).show();
});
function editFiliere(id){
  const f = getFiliere(id);
  const form = document.getElementById('formFiliere');
  form.reset();
  Object.keys(f).forEach(k=>{ if(form.elements[k]) form.elements[k].value = f[k]; });
  setFiliereImageBox(f.flyer);
  document.getElementById('modalFiliereTitle').textContent='Modifier filière';
  new bootstrap.Modal(document.getElementById('modalFiliere')).show();
}
document.getElementById('formFiliere').addEventListener('submit', async e=>{
  e.preventDefault();
  await resolvePendingUpload('filiereImageData');
  const data = Object.fromEntries(new FormData(e.target).entries());
  if(data.id){
    const idx = DB.filieres.findIndex(x=>x.id===data.id);
    DB.filieres[idx] = {...DB.filieres[idx], ...data};
  } else {
    data.id = uid();
    DB.filieres.push(data);
  }
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalFiliere')).hide();
  toast('Filière enregistrée');
  populateAllSelects(); renderFilieres(); renderPublicSite();
});


/* ---------- MODULES (rattachés à une filière) ---------- */
let currentModulesFiliereId = null;
function openModulesModal(filId){
  currentModulesFiliereId = filId;
  const fil = getFiliere(filId);
  document.getElementById('modalModulesTitle').textContent = 'Modules — '+(fil?fil.nom:'');
  renderModulesList();
  new bootstrap.Modal(document.getElementById('modalModules')).show();
}
function renderModulesList(){
  const editable = canEdit('filieres');
  document.getElementById('btnNewModule').style.display = editable?'inline-block':'none';
  const list = modulesOfFiliere(currentModulesFiliereId);
  document.getElementById('modulesBody').innerHTML = list.length ? list.map(m=>`
    <tr>
      <td class="fw-semibold">${m.nom}</td>
      <td>${m.formateurId ? nomComplet(getFormateur(m.formateurId)) : '<span class="text-muted">Non assigné</span>'}</td>
      <td class="d-none d-md-table-cell text-muted small">${m.description||'—'}</td>
      <td class="text-end">${editable?`<button class="btn btn-sm btn-icon" onclick="editModule('${m.id}')"><i class="bi bi-pencil"></i></button><button class="btn btn-sm btn-icon text-danger" onclick="deleteModule('${m.id}')"><i class="bi bi-trash"></i></button>`:''}</td>
    </tr>`).join('') : `<tr><td colspan="4"><div class="empty-state"><i class="bi bi-collection"></i><p>Aucun module pour cette filière</p></div></td></tr>`;
}
function fillSelectFormateurModule(){
  document.getElementById('selectFormateurModule').innerHTML = '<option value="">—</option>'+DB.formateurs.map(f=>`<option value="${f.id}">${nomComplet(f)}</option>`).join('');
}
document.getElementById('btnNewModule').addEventListener('click', ()=>{
  fillSelectFormateurModule();
  document.getElementById('formModule').reset();
  document.getElementById('formModule').elements['id'].value='';
  document.getElementById('moduleFiliereId').value = currentModulesFiliereId;
  document.getElementById('modalModuleFormTitle').textContent='Nouveau module';
  new bootstrap.Modal(document.getElementById('modalModuleForm')).show();
});
function editModule(id){
  fillSelectFormateurModule();
  const m = getModule(id);
  const form = document.getElementById('formModule');
  form.reset();
  Object.keys(m).forEach(k=>{ if(form.elements[k]) form.elements[k].value = m[k]; });
  document.getElementById('modalModuleFormTitle').textContent='Modifier module';
  new bootstrap.Modal(document.getElementById('modalModuleForm')).show();
}
document.getElementById('formModule').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  if(data.id){
    const idx = DB.modules.findIndex(x=>x.id===data.id);
    DB.modules[idx] = {...DB.modules[idx], ...data};
  } else {
    data.id = uid();
    DB.modules.push(data);
  }
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalModuleForm')).hide();
  toast('Module enregistré');
  renderModulesList();
  renderFilieres();
  if(document.getElementById('panel-formateurs').classList.contains('active')) renderFormateurs();
});
function deleteModule(id){
  pendingDelete = {collection:'modules', id};
  new bootstrap.Modal(document.getElementById('modalConfirm')).show();
}

/* ---------- FORMATEURS ---------- */
function renderFormateurs(){
  const editable = canEdit('formateurs');
  document.getElementById('btnNewFormateur').style.display = editable?'inline-block':'none';
  document.getElementById('formateursBody').innerHTML = DB.formateurs.map(f=>{
    const mods = modulesOfFormateur(f.id);
    const modIdsSet = mods.map(m=>m.id);
    const nbEt = DB.etudiants.filter(e=>(e.moduleIds||[]).some(mid=>modIdsSet.includes(mid))).length;
    return `<tr>
      <td><div class="d-flex align-items-center gap-2">${avatarHTML(f)}<span class="fw-semibold">${nomComplet(f)}</span></div></td>
      <td class="d-none d-md-table-cell">${f.specialite||'—'}</td>
      <td class="d-none d-md-table-cell">${f.telephone}<br><span class="text-muted small">${f.email||''}</span></td>
      <td class="d-none d-lg-table-cell">${mods.map(m=>`<span class="badge bg-light text-dark border me-1 mb-1">${m.nom}</span>`).join('')||'—'}</td>
      <td class="d-none d-lg-table-cell">${nbEt}</td>
      <td class="text-end">
        <button class="btn btn-sm btn-icon" onclick="viewFormateur('${f.id}')" title="Afficher"><i class="bi bi-eye"></i></button>
        <button class="btn btn-sm btn-icon" onclick="exportFicheFormateurPdf('${f.id}')" title="Exporter PDF"><i class="bi bi-file-earmark-pdf"></i></button>
        ${editable?`<button class="btn btn-sm btn-icon" onclick="editFormateur('${f.id}')" title="Modifier"><i class="bi bi-pencil"></i></button><button class="btn btn-sm btn-icon text-danger" onclick="askDelete('formateurs','${f.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>`:''}
      </td>
    </tr>`;
  }).join('') || `<tr><td colspan="6"><div class="empty-state"><i class="bi bi-person-workspace"></i><p>Aucun formateur</p></div></td></tr>`;
}
function resetFormateurPhotoBox(){
  document.getElementById('formateurPhotoInput').value='';
  document.getElementById('formateurPhotoData').value='';
  document.getElementById('formateurPhotoPreview').style.display='none';
  document.getElementById('formateurPhotoPreview').src='';
  document.getElementById('formateurPhotoPlaceholderIcon').style.display='block';
}
function setFormateurPhotoBox(dataUrl){
  document.getElementById('formateurPhotoData').value = dataUrl || '';
  const img = document.getElementById('formateurPhotoPreview');
  const icon = document.getElementById('formateurPhotoPlaceholderIcon');
  if(dataUrl){ img.src = dataUrl; img.style.display='block'; icon.style.display='none'; }
  else { img.style.display='none'; icon.style.display='block'; }
}
document.getElementById('formateurPhotoUploadBox').addEventListener('click', ()=> document.getElementById('formateurPhotoInput').click());
document.getElementById('formateurPhotoInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  setFormateurPhotoBox(URL.createObjectURL(file));
  document.getElementById('formateurPhotoData').value = '';
  const uploadPromise = uploadToCloudinary(file)
    .then(url => { document.getElementById('formateurPhotoData').value = url; })
    .catch(err => { console.error(err); toast("Échec de l'envoi de la photo — réessayez"); resetFormateurPhotoBox(); });
  trackPendingUpload('formateurPhotoData', uploadPromise);
});
document.getElementById('btnNewFormateur').addEventListener('click', ()=>{
  document.getElementById('formFormateur').reset();
  document.getElementById('formFormateur').elements['id'].value='';
  resetFormateurPhotoBox();
  document.getElementById('modalFormateurTitle').textContent='Nouveau formateur';
  new bootstrap.Modal(document.getElementById('modalFormateur')).show();
});
function editFormateur(id){
  const f = getFormateur(id);
  const form = document.getElementById('formFormateur');
  Object.keys(f).forEach(k=>{ if(form.elements[k]) form.elements[k].value = f[k]; });
  setFormateurPhotoBox(f.photo || '');
  document.getElementById('modalFormateurTitle').textContent='Modifier formateur';
  new bootstrap.Modal(document.getElementById('modalFormateur')).show();
}
function viewFormateur(id){
  const f = getFormateur(id);
  if(!f) return;
  const mods = modulesOfFormateur(f.id);
  const modIdsSet = mods.map(m=>m.id);
  const etudiantsSuivis = DB.etudiants.filter(e=>(e.moduleIds||[]).some(mid=>modIdsSet.includes(mid)));
  document.getElementById('ficheFormateurBody').innerHTML = `
    <div class="fiche-banner mb-3">
      ${ficheLogoBadgeHTML()}
      <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
          <div style="border-radius:50%;padding:3px;background:rgba(255,255,255,.18);flex-shrink:0;">${avatarHTML(f, 60)}</div>
          <div>
            <div class="fiche-name">${nomComplet(f)}</div>
            <div class="fiche-sub">${f.specialite||'—'}</div>
          </div>
        </div>
        <div class="d-flex gap-2 flex-wrap fiche-actions">
          ${f.telephone ? `<a class="btn btn-sm btn-outline-light" href="tel:${f.telephone}" title="Appeler"><i class="bi bi-telephone-fill"></i></a>` : ''}
          ${f.telephone ? `<a class="btn btn-sm btn-outline-light" href="${waLink(f.telephone)}" target="_blank" title="WhatsApp"><i class="bi bi-whatsapp"></i></a>` : ''}
          ${canEdit('formateurs') ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheFormateur')).hide(); editFormateur('${f.id}')" title="Modifier"><i class="bi bi-pencil"></i></button>` : ''}
          ${canEdit('formateurs') ? `<button class="btn btn-sm btn-outline-light" onclick="bootstrap.Modal.getInstance(document.getElementById('modalFicheFormateur')).hide(); askDelete('formateurs','${f.id}')" title="Supprimer"><i class="bi bi-trash"></i></button>` : ''}
          <button class="btn btn-sm btn-amber" onclick="exportFicheFormateurPdf('${f.id}')" title="Enregistrer en PDF"><i class="bi bi-file-earmark-pdf"></i> PDF</button>
        </div>
      </div>
    </div>
    <div class="fiche-section">
      <h6><i class="bi bi-person-vcard me-1"></i> Informations</h6>
      <div class="row g-2">
        <div class="col-6 fiche-field"><span class="fiche-label">Téléphone</span><span class="fiche-value">${f.telephone||'—'}</span></div>
        <div class="col-6 fiche-field"><span class="fiche-label">Email</span><span class="fiche-value">${f.email||'—'}</span></div>
        <div class="col-6 fiche-field"><span class="fiche-label">Date de démarrage</span><span class="fiche-value">${f.dateDebut?fmtDate(f.dateDebut):'—'}</span></div>
        <div class="col-6 fiche-field mb-0"><span class="fiche-label">Durée du contrat</span><span class="fiche-value">${f.dureeContrat||'—'}</span></div>
      </div>
    </div>
    <div class="fiche-section">
      <h6><i class="bi bi-collection-fill me-1"></i> Modules confiés</h6>
      ${mods.length ? `<div class="d-flex flex-wrap gap-2">${mods.map(m=>`<span class="badge bg-light text-dark border">${m.nom}</span>`).join('')}</div>` : '<p class="text-muted small mb-0">Aucun module confié pour le moment.</p>'}
    </div>
    ${(f.portfolio || f.cv) ? `<div class="fiche-section mb-0">
      <h6><i class="bi bi-briefcase-fill me-1"></i> Portfolio & CV</h6>
      ${f.portfolio ? `<div class="fiche-field"><span class="fiche-label">Portfolio</span><span class="fiche-value">${f.portfolio}</span></div>` : ''}
      ${f.cv ? `<a class="btn btn-sm btn-outline-secondary mt-1" href="${f.cv}" target="_blank" download="cv-${f.nom||'formateur'}"><i class="bi bi-file-earmark-person"></i> Voir le CV</a>` : ''}
    </div>` : ''}
  `;
  new bootstrap.Modal(document.getElementById('modalFicheFormateur')).show();
}
async function exportFicheFormateurPdf(id){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const f = getFormateur(id);
  if(!f) return;
  const mods = modulesOfFormateur(f.id);
  const M = 14, W = 182; // marge gauche & largeur utile de la page A4
  pdfHeader(doc, 'Fiche formateur', nomComplet(f), font);

  let y = 50;
  y = pdfSection(doc, M, y, W, 'Informations personnelles', [
    ['Spécialité', f.specialite||'—'],
    ['Téléphone', f.telephone||'—'],
    ['Email', f.email||'—'],
  ], font) + 6;

  y = pdfSection(doc, M, y, W, 'Contrat', [
    ['Date de démarrage', f.dateDebut?fmtDate(f.dateDebut):'—'],
    ['Durée du contrat', f.dureeContrat||'—'],
  ], font) + 6;

  y = pdfTextSection(doc, M, y, W, 'Modules confiés',
    mods.length ? mods.map(m=>m.nom).join('   •   ') : 'Aucun module confié pour le moment.',
    font);

  pdfFooter(doc, font);
  doc.save(`fiche-formateur-${(f.nom||'formateur').toLowerCase()}.pdf`);
}
document.getElementById('formFormateur').addEventListener('submit', async e=>{
  e.preventDefault();
  await resolvePendingUpload('formateurPhotoData');
  const data = Object.fromEntries(new FormData(e.target).entries());
  if(data.id){
    const idx = DB.formateurs.findIndex(x=>x.id===data.id);
    DB.formateurs[idx] = {...DB.formateurs[idx], ...data};
  } else { data.id = uid(); DB.formateurs.push(data); }
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalFormateur')).hide();
  toast('Formateur enregistré');
  populateAllSelects(); renderFormateurs();
});

/* ---------- PAIEMENTS ---------- */
/* ---------- Échéancier de paiement : affichage (menu Paiement / fiche étudiant) ---------- */
const statutEcheancierCls = {'Payé':'badge-statut-paye','À échoir':'badge-statut-partiel','En retard':'badge-statut-impaye','À venir':'badge-statut-avenir'};
function renderEcheancierCard(){
  const card = document.getElementById('cardEcheancier');
  const body = document.getElementById('echeancierBody');
  if(!card || !body) return;
  renderPaiementNotifBanner();
  if(state.role!=='etudiant'){ card.style.display='none'; return; }
  const u = currentUser();
  if(!u || !u.etudiantId){ card.style.display='none'; return; }
  const rows = computeEcheancier(u.etudiantId);
  if(!rows.length){
    card.style.display='none';
    return;
  }
  card.style.display='';
  body.innerHTML = `<div class="table-responsive"><table class="table table-sm align-middle mb-0">
    <thead><tr><th>Tranche</th><th>Montant</th><th>Payé</th><th>Reste</th><th>Date limite</th><th>Statut</th></tr></thead>
    <tbody>${rows.map(r=>`<tr>
      <td>${r.libelle}</td>
      <td>${fmtCFA(r.montant)}</td>
      <td class="text-success">${fmtCFA(r.paye)}</td>
      <td class="${r.reste>0?'text-danger fw-semibold':''}">${r.reste>0?fmtCFA(r.reste):'—'}</td>
      <td>${fmtDate(r.date)}</td>
      <td><span class="badge ${statutEcheancierCls[r.statut]}">${r.statut}</span></td>
    </tr>`).join('')}</tbody></table></div>`;
}
let currentEcheancierEtId = null;
function openEcheancierModal(etId){
  currentEcheancierEtId = etId;
  const et = getEtudiant(etId);
  document.getElementById('modalEcheancierTitle').textContent = `Échéancier de paiement — ${et?nomComplet(et):''}`;
  const rows = (et && et.echeancier) ? [...et.echeancier].sort((a,b)=>new Date(a.date)-new Date(b.date)) : [];
  const body = document.getElementById('echeancierFormRows');
  body.innerHTML='';
  if(rows.length){ rows.forEach(addEcheanceRow); } else { addEcheanceRow(); }
  updateEcheancierPctTotal();
  new bootstrap.Modal(document.getElementById('modalEcheancier')).show();
}
function addEcheanceRow(tr){
  tr = tr || {libelle:'', montant:'', date:''};
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><input class="form-control form-control-sm" data-f="libelle" value="${tr.libelle||''}" placeholder="Ex: Tranche 1"></td>
    <td><input type="number" min="0" step="1" class="form-control form-control-sm" data-f="montant" value="${tr.montant||''}"></td>
    <td><input type="date" class="form-control form-control-sm" data-f="date" value="${tr.date||''}"></td>
    <td class="text-end"><button type="button" class="btn btn-sm btn-icon text-danger" onclick="this.closest('tr').remove(); updateEcheancierPctTotal();"><i class="bi bi-trash"></i></button></td>`;
  row.querySelector('[data-f="montant"]').addEventListener('input', updateEcheancierPctTotal);
  document.getElementById('echeancierFormRows').appendChild(row);
}
document.getElementById('btnAddEcheanceRow').addEventListener('click', ()=>addEcheanceRow());
function updateEcheancierPctTotal(){
  const rows = [...document.querySelectorAll('#echeancierFormRows tr')];
  const total = rows.reduce((s,r)=> s + (Number(r.querySelector('[data-f="montant"]').value)||0), 0);
  const et = getEtudiant(currentEcheancierEtId);
  const fin = et ? etudiantFinance(et.id) : {total:0};
  const el = document.getElementById('echeancierPctTotal');
  el.innerHTML = `Total des tranches : <strong>${fmtCFA(total)}</strong> — Montant total dû par l'étudiant : <strong>${fmtCFA(fin.total)}</strong>${Math.abs(total-fin.total)>0.5?' <span class="text-danger">(les deux montants ne correspondent pas)</span>':' <span class="text-success">✓</span>'}`;
}
document.getElementById('btnSaveEcheancier').addEventListener('click', async ()=>{
  if(!currentEcheancierEtId) return;
  const rows = [...document.querySelectorAll('#echeancierFormRows tr')].map(r=>({
    id: uid(),
    libelle: r.querySelector('[data-f="libelle"]').value.trim(),
    montant: Number(r.querySelector('[data-f="montant"]').value)||0,
    date: r.querySelector('[data-f="date"]').value,
  })).filter(t=>t.libelle && t.date && t.montant>0);
  if(!rows.length){ toast("Ajoutez au moins une tranche complète (libellé, montant et date)"); return; }
  const et = getEtudiant(currentEcheancierEtId);
  if(!et) return;
  et.echeancier = rows;
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalEcheancier')).hide();
  toast("Échéancier de paiement enregistré");
  renderEcheancierCard();
  if(document.getElementById('paiementsBody')) renderPaiements();
  if(state.section==='dashboard') renderDashNotifBanner();
});

function renderPaiements(){
  renderEcheancierCard();
  const editable = canEdit('paiements');
  // La carte "État des paiements par étudiant" (vue globale multi-étudiants) n'a pas
  // lieu d'être dans le profil étudiant : on ne l'affiche que pour direction/comptabilité.
  document.getElementById('cardEtatPaiementsParEtudiant').style.display = state.role==='etudiant' ? 'none' : '';
  document.getElementById('btnNewPaiement').style.display = editable?'inline-block':'none';
  document.getElementById('btnExportFinancierPdf').style.display = state.role==='etudiant' ? 'none' : 'inline-block';
  const filterStatut = document.getElementById('filterStatutPaiement').value;
  const filterFil = document.getElementById('filterFilierePaiement').value;
  const filterStatutEt = document.getElementById('filterStatutEtudiantPaiement').value;
  const search = (document.getElementById('searchPaiement').value||'').toLowerCase();

  const scopedEt = scopeEtudiants(DB.etudiants);
  const finances = scopedEt.map(e=>({e, fin:etudiantFinance(e.id)}));
  const totalCollecte = finances.reduce((s,x)=>s+x.fin.paye,0);
  const totalDu = finances.reduce((s,x)=>s+x.fin.total,0);
  const totalReste = totalDu-totalCollecte;
  const impayesCount = finances.filter(x=>x.fin.statut==='Impayé').length;
  document.getElementById('statCardsPaiements').innerHTML = [
    {label: state.role==='etudiant' ? 'Total payé' : 'Total collecté', num:fmtCFA(totalCollecte), icon:'bi-cash-stack'},
    {label:'Reste à recouvrer', num:fmtCFA(Math.max(totalReste,0)), icon:'bi-hourglass-split'},
    {label: state.role==='etudiant' ? 'Statut' : 'Étudiants impayés', num: state.role==='etudiant' ? (finances[0]?.fin.statut||'—') : impayesCount, icon:'bi-exclamation-circle'},
  ].map(c=>`<div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="bi ${c.icon}"></i></div><div class="stat-num" style="font-size:1.3rem;">${c.num}</div><div class="stat-label">${c.label}</div></div></div>`).join('');

  let list = finances.filter(x=> !filterStatut || x.fin.statut===filterStatut)
    .filter(x=> !filterFil || x.e.filiereId===filterFil)
    .filter(x=> !filterStatutEt || x.e.statut===filterStatutEt)
    .filter(x=> nomComplet(x.e).toLowerCase().includes(search));
  list.sort((a,b)=>nomComplet(a.e).localeCompare(nomComplet(b.e),'fr',{sensitivity:'base'}));
  document.getElementById('paiementsBody').innerHTML = list.length ? list.map(x=>{
    const payCls = {'Payé':'badge-statut-paye','Partiel':'badge-statut-partiel','Impayé':'badge-statut-impaye'}[x.fin.statut];
    return `<tr>
      <td><div class="d-flex align-items-center gap-2"><div class="avatar-circ">${initials(x.e.prenom,x.e.nom)}</div>${nomComplet(x.e)}</div></td>
      <td class="d-none d-md-table-cell">${getFiliere(x.e.filiereId)?.nom||'—'}</td>
      <td class="d-none d-lg-table-cell">${fmtCFA(x.fin.total)}</td>
      <td class="d-none d-lg-table-cell text-success fw-semibold">${fmtCFA(x.fin.paye)}</td>
      <td class="text-danger fw-semibold">${fmtCFA(x.fin.reste)}</td>
      <td><span class="badge ${payCls}">${x.fin.statut}</span></td>
      <td class="text-end">${editable ? `<button class="btn btn-sm btn-outline-secondary" onclick="openEcheancierModal('${x.e.id}')"><i class="bi bi-calendar2-week"></i></button>` : ''}</td>
      <td class="text-end"><button class="btn btn-sm btn-outline-secondary" onclick="viewHistorique('${x.e.id}')"><i class="bi bi-clock-history"></i> Historique</button></td>
    </tr>`;
  }).join('') : `<tr><td colspan="8"><div class="empty-state"><i class="bi bi-cash"></i><p>Aucun résultat</p></div></td></tr>`;
}
document.getElementById('filterStatutPaiement').addEventListener('change', renderPaiements);
document.getElementById('filterFilierePaiement').addEventListener('change', renderPaiements);
document.getElementById('filterStatutEtudiantPaiement').addEventListener('change', renderPaiements);
document.getElementById('searchPaiement').addEventListener('input', renderPaiements);
document.getElementById('btnExportFinancierPdf').addEventListener('click', exportFinancierPdf);
// Indique si la modale Paiement a été ouverte depuis la modale Historique,
// pour savoir si on doit rouvrir l'Historique une fois la modale Paiement fermée.
let reopenHistoriqueAfterPaiement = false;
// Affiche/masque le champ de saisie libre quand "Autre" est choisi comme type de versement.
function toggleTypeAutreInput(){
  const sel = document.getElementById('selectTypePaiement');
  const input = document.getElementById('inputTypeAutreLibelle');
  const isAutre = sel.value === 'Autre';
  input.style.display = isAutre ? '' : 'none';
  input.required = isAutre;
  if(!isAutre) input.value = '';
}
document.getElementById('selectTypePaiement').addEventListener('change', toggleTypeAutreInput);
document.getElementById('btnNewPaiement').addEventListener('click', ()=>{
  reopenHistoriqueAfterPaiement = false;
  document.getElementById('formPaiement').reset();
  document.getElementById('editPaiementId').value = '';
  document.getElementById('modalPaiementTitle').textContent = 'Enregistrer un versement';
  document.getElementById('btnSubmitPaiement').textContent = 'Valider le versement';
  document.getElementById('selectEtudiantPaiement').disabled = false;
  document.getElementById('formPaiement').elements['date'].value = new Date().toISOString().slice(0,10);
  toggleTypeAutreInput();
  new bootstrap.Modal(document.getElementById('modalPaiement')).show();
});
// Modification d'un versement déjà enregistré (accès direction / comptabilité)
function editPaiement(id){
  const p = DB.paiements.find(x=>x.id===id);
  if(!p) return;
  // BUG CORRIGÉ : la modale #modalPaiement est déclarée AVANT #modalHistorique dans le HTML.
  // Ouvrir #modalPaiement par-dessus #modalHistorique sans fermer cette dernière la laissait
  // cachée derrière la fenêtre Historique (même z-index, ordre DOM défavorable) :
  // impossible de voir/atteindre le formulaire de modification. On ferme donc l'Historique
  // d'abord, et on le rouvrira automatiquement à la fermeture de la modale Paiement.
  const histModalEl = document.getElementById('modalHistorique');
  const histInstance = bootstrap.Modal.getInstance(histModalEl);
  reopenHistoriqueAfterPaiement = !!(histInstance && histModalEl.classList.contains('show'));
  if(histInstance) histInstance.hide();
  const f = document.getElementById('formPaiement');
  f.reset();
  document.getElementById('editPaiementId').value = p.id;
  f.elements['etudiantId'].value = p.etudiantId;
  f.elements['montant'].value = p.montant;
  f.elements['date'].value = p.date;
  f.elements['mode'].value = p.mode;
  // Types fixes du menu : si le type enregistré n'en fait pas partie, c'est un libellé "Autre"
  // saisi librement -> on sélectionne "Autre" et on remet le libellé dans le champ texte.
  const typesFixes = ["Frais d'inscription",'Tranche 1','Tranche 2','Tranche 3','Solde','Uniforme'];
  if(typesFixes.includes(p.type)){
    f.elements['type'].value = p.type;
    toggleTypeAutreInput();
  } else {
    f.elements['type'].value = 'Autre';
    toggleTypeAutreInput();
    document.getElementById('inputTypeAutreLibelle').value = p.type || '';
  }
  document.getElementById('selectEtudiantPaiement').disabled = true; // on ne change pas l'étudiant d'un versement existant
  document.getElementById('modalPaiementTitle').textContent = 'Modifier le versement';
  document.getElementById('btnSubmitPaiement').textContent = 'Enregistrer les modifications';
  new bootstrap.Modal(document.getElementById('modalPaiement')).show();
}
// Quelle que soit la façon dont la modale Paiement se ferme (validation, Annuler, croix),
// on rouvre l'Historique si c'est de là qu'on venait.
document.getElementById('modalPaiement').addEventListener('hidden.bs.modal', ()=>{
  document.getElementById('selectEtudiantPaiement').disabled = false;
  if(reopenHistoriqueAfterPaiement && currentHistoriqueEtId){
    reopenHistoriqueAfterPaiement = false;
    viewHistorique(currentHistoriqueEtId);
  }
});
document.getElementById('formPaiement').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  // "Tranche X"/"Solde" = versements liés au coût de la formation (pris en compte pour l'échéancier
  // et le reste à payer). "Frais d'inscription"/"Uniforme"/"Autre" sont des frais annexes, jamais
  // additionnés au coût de la formation pour ces calculs.
  const estFormation = TYPES_PAIEMENT_FORMATION.includes(data.type);
  const typeFinal = (data.type === 'Autre') ? (data.typeAutreLibelle||'Autre').trim() : data.type;
  delete data.typeAutreLibelle;
  data.type = typeFinal;
  data.estFormation = estFormation;
  const editId = document.getElementById('editPaiementId').value;
  if(editId){
    const p = DB.paiements.find(x=>x.id===editId);
    if(p){ p.montant = data.montant; p.date = data.date; p.mode = data.mode; p.type = data.type; p.estFormation = data.estFormation; }
  } else {
    data.id = uid();
    DB.paiements.push(data);
  }
  await saveDB();
  document.getElementById('selectEtudiantPaiement').disabled = false;
  bootstrap.Modal.getInstance(document.getElementById('modalPaiement')).hide();
  toast(editId ? 'Versement modifié' : 'Versement enregistré');
  renderPaiements();
  renderHistoriquePeriode();
  // La réouverture de l'Historique (si on venait de là) est gérée par l'écouteur
  // 'hidden.bs.modal' ci-dessus, une fois que la modale Paiement est complètement fermée
  // (évite de superposer à nouveau les deux fenêtres pendant l'animation de fermeture).
});
let currentHistoriqueEtId = null;
function viewHistorique(etId){
  currentHistoriqueEtId = etId;
  const e = getEtudiant(etId);
  const fin = etudiantFinance(etId);
  const editable = canEdit('paiements');
  const payCls = {'Payé':'badge-statut-paye','Partiel':'badge-statut-partiel','Impayé':'badge-statut-impaye'}[fin.statut];
  document.getElementById('modalHistoriqueTitle').textContent = `État de paiement — ${e?nomComplet(e):''}`;
  const list = DB.paiements.filter(p=>p.etudiantId===etId).sort((a,b)=>new Date(b.date)-new Date(a.date));
  document.getElementById('historiqueBody').innerHTML = `
    <div class="row g-2 mb-3">
      <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="font-size:1rem;">${fmtCFA(fin.total)}</div><div class="stat-label">Montant dû</div></div></div>
      <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="font-size:1rem;color:#1C7A46;">${fmtCFA(fin.paye)}</div><div class="stat-label">Payé</div></div></div>
      <div class="col-4"><div class="fiche-mini-stat"><div class="stat-num" style="font-size:1rem;color:#B03327;">${fmtCFA(fin.reste)}</div><div class="stat-label">Reste</div></div></div>
    </div>
    <div class="d-flex align-items-center justify-content-between mb-2">
      <span class="fw-semibold small text-muted">Historique des versements</span>
      <span class="badge ${payCls}">${fin.statut}</span>
    </div>
    ${list.length ? `
    <ul class="list-group list-group-flush">${list.map(p=>`
      <li class="list-group-item d-flex justify-content-between align-items-center px-0">
        <div><div class="fw-semibold small">${p.type}</div><div class="text-muted" style="font-size:.75rem;">${fmtDate(p.date)} · ${p.mode}</div></div>
        <div class="d-flex align-items-center gap-2">
          <span class="fw-bold">${fmtCFA(p.montant)}</span>
          ${editable ? `<button class="btn btn-sm btn-icon" onclick="editPaiement('${p.id}')" title="Modifier ce versement"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-icon text-danger" onclick="askDelete('paiements','${p.id}')" title="Supprimer ce versement"><i class="bi bi-trash"></i></button>` : ''}
        </div>
      </li>`).join('')}</ul>` : `<div class="empty-state"><i class="bi bi-receipt"></i><p>Aucun versement</p></div>`}
  `;
  new bootstrap.Modal(document.getElementById('modalHistorique')).show();
}
document.getElementById('btnExportHistoriqueEtudiantPdf').addEventListener('click', ()=>{
  if(currentHistoriqueEtId) exportHistoriqueEtudiantPdf(currentHistoriqueEtId);
});
async function exportHistoriqueEtudiantPdf(etId){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const e = getEtudiant(etId);
  const fin = etudiantFinance(etId);
  const fil = e ? getFiliere(e.filiereId) : null;
  const list = DB.paiements.filter(p=>p.etudiantId===etId).sort((a,b)=>new Date(a.date)-new Date(b.date));
  const M = 14, W = 182;
  pdfHeader(doc, 'État de paiement', `${e?nomComplet(e):''} — ${e?.matricule||''}${fil?' — '+fil.nom:''}`, font);
  let y = pdfStatsSection(doc, M, 50, W, 'État financier', [
    {label:'Montant dû', value:fmtCFA(fin.total), color:[22,35,63]},
    {label:'Payé', value:fmtCFA(fin.paye), color:[28,122,70]},
    {label:'Reste à payer', value:fmtCFA(fin.reste), color:[176,51,39]},
    {label:'Statut', value:fin.statut, color:[22,35,63]},
  ], font) + 6;
  doc.autoTable({
    startY: y,
    head: [['Date','Type','Mode','Montant']],
    body: list.map(p=>[fmtDate(p.date), p.type||'—', p.mode||'—', fmtCFA(p.montant)]),
    foot: [['','','Total payé', fmtCFA(fin.paye)]],
    styles:{font},
    headStyles:{fillColor:[22,35,63], textColor:255, fontSize:9, font},
    bodyStyles:{fontSize:8.5, font},
    alternateRowStyles:{fillColor:[245,246,248]},
    footStyles:{fillColor:[240,240,240], textColor:[20,20,20], fontStyle:'bold', font},
  });
  pdfFooter(doc, font);
  doc.save(`etat-paiement-${(e?.matricule||'etudiant')}.pdf`);
}

/* ---------- EVALUATIONS ---------- */
function renderEvaluations(){
  const editable = canEdit('evaluations');
  document.getElementById('btnNewEvaluation').style.display = editable?'inline-block':'none';
  // Côté étudiant : la colonne "Étudiant" (c'est toujours lui) et "Actions" (non éditable) sont inutiles.
  const isEtudiantView = state.role==='etudiant';
  document.getElementById('thEvalEtudiant').style.display = isEtudiantView ? 'none' : '';
  document.getElementById('thEvalActions').style.display = isEtudiantView ? 'none' : '';
  const filFilter = document.getElementById('filterFiliereEval').value;
  let base = DB.evaluations;
  if(state.role==='etudiant'){
    const u = currentUser();
    base = base.filter(ev=>u && ev.etudiantId===u.etudiantId);
  } else {
    base = scopeByFiliereId(base);
  }
  let list = base.filter(ev=> !filFilter || ev.filiereId===filFilter);
  const evalMoyenneBanner = document.getElementById('evalMoyenneBanner');
  if(state.role==='etudiant'){
    // moyenne générale calculée sur toutes mes évaluations, indépendamment du filtre filière sélectionné
    const moy = base.length ? (base.reduce((s,ev)=>s+Number(ev.note),0)/base.length).toFixed(1) : '—';
    document.getElementById('evalMoyenneValue').textContent = moy;
    evalMoyenneBanner.classList.remove('d-none'); evalMoyenneBanner.classList.add('d-flex');
  } else {
    evalMoyenneBanner.classList.add('d-none'); evalMoyenneBanner.classList.remove('d-flex');
  }
  document.getElementById('evaluationsBody').innerHTML = list.length ? list.map(ev=>{
    const et = getEtudiant(ev.etudiantId);
    const noteCls = ev.note>=14 ? 'note-good' : ev.note>=10 ? 'note-avg' : 'note-bad';
    return `<tr>
      ${isEtudiantView ? '' : `<td>${nomComplet(et)}</td>`}
      <td class="d-none d-md-table-cell">${getFiliere(ev.filiereId)?.nom||'—'}</td>
      <td>${ev.module}</td>
      <td class="d-none d-md-table-cell">${ev.formateurId ? nomComplet(getFormateur(ev.formateurId)) : (ev.formateurNom || '—')}</td>
      <td><span class="note-pill ${noteCls}">${ev.note}/20</span></td>
      <td class="d-none d-lg-table-cell">${ev.appreciation||'—'}</td>
      <td class="d-none d-lg-table-cell">${fmtDate(ev.date)}</td>
      ${isEtudiantView ? '' : `<td class="text-end">${editable ? `<button class="btn btn-sm btn-icon" onclick="editEvaluation('${ev.id}')" title="Modifier la note"><i class="bi bi-pencil"></i></button>
      <button class="btn btn-sm btn-icon text-danger" onclick="askDelete('evaluations','${ev.id}')" title="Supprimer la note"><i class="bi bi-trash"></i></button>` : ''}</td>`}
    </tr>`;
  }).join('') : `<tr><td colspan="${isEtudiantView?6:8}"><div class="empty-state"><i class="bi bi-clipboard-x"></i><p>Aucune évaluation</p></div></td></tr>`;
}
/* Modification ou suppression d'une note déjà enregistrée (accès direction) */
function editEvaluation(id){
  const ev = DB.evaluations.find(x=>x.id===id);
  if(!ev) return;
  const et = getEtudiant(ev.etudiantId);
  document.getElementById('editEvalId').value = ev.id;
  document.getElementById('editEvalEtudiantNom').textContent = nomComplet(et)+' — '+ev.module;
  document.getElementById('editEvalNote').value = ev.note;
  document.getElementById('editEvalAppreciation').value = ev.appreciation||'';
  new bootstrap.Modal(document.getElementById('modalEditEvaluation')).show();
}
document.getElementById('formEditEvaluation').addEventListener('submit', async e=>{
  e.preventDefault();
  const id = document.getElementById('editEvalId').value;
  const ev = DB.evaluations.find(x=>x.id===id);
  if(!ev){ return; }
  ev.note = document.getElementById('editEvalNote').value;
  ev.appreciation = document.getElementById('editEvalAppreciation').value;
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalEditEvaluation')).hide();
  toast('Note modifiée');
  renderEvaluations();
});
document.getElementById('filterFiliereEval').addEventListener('change', renderEvaluations);

/* Saisie groupée : la liste des étudiants (actifs uniquement pour le formateur) de la filière
   sélectionnée s'affiche avec un champ note par étudiant, au lieu de saisir une évaluation à la fois. */
function renderEvalBulkRows(){
  const filiereId = document.getElementById('evalBulkFiliere').value;
  const list = scopeEtudiants(DB.etudiants).filter(e=>e.filiereId===filiereId)
    .sort((a,b)=>nomComplet(a).localeCompare(nomComplet(b),'fr',{sensitivity:'base'}));
  document.getElementById('evalBulkRows').innerHTML = list.length ? list.map(e=>`
    <tr>
      <td><div class="d-flex align-items-center gap-2">${avatarHTML(e,28,'square')}<span>${nomComplet(e)}</span></div></td>
      <td><input type="number" min="0" max="20" step="0.5" class="form-control form-control-sm eval-bulk-note" data-etudiant-id="${e.id}" placeholder="—"></td>
      <td><input type="text" class="form-control form-control-sm eval-bulk-appreciation" data-etudiant-id="${e.id}" placeholder="Appréciation (optionnel)"></td>
    </tr>`).join('') : `<tr><td colspan="3" class="text-center text-muted py-3">Aucun étudiant actif dans cette filière</td></tr>`;
}
document.getElementById('evalBulkFiliere').addEventListener('change', renderEvalBulkRows);
document.getElementById('btnNewEvaluation').addEventListener('click', ()=>{
  document.getElementById('formEvaluation').reset();
  document.getElementById('evalBulkDate').value = new Date().toISOString().slice(0,10);
  renderEvalBulkRows();
  new bootstrap.Modal(document.getElementById('modalEvaluation')).show();
});
document.getElementById('formEvaluation').addEventListener('submit', async e=>{
  e.preventDefault();
  const filiereId = document.getElementById('evalBulkFiliere').value;
  const module = document.getElementById('evalBulkModule').value;
  const formateurId = document.getElementById('evalBulkFormateur').value;
  const date = document.getElementById('evalBulkDate').value;
  const noteInputs = [...document.querySelectorAll('#evalBulkRows .eval-bulk-note')];
  let count = 0;
  noteInputs.forEach(inp=>{
    if(inp.value===''||inp.value===null) return;
    const etudiantId = inp.dataset.etudiantId;
    const appreciation = document.querySelector(`.eval-bulk-appreciation[data-etudiant-id="${etudiantId}"]`)?.value || '';
    DB.evaluations.push({ id:uid(), etudiantId, filiereId, module, formateurId, note:inp.value, appreciation, date });
    count++;
  });
  if(count===0){ toast('Aucune note saisie'); return; }
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalEvaluation')).hide();
  toast(count+' évaluation(s) enregistrée(s)');
  renderEvaluations();
});

/* ---------- RAPPORTS DE CHANTIER ---------- */
// Grille d'appréciation officielle (Fiche de rapport journalier ANADENCE CITY) :
// le formateur note chaque critère, la note finale de l'étudiant = moyenne des appréciations.
const APPRECIATION_CRITERES = [
  'Ponctualité et assiduité (respect des horaires)',
  'Équipements de protection individuel',
  'Motivation pour le travail',
  'Respect des consignes données',
  'Connaissances professionnelles',
  'Connaissances des équipements utilisés',
  "Capacité d'adaptation",
  'Rapidité et Dynamisme',
  'Qualité des travaux effectués',
  'Comportements, relation avec les autres',
];
const APPRECIATION_NIVEAUX = ['EXCE','SATIS','INSU','T-INSU'];
const APPRECIATION_BAREME = { EXCE:19, SATIS:15, INSU:10, 'T-INSU':7 };
const APPRECIATION_LABELS = { EXCE:'Excellent (19)', SATIS:'Satisfaisant (15)', INSU:'Insuffisant (10)', 'T-INSU':'Très insuffisant (7)' };
// Délai laissé à l'étudiant pour finaliser son rapport une fois le chantier initié par le formateur/la direction.
const RAPPORT_DEADLINE_MS = 72 * 60 * 60 * 1000;
const RAPPORT_MAX_IMAGES = 5;

function canValidateRapport(r){
  if(state.role==='direction') return true;
  if(state.role==='formateur'){
    const u = currentUser();
    if(!(u && u.formateurId)) return false;
    const ids = scopedFiliereIds();
    return ids ? ids.includes(r.filiereId) : true;
  }
  return false;
}
function apprGridHTML(rapportId, etudiantId){
  return `
    <div class="d-flex flex-column gap-2 mb-2">
      ${APPRECIATION_CRITERES.map((c,i)=>`
        <div class="row g-2 align-items-center">
          <div class="col-8 col-md-9 small">${c}</div>
          <div class="col-4 col-md-3">
            <select class="form-select form-select-sm appr-select" id="apprRow_${rapportId}_${etudiantId}_${i}">
              <option value="">—</option>
              ${APPRECIATION_NIVEAUX.map(n=>`<option value="${n}">${n}</option>`).join('')}
            </select>
          </div>
        </div>`).join('')}
    </div>
    <div class="text-muted mb-2" style="font-size:.74rem;">Barème : EXCE = 19 · SATIS = 15 · INSU = 10 · T-INSU = 7 — la note finale de l'étudiant est la moyenne des ${APPRECIATION_CRITERES.length} appréciations ci-dessus.</div>`;
}
function fmtPeriodeRapport(r){
  if(r.dateDebut && r.dateFin && r.dateDebut !== r.dateFin) return `${fmtDate(r.dateDebut)} → ${fmtDate(r.dateFin)}`;
  return fmtDate(r.dateDebut || r.dateFin || r.date);
}
function getParticipant(r, etudiantId){
  return (r.participants||[]).find(p=>p.etudiantId===etudiantId);
}
function creerParticipant(etudiantId, participation, motif){
  const p = {
    etudiantId, participation, motif: motif||'',
    soumis:false, dateSoumission:null,
    description:'', incidents:'', recommandations:'',
    fichePhoto:null, photosEtudiant:[],
    appreciationsDetail:null, note:null, appreciationRapport:'',
    locked:false, lockReason:null, evalPushed:false,
    dateValidation:null, valideParId:null,
    correctionDemandee:false, motifCorrection:'', dateDemandeCorrection:null,
  };
  if(participation==='non' && !motif){
    p.note = 0; p.locked = true; p.lockReason = 'non-sans-motif';
    p.dateValidation = new Date().toISOString().slice(0,10);
  }
  return p;
}
// Pousse une note finale (auto ou validée) dans le registre des évaluations, une seule fois par participant.
function pushEvaluationForParticipant(r, p){
  if(p.evalPushed) return;
  DB.evaluations.push({
    id:uid(), etudiantId:p.etudiantId, filiereId:r.filiereId,
    module:'Rapport de chantier — '+r.titre, formateurId:r.formateurId, formateurNom:r.formateurNom,
    note:p.note, appreciation:p.appreciationRapport||'', date:p.dateValidation||new Date().toISOString().slice(0,10)
  });
  p.evalPushed = true;
}
// Vérifie les délais de 72h : tout participant "oui" non finalisé après le délai bascule automatiquement à la note 0 et se verrouille.
function applyAutoExpirations(){
  let changed = false;
  (DB.rapports||[]).forEach(r=>{
    if(!r.dateCreation) return;
    const deadlinePassed = (Date.now() - new Date(r.dateCreation).getTime()) > RAPPORT_DEADLINE_MS;
    if(!deadlinePassed) return;
    (r.participants||[]).forEach(p=>{
      // Un participant à qui une correction a été demandée ne doit pas basculer automatiquement à 0 :
      // il dispose du temps nécessaire pour corriger, la validation reste manuelle.
      if(p.participation==='oui' && !p.soumis && !p.locked && !p.correctionDemandee){
        p.note = 0; p.locked = true; p.lockReason = 'expire';
        p.dateValidation = new Date().toISOString().slice(0,10);
        pushEvaluationForParticipant(r, p);
        changed = true;
      }
    });
  });
  return changed;
}
function participantStatus(r, p){
  if(p.participation==='non'){
    if(p.motif) return {code:'dispense', label:'Dispensé (motif fourni)', cls:'secondary'};
    return {code:'non-sans-motif', label:'Non-participation sans motif — Note 0/19', cls:'danger'};
  }
  if(p.locked && p.lockReason==='expire') return {code:'expire', label:'Délai de 72h dépassé — Note 0/19', cls:'danger'};
  if(p.locked && p.lockReason==='valide') return {code:'valide', label:'Rapport validé — Note '+p.note+'/19', cls:'success'};
  if(p.correctionDemandee) return {code:'correction', label:'Correction demandée — en attente de l\'étudiant', cls:'danger'};
  if(p.soumis) return {code:'attente', label:'Rapport soumis — en attente de validation', cls:'warning'};
  return {code:'a-remplir', label:'À compléter par l\'étudiant', cls:'info'};
}
function deadlineRemainingHTML(r){
  if(!r.dateCreation) return '';
  const remaining = RAPPORT_DEADLINE_MS - (Date.now() - new Date(r.dateCreation).getTime());
  if(remaining <= 0) return `<span class="text-danger">Délai de 72h dépassé</span>`;
  const h = Math.floor(remaining/3600000);
  return `Il vous reste environ <strong>${h} heure(s)</strong> pour finaliser ce rapport avant l'attribution automatique de la note 0.`;
}
// Le chantier entier ne peut être supprimé/modifié par un formateur qu'avant toute validation formelle par un responsable.
function canDeleteChantier(r){
  if(!canEdit('rapports')) return false;
  if(state.role==='direction') return true;
  if(state.role==='etudiant') return false;
  return !(r.participants||[]).some(p=>p.lockReason==='valide');
}
function renderRapports(){
  if(applyAutoExpirations()) saveDB();
  renderNav();
  const editable = canEdit('rapports');
  document.getElementById('btnNewRapport').style.display = (editable && state.role!=='etudiant')?'inline-block':'none';
  let list = scopeByFiliereId([...DB.rapports]);
  if(state.role==='etudiant'){
    const u = currentUser();
    list = list.filter(r=>u && getParticipant(r, u.etudiantId));
  }
  list.sort((a,b)=>new Date(b.dateDebut||b.date)-new Date(a.dateDebut||a.date));
  document.getElementById('rapportsGrid').innerHTML = list.length ? list.map(r=>
    state.role==='etudiant' ? rapportCardEtudiantHTML(r) : rapportCardAdminHTML(r)
  ).join('') : `<div class="col-12"><div class="empty-state"><i class="bi bi-clipboard"></i><p>Aucun rapport de chantier</p></div></div>`;
}
function rapportHeaderHTML(r){
  return `
    <div class="d-flex justify-content-between align-items-start mb-2">
      <span class="tag">${getFiliere(r.filiereId)?.nom||'—'}</span>
      <span class="text-muted small">${fmtPeriodeRapport(r)}</span>
    </div>
    <h6 class="fw-bold">${r.titre}</h6>
    <div class="small text-muted mb-2"><i class="bi bi-geo-alt"></i> ${r.lieu||'—'} · <i class="bi bi-person-badge"></i> ${r.formateurNom || nomComplet(getFormateur(r.formateurId))}</div>`;
}
// Identifiants des chantiers actuellement "dépliés" (détails + participants visibles) dans la vue admin/formateur/secrétariat.
// Repliés par défaut pour rester compact en plein écran comme sur mobile.
const expandedChantiers = new Set();
function toggleChantier(id){
  if(expandedChantiers.has(id)) expandedChantiers.delete(id); else expandedChantiers.add(id);
  renderRapports();
}
// Identifiants "rapportId__etudiantId" des participants dont le détail du rapport est actuellement déplié
// dans la vue admin/formateur. Repliés par défaut : le formateur ne voit d'abord que la liste des étudiants
// avec leur statut, et clique sur "Afficher" devant un nom pour voir le détail du rapport et le noter.
const expandedParticipants = new Set();
function toggleParticipantDetail(rapportId, etudiantId){
  const key = rapportId+'__'+etudiantId;
  if(expandedParticipants.has(key)) expandedParticipants.delete(key); else expandedParticipants.add(key);
  renderRapports();
}
// Vue direction / secrétariat / formateur : liste des chantiers avec le récapitulatif de chaque participant.
function rapportCardAdminHTML(r){
  const expanded = expandedChantiers.has(r.id);
  const participants = r.participants||[];
  const canDelete = canDeleteChantier(r);
  const rows = participants.map(p=>{
    const et = getEtudiant(p.etudiantId);
    const st = participantStatus(r, p);
    const pKey = r.id+'__'+p.etudiantId;
    const pExpanded = expandedParticipants.has(pKey);
    let gradeBlock = '';
    if(st.code==='attente' && canValidateRapport(r)){
      gradeBlock = `
        <div class="border rounded p-2 mt-2" style="background:#F8F9FB;">
          <div class="fw-semibold small mb-2"><i class="bi bi-clipboard-check me-1"></i> Appréciations du responsable</div>
          ${apprGridHTML(r.id, p.etudiantId)}
          <label class="form-label small mb-1">Commentaire (optionnel)</label>
          <input type="text" class="form-control form-control-sm" id="rapportAppr_${r.id}_${p.etudiantId}" placeholder="Optionnel">
          <div class="d-flex gap-2 flex-wrap mt-2">
            <button class="btn btn-amber btn-sm" onclick="validerParticipantRapport('${r.id}','${p.etudiantId}')"><i class="bi bi-check2-circle"></i> Noter et valider</button>
            <button class="btn btn-outline-danger btn-sm" onclick="openDemandeCorrectionModal('${r.id}','${p.etudiantId}')"><i class="bi bi-arrow-repeat"></i> Demander une correction</button>
          </div>
        </div>`;
    } else if(st.code==='correction' && canValidateRapport(r)){
      gradeBlock = `
        <div class="alert alert-danger py-2 px-3 small mt-2 mb-0"><i class="bi bi-hourglass-split me-1"></i> En attente de la correction par l'étudiant${p.motifCorrection?' — motif : '+p.motifCorrection:''}</div>`;
    }
    const photosFiche = p.fichePhoto ? `<img src="${p.fichePhoto}" style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--border);cursor:pointer;" onclick="window.open('${p.fichePhoto}','_blank')">` : '';
    const photosSite = (p.photosEtudiant||[]).map(ph=>`<img src="${ph}" style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--border);cursor:pointer;" onclick="window.open('${ph}','_blank')">`).join('');
    const resetBtn = (state.role==='direction' && (p.soumis || p.locked || p.correctionDemandee)) ? `<button class="btn btn-outline-secondary btn-sm" title="Réinitialiser (Direction)" onclick="resetParticipantDirection('${r.id}','${p.etudiantId}')"><i class="bi bi-arrow-counterclockwise"></i></button>` : '';
    // Détail du rapport de cet étudiant : masqué tant que le formateur n'a pas cliqué sur "Afficher" devant son nom.
    const detailHTML = `
        ${p.participation==='non' && p.motif ? `<div class="small text-muted mt-1"><strong>Motif :</strong> ${p.motif}</div>` : ''}
        ${p.description ? `<div class="small mt-2"><strong>Travaux :</strong> ${p.description}</div>` : ''}
        ${p.incidents ? `<div class="small text-muted"><strong>Observations :</strong> ${p.incidents}</div>` : ''}
        ${p.appreciationRapport ? `<div class="small text-muted"><strong>Commentaire :</strong> ${p.appreciationRapport}</div>` : ''}
        ${(photosFiche||photosSite) ? `<div class="d-flex flex-wrap gap-2 mt-2">${photosFiche}${photosSite}</div>` : ''}
        <div class="mt-2">
          <button class="btn btn-outline-secondary btn-sm" onclick="exportRapportPdf('${r.id}','${p.etudiantId}')" title="PDF de ce rapport"><i class="bi bi-file-earmark-pdf"></i> PDF</button>
          ${resetBtn}
        </div>
        ${gradeBlock}`;
    return `
      <div class="border rounded p-2 mb-2">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-1">
          <div class="d-flex align-items-center gap-2">${avatarHTML(et,28,'square')}<span class="small fw-semibold">${nomComplet(et)}</span></div>
          <div class="d-flex align-items-center gap-2">
            <span class="badge bg-${st.cls}">${st.label}</span>
            <button class="btn btn-outline-secondary btn-sm" onclick="toggleParticipantDetail('${r.id}','${p.etudiantId}')">
              <i class="bi bi-${pExpanded?'eye-slash':'eye'}"></i> ${pExpanded?'Masquer':'Afficher'}
            </button>
          </div>
        </div>
        ${pExpanded ? detailHTML : ''}
      </div>`;
  }).join('');
  const toggleBtn = `<button class="btn btn-outline-secondary btn-sm" onclick="toggleChantier('${r.id}')">
    <i class="bi bi-${expanded?'eye-slash':'eye'}"></i> ${expanded?'Masquer':'Afficher'}
  </button>`;
  const detailBlock = expanded ? `
        <div class="small text-muted mb-2"><i class="bi bi-geo-alt"></i> ${r.lieu||'—'} · <i class="bi bi-person-badge"></i> ${r.formateurNom || nomComplet(getFormateur(r.formateurId))}</div>
        <div class="small text-muted mb-2"><i class="bi bi-people"></i> ${participants.length} étudiant(s) concerné(s)</div>
        ${r.auteurNom?`<div class="text-muted mb-2" style="font-size:.74rem;">Chantier initié par ${r.auteurNom}</div>`:''}
        ${rows || '<div class="empty-state py-3"><p class="mb-0 small">Aucun étudiant sélectionné</p></div>'}
        <div class="d-flex gap-2 flex-wrap mt-1">
          ${canDelete ? `<button class="btn btn-outline-danger btn-sm" onclick="askDelete('rapports','${r.id}')"><i class="bi bi-trash"></i> Supprimer le chantier</button>` : ''}
        </div>` : '';
  return `
    <div class="col-md-6">
      <div class="chantier-card h-100">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <span class="tag">${getFiliere(r.filiereId)?.nom||'—'}</span>
          <span class="text-muted small">${fmtPeriodeRapport(r)}</span>
        </div>
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <h6 class="fw-bold mb-0">${r.titre}</h6>
          ${toggleBtn}
        </div>
        ${detailBlock}
      </div>
    </div>`;
}
// Vue étudiant : uniquement sa propre participation à chaque chantier.
// Repliée par défaut (comme les cartes admin) : on ne voit que la période du chantier
// et le bouton "Afficher". Un clic déplie la carte et révèle le détail + l'action
// à mener (Compléter / Corriger le rapport), ou simplement le résultat (En attente
// de validation / Validé) quand aucune action n'est requise côté étudiant.
function rapportCardEtudiantHTML(r){
  const u = currentUser();
  const p = getParticipant(r, u.etudiantId);
  if(!p) return '';
  const st = participantStatus(r, p);
  const expanded = expandedChantiers.has(r.id);

  // Bandeau visible même repliée : la carte reste "muette" tant qu'aucune action/résultat
  // n'existe (état "à compléter"), et affiche sinon un résumé immédiat (notification de
  // correction avec son bouton, "En attente de validation", ou "Validé").
  let collapsedExtra = '';
  if(st.code==='correction'){
    collapsedExtra = `
      <div class="alert alert-danger py-2 px-3 small mt-2 mb-0">
        <div class="fw-semibold mb-2"><i class="bi bi-exclamation-triangle-fill me-1"></i> Le formateur demande une correction</div>
        <button class="btn btn-amber btn-sm" onclick="openRapportEtudiantModal('${r.id}')"><i class="bi bi-pencil-square"></i> Corriger le rapport</button>
      </div>`;
  } else if(st.code==='attente'){
    collapsedExtra = `<div class="small text-muted mt-2"><i class="bi bi-hourglass-split me-1"></i> En attente de validation</div>`;
  } else if(st.code==='valide'){
    collapsedExtra = `<div class="small text-success fw-semibold mt-2"><i class="bi bi-check-circle-fill me-1"></i> Validé</div>`;
  } else if(st.code==='dispense' || st.code==='non-sans-motif' || st.code==='expire'){
    collapsedExtra = `<div class="mt-2"><span class="badge bg-${st.cls}">${st.label}</span></div>`;
  }
  // st.code==='a-remplir' -> rien de plus tant que la carte est repliée.

  let detailBody = '';
  if(expanded){
    const lieuFormateur = `<div class="small text-muted mb-2"><i class="bi bi-geo-alt"></i> ${r.lieu||'—'} · <i class="bi bi-person-badge"></i> ${r.formateurNom || nomComplet(getFormateur(r.formateurId))}</div>`;
    if(st.code==='dispense'){
      detailBody = `<div class="alert alert-secondary py-2 px-3 small mb-0"><i class="bi bi-slash-circle me-1"></i> Vous n'avez pas participé à ce chantier — Motif : ${p.motif} — aucune note attribuée.</div>`;
    } else if(st.code==='non-sans-motif'){
      detailBody = `<div class="alert alert-danger py-2 px-3 small mb-0"><i class="bi bi-x-circle me-1"></i> Non-participation enregistrée sans motif — Note : 0/19.</div>`;
    } else if(st.code==='expire'){
      detailBody = `<div class="alert alert-danger py-2 px-3 small mb-0"><i class="bi bi-hourglass-bottom me-1"></i> Le délai de 72h pour finaliser ce rapport est dépassé — Note : 0/19.</div>`;
    } else if(st.code==='a-remplir'){
      detailBody = `
        ${lieuFormateur}
        <div class="alert alert-info py-2 px-3 small">${deadlineRemainingHTML(r)}</div>
        <button class="btn btn-amber btn-sm" onclick="openRapportEtudiantModal('${r.id}')"><i class="bi bi-pencil-square"></i> Compléter le rapport</button>`;
    } else if(st.code==='correction'){
      detailBody = `
        ${lieuFormateur}
        <div class="alert alert-danger py-2 px-3 small mb-2">
          <div class="fw-semibold mb-1"><i class="bi bi-exclamation-triangle-fill me-1"></i> Le formateur demande une correction</div>
          ${p.motifCorrection ? `<div>${p.motifCorrection}</div>` : ''}
        </div>
        <button class="btn btn-amber btn-sm" onclick="openRapportEtudiantModal('${r.id}')"><i class="bi bi-pencil-square"></i> Corriger le rapport</button>`;
    } else if(st.code==='attente'){
      detailBody = `
        ${lieuFormateur}
        <div class="small text-muted mb-2"><i class="bi bi-hourglass-split me-1"></i> Rapport soumis le ${fmtDate(p.dateSoumission)} — en attente de validation par le formateur.</div>
        ${p.description ? `<div class="small mb-2"><strong>Travaux :</strong> ${p.description}</div>` : ''}
        <button class="btn btn-outline-secondary btn-sm" onclick="openRapportEtudiantModal('${r.id}', true)"><i class="bi bi-eye"></i> Voir le rapport complet</button>`;
    } else if(st.code==='valide'){
      const detail = Array.isArray(p.appreciationsDetail) ? p.appreciationsDetail : [];
      const counts = {};
      detail.forEach(a=>{ counts[a.niveau] = (counts[a.niveau]||0)+1; });
      const summary = APPRECIATION_NIVEAUX.filter(n=>counts[n]).map(n=>`${counts[n]} ${n}`).join(' · ');
      detailBody = `
        ${lieuFormateur}
        <div class="alert alert-success py-2 px-3 small mb-2">
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-1"><span><i class="bi bi-check-circle-fill me-1"></i> Rapport validé</span><strong>Note : ${p.note}/19</strong></div>
          ${summary ? `<div class="text-muted mt-1" style="font-size:.76rem;">${summary}</div>` : ''}
        </div>
        ${p.appreciationRapport ? `<div class="small text-muted mb-2"><strong>Commentaire :</strong> ${p.appreciationRapport}</div>` : ''}
        <button class="btn btn-outline-secondary btn-sm" onclick="openRapportEtudiantModal('${r.id}', true)"><i class="bi bi-eye"></i> Voir le rapport complet</button>`;
    }
    detailBody += `
      <div class="d-flex gap-2 flex-wrap mt-2">
        <button class="btn btn-outline-secondary btn-sm" onclick="exportRapportPdf('${r.id}','${u.etudiantId}')"><i class="bi bi-file-earmark-pdf"></i> Télécharger le PDF</button>
      </div>`;
  }

  const toggleBtn = `<button class="btn btn-outline-secondary btn-sm" onclick="toggleChantier('${r.id}')">
    <i class="bi bi-${expanded?'eye-slash':'eye'}"></i> ${expanded?'Masquer':'Afficher'}
  </button>`;

  return `
    <div class="col-md-6">
      <div class="chantier-card h-100">
        <div class="d-flex justify-content-between align-items-start mb-2">
          <span class="tag">${getFiliere(r.filiereId)?.nom||'—'}</span>
          <span class="text-muted small">${fmtPeriodeRapport(r)}</span>
        </div>
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <h6 class="fw-bold mb-0">${r.titre}</h6>
          ${toggleBtn}
        </div>
        ${!expanded ? collapsedExtra : ''}
        ${expanded ? `<div class="mt-2">${detailBody}</div>` : ''}
      </div>
    </div>`;
}
async function validerParticipantRapport(rapportId, etudiantId){
  const r = DB.rapports.find(x=>x.id===rapportId);
  const p = r && getParticipant(r, etudiantId);
  if(!r || !p || !canValidateRapport(r)) return;
  const detail = [];
  for(let i=0;i<APPRECIATION_CRITERES.length;i++){
    const sel = document.getElementById(`apprRow_${rapportId}_${etudiantId}_${i}`);
    if(!sel || !sel.value){ toast('Veuillez évaluer chaque critère avant de valider'); return; }
    detail.push({ critere: APPRECIATION_CRITERES[i], niveau: sel.value });
  }
  const moyenne = detail.reduce((s,a)=>s+APPRECIATION_BAREME[a.niveau],0)/detail.length;
  const apprInput = document.getElementById(`rapportAppr_${rapportId}_${etudiantId}`);
  p.appreciationsDetail = detail;
  p.note = Math.round(moyenne*10)/10;
  p.appreciationRapport = apprInput ? (apprInput.value||'') : '';
  p.locked = true;
  p.lockReason = 'valide';
  p.dateValidation = new Date().toISOString().slice(0,10);
  p.valideParId = state.userId;
  pushEvaluationForParticipant(r, p);
  await saveDB();
  toast('Rapport validé — note calculée : '+p.note+'/19');
  renderRapports();
  if(document.getElementById('panel-evaluations').classList.contains('active')) renderEvaluations();
}
// Réinitialisation réservée à la direction : seule la direction peut rouvrir un rapport verrouillé.
async function resetParticipantDirection(rapportId, etudiantId){
  if(state.role!=='direction') return;
  const r = DB.rapports.find(x=>x.id===rapportId);
  const p = r && getParticipant(r, etudiantId);
  if(!r || !p) return;
  Object.assign(p, {
    soumis:false, dateSoumission:null, description:'', incidents:'', recommandations:'',
    fichePhoto:null, photosEtudiant:[], appreciationsDetail:null, note: p.participation==='non' && !p.motif ? 0 : null,
    appreciationRapport:'', locked: p.participation==='non' && !p.motif, lockReason: p.participation==='non' && !p.motif ? 'non-sans-motif' : null,
    evalPushed:false, dateValidation:null, valideParId:null,
    correctionDemandee:false, motifCorrection:'', dateDemandeCorrection:null,
  });
  DB.evaluations = DB.evaluations.filter(ev=>!(ev.etudiantId===etudiantId && ev.module==='Rapport de chantier — '+r.titre));
  await saveDB();
  toast('Rapport réinitialisé par la direction');
  renderRapports();
}
function populateChantierParticipantsBody(){
  const fid = document.getElementById('selectFiliereRapport').value;
  const students = DB.etudiants.filter(e=>e.filiereId===fid && e.statut==='actif').sort((a,b)=>nomComplet(a).localeCompare(nomComplet(b),'fr',{sensitivity:'base'}));
  document.getElementById('chantierParticipantsBody').innerHTML = students.length ? students.map(e=>`
    <tr data-student="${e.id}">
      <td><div class="d-flex align-items-center gap-2">${avatarHTML(e,28,'square')}${nomComplet(e)}</div></td>
      <td>
        <div class="btn-group btn-group-sm chantier-toggle" role="group">
          <button type="button" class="btn btn-success" data-val="oui">Oui</button>
          <button type="button" class="btn btn-outline-danger" data-val="non">Non</button>
        </div>
      </td>
      <td><input type="text" class="form-control form-control-sm chantier-motif" style="display:none;max-width:220px;" placeholder="Motif (optionnel)"></td>
    </tr>`).join('') : `<tr><td colspan="3"><div class="empty-state"><i class="bi bi-people"></i><p>Aucun étudiant actif dans cette filière</p></div></td></tr>`;
  document.querySelectorAll('.chantier-toggle').forEach(grp=>{
    grp.querySelectorAll('button').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        grp.querySelectorAll('button').forEach(b=>{ b.className = 'btn ' + (b.dataset.val==='oui'?'btn-outline-success':'btn-outline-danger'); });
        btn.className = 'btn ' + (btn.dataset.val==='oui'?'btn-success':'btn-danger');
        const motifInput = grp.closest('tr').querySelector('.chantier-motif');
        motifInput.style.display = btn.dataset.val==='non' ? 'inline-block' : 'none';
        if(btn.dataset.val==='oui') motifInput.value = '';
      });
    });
  });
}
document.getElementById('btnNewRapport').addEventListener('click', ()=>{
  document.getElementById('formRapport').reset();
  document.getElementById('formRapport').elements['dateDebut'].value = new Date().toISOString().slice(0,10);
  document.getElementById('formRapport').elements['dateFin'].value = new Date().toISOString().slice(0,10);
  populateChantierParticipantsBody();
  new bootstrap.Modal(document.getElementById('modalRapport')).show();
});
document.getElementById('selectFiliereRapport').addEventListener('change', populateChantierParticipantsBody);
document.getElementById('formRapport').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  if(data.dateDebut && data.dateFin && data.dateFin < data.dateDebut){
    toast('La date de fin doit être postérieure ou égale à la date de début');
    return;
  }
  data.id = uid();
  data.auteurId = state.userId;
  data.auteurNom = state.userName;
  data.dateCreation = new Date().toISOString();
  data.participants = [];
  document.querySelectorAll('#chantierParticipantsBody tr[data-student]').forEach(row=>{
    const etudiantId = row.dataset.student;
    const activeBtn = row.querySelector('.chantier-toggle .btn-success, .chantier-toggle .btn-danger');
    const participation = activeBtn ? activeBtn.dataset.val : 'oui';
    const motif = participation==='non' ? (row.querySelector('.chantier-motif').value||'') : '';
    data.participants.push(creerParticipant(etudiantId, participation, motif));
  });
  if(!data.participants.length){ toast('Aucun étudiant actif trouvé dans cette filière'); return; }
  DB.rapports.push(data);
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalRapport')).hide();
  toast('Chantier créé — les étudiants participants doivent compléter leur rapport');
  renderRapports();
});

/* ---- Complétion du rapport côté étudiant ---- */
const RE_MAX_SITE_PHOTOS = 5;
// readonly=true -> mode "Afficher" (rapport soumis en attente de validation, ou déjà validé) : formulaire verrouillé, pas de soumission possible.
function openRapportEtudiantModal(rapportId, readonly){
  const r = DB.rapports.find(x=>x.id===rapportId);
  const u = currentUser();
  const p = r && u && getParticipant(r, u.etudiantId);
  if(!r || !p) return;
  const form = document.getElementById('formRapportEtudiant');
  form.reset();
  form.dataset.readonly = readonly ? '1' : '';
  document.getElementById('rapportEtudiantRapportId').value = rapportId;
  // En cas de correction demandée, on repart des données déjà saisies par l'étudiant plutôt que d'un formulaire vide.
  document.getElementById('reDescription').value = p.description || '';
  document.getElementById('reIncidents').value = p.incidents || '';
  document.getElementById('reRecommandations').value = p.recommandations || '';
  const deadlineEl = document.getElementById('rapportEtudiantDeadlineInfo');
  const titleEl = document.getElementById('modalRapportEtudiantTitle');
  const submitBtn = document.getElementById('btnSoumettreRapportEtudiant');
  const cancelBtn = document.getElementById('btnAnnulerRapportEtudiant');
  const fieldIds = ['reDescription','reIncidents','reRecommandations','reFichePhotoInput','reSitePhotosInput'];
  fieldIds.forEach(id=>{ const el = document.getElementById(id); if(el) el.disabled = !!readonly; });
  submitBtn.style.display = readonly ? 'none' : '';
  cancelBtn.textContent = readonly ? 'Fermer' : 'Annuler';
  if(readonly){
    titleEl.textContent = 'Rapport de chantier';
    if(p.lockReason==='valide'){
      deadlineEl.className = 'alert alert-success py-2 px-3 small';
      deadlineEl.innerHTML = `<div class="fw-semibold mb-1"><i class="bi bi-check-circle-fill me-1"></i> Rapport validé — Note : ${p.note}/19</div>${p.appreciationRapport ? `<div>${p.appreciationRapport}</div>` : ''}`;
    } else {
      deadlineEl.className = 'alert alert-warning py-2 px-3 small';
      deadlineEl.innerHTML = `<i class="bi bi-hourglass-split me-1"></i> Rapport soumis le ${fmtDate(p.dateSoumission)} — en attente de validation par le formateur.`;
    }
  } else {
    titleEl.textContent = p.correctionDemandee ? 'Corriger le rapport de chantier' : 'Compléter le rapport de chantier';
    if(p.correctionDemandee){
      deadlineEl.className = 'alert alert-danger py-2 px-3 small';
      deadlineEl.innerHTML = `<div class="fw-semibold mb-1"><i class="bi bi-exclamation-triangle-fill me-1"></i> Correction demandée par le formateur</div>${p.motifCorrection ? `<div>${p.motifCorrection}</div>` : ''}`;
    } else {
      deadlineEl.className = 'alert alert-warning py-2 px-3 small';
      deadlineEl.innerHTML = deadlineRemainingHTML(r);
    }
  }
  document.getElementById('btnSoumettreRapportEtudiant').textContent = p.correctionDemandee ? 'Renvoyer le rapport corrigé' : 'Soumettre le rapport';
  document.getElementById('reFichePhotoPreview').innerHTML = p.fichePhoto ? `<img src="${p.fichePhoto}" style="width:64px;height:64px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">` : '';
  document.getElementById('reSitePhotosPreview').innerHTML = (p.photosEtudiant||[]).map(ph=>`<img src="${ph}" style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">`).join('');
  document.getElementById('reSitePhotosCount').textContent = '';
  new bootstrap.Modal(document.getElementById('modalRapportEtudiant')).show();
}
// Ouvre la fenêtre permettant au formateur/à la direction de demander une correction à l'étudiant sur un rapport soumis.
function openDemandeCorrectionModal(rapportId, etudiantId){
  const r = DB.rapports.find(x=>x.id===rapportId);
  if(!r || !canValidateRapport(r)) return;
  document.getElementById('drRapportId').value = rapportId;
  document.getElementById('drEtudiantId').value = etudiantId;
  document.getElementById('drMotif').value = '';
  new bootstrap.Modal(document.getElementById('modalDemandeCorrection')).show();
}
document.getElementById('btnConfirmDemandeCorrection').addEventListener('click', async ()=>{
  const rapportId = document.getElementById('drRapportId').value;
  const etudiantId = document.getElementById('drEtudiantId').value;
  const motif = document.getElementById('drMotif').value.trim();
  const r = DB.rapports.find(x=>x.id===rapportId);
  const p = r && getParticipant(r, etudiantId);
  if(!r || !p || !canValidateRapport(r)) return;
  if(!motif){ toast('Merci de préciser ce que l\'étudiant doit corriger'); return; }
  p.correctionDemandee = true;
  p.motifCorrection = motif;
  p.dateDemandeCorrection = new Date().toISOString().slice(0,10);
  p.soumis = false;
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalDemandeCorrection')).hide();
  toast("Correction demandée — l'étudiant est notifié");
  renderRapports();
});
document.getElementById('reFichePhotoInput').addEventListener('change', e=>{
  const preview = document.getElementById('reFichePhotoPreview');
  preview.innerHTML = '';
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ev=>{
    const img = document.createElement('img');
    img.src = ev.target.result;
    img.style.cssText = 'width:64px;height:64px;object-fit:cover;border-radius:8px;border:1px solid var(--border);';
    preview.appendChild(img);
  };
  reader.readAsDataURL(file);
});
document.getElementById('reSitePhotosInput').addEventListener('change', e=>{
  const preview = document.getElementById('reSitePhotosPreview');
  const countEl = document.getElementById('reSitePhotosCount');
  preview.innerHTML = '';
  let files = [...e.target.files];
  if(files.length > RE_MAX_SITE_PHOTOS){
    toast(`Maximum ${RE_MAX_SITE_PHOTOS} photos — seules les ${RE_MAX_SITE_PHOTOS} premières ont été gardées`);
    const dt = new DataTransfer();
    files.slice(0, RE_MAX_SITE_PHOTOS).forEach(f=>dt.items.add(f));
    e.target.files = dt.files;
    files = [...e.target.files];
  }
  countEl.textContent = files.length ? `${files.length}/${RE_MAX_SITE_PHOTOS} photo(s) — ${files.length<2?'au moins 2 photos sont recommandées':'merci !'}` : '';
  files.forEach(file=>{
    const reader = new FileReader();
    reader.onload = ev=>{
      const img = document.createElement('img');
      img.src = ev.target.result;
      img.style.cssText = 'width:56px;height:56px;object-fit:cover;border-radius:8px;border:1px solid var(--border);';
      preview.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
});
document.getElementById('formRapportEtudiant').addEventListener('submit', async e=>{
  e.preventDefault();
  if(e.target.dataset.readonly==='1') return; // Mode "Afficher" : aucune soumission possible.
  const rapportId = document.getElementById('rapportEtudiantRapportId').value;
  const r = DB.rapports.find(x=>x.id===rapportId);
  const u = currentUser();
  const p = r && u && getParticipant(r, u.etudiantId);
  if(!r || !p){ toast('Rapport introuvable'); return; }
  if(p.locked || p.soumis){ toast("Ce rapport n'est plus modifiable"); return; }
  // Le délai de 72h ne s'applique qu'à la toute première soumission ; une correction demandée reste possible ensuite.
  if(!p.correctionDemandee && (Date.now() - new Date(r.dateCreation).getTime()) > RAPPORT_DEADLINE_MS){
    toast('Le délai de 72h est dépassé pour ce rapport');
    renderRapports();
    bootstrap.Modal.getInstance(document.getElementById('modalRapportEtudiant')).hide();
    return;
  }
  p.description = document.getElementById('reDescription').value;
  p.incidents = document.getElementById('reIncidents').value;
  p.recommandations = document.getElementById('reRecommandations').value;
  const ficheFile = document.getElementById('reFichePhotoInput').files[0];
  if(ficheFile){
    try{
      p.fichePhoto = await uploadToCloudinary(ficheFile);
    }catch(err){
      console.error(err);
      toast("Échec de l'envoi de la photo de fiche — réessayez");
      return;
    }
  }
  const siteFiles = [...document.getElementById('reSitePhotosInput').files].slice(0, RE_MAX_SITE_PHOTOS);
  if(siteFiles.length){
    try{
      p.photosEtudiant = await Promise.all(siteFiles.map(file => uploadToCloudinary(file)));
    }catch(err){
      console.error(err);
      toast("Échec de l'envoi des photos de chantier — réessayez");
      return;
    }
  }
  const etaitCorrection = p.correctionDemandee;
  p.soumis = true;
  p.dateSoumission = new Date().toISOString().slice(0,10);
  p.correctionDemandee = false;
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalRapportEtudiant')).hide();
  toast(etaitCorrection ? 'Rapport corrigé renvoyé — en attente de validation par le formateur' : 'Rapport soumis — en attente de validation par le formateur');
  renderRapports();
});

/* ---------- PRESENCES ---------- */
function renderPresences(){
  const manage = canEdit('presences');
  document.getElementById('presenceAppelCard').style.display = manage ? '' : 'none';
  document.getElementById('presenceListCard').style.display = manage ? '' : 'none';
  if(manage) populatePresenceList();
  renderPresenceHistory();
}
document.getElementById('presenceDate').value = new Date().toISOString().slice(0,10);
const MOTIFS_ABSENCE = ['Avec permission','Sans permission','Malade','Deuil','Autre'];
function populatePresenceList(){
  const mid = document.getElementById('presenceModule').value;
  const date = document.getElementById('presenceDate').value;
  const students = DB.etudiants.filter(e=>(e.moduleIds||[]).includes(mid) && e.statut==='actif').sort((a,b)=>nomComplet(a).localeCompare(nomComplet(b),'fr',{sensitivity:'base'}));
  document.getElementById('presenceListBody').innerHTML = students.length ? students.map(e=>{
    const existing = DB.presences.find(p=>p.etudiantId===e.id && p.moduleId===mid && p.date===date);
    const statut = existing ? existing.statut : 'present';
    const motif = existing ? (existing.motif||'') : '';
    return `<tr data-student="${e.id}">
      <td><div class="d-flex align-items-center gap-2">${avatarHTML(e,30,'square')}${nomComplet(e)}</div></td>
      <td>
        <div class="btn-group btn-group-sm presence-toggle" role="group">
          <button type="button" class="btn ${statut==='present'?'btn-success':'btn-outline-success'}" data-val="present">Présent</button>
          <button type="button" class="btn ${statut==='retard'?'btn-warning':'btn-outline-warning'}" data-val="retard">Retard</button>
          <button type="button" class="btn ${statut==='absent'?'btn-danger':'btn-outline-danger'}" data-val="absent">Absent</button>
        </div>
      </td>
      <td>
        <select class="form-select form-select-sm presence-motif" style="display:${statut==='present'?'none':'inline-block'};max-width:170px;">
          <option value="">Motif...</option>
          ${MOTIFS_ABSENCE.map(m=>`<option value="${m}" ${motif===m?'selected':''}>${m}</option>`).join('')}
        </select>
      </td>
    </tr>`;
  }).join('') : `<tr><td colspan="3"><div class="empty-state"><i class="bi bi-people"></i><p>Aucun étudiant actif inscrit à ce module</p></div></td></tr>`;
  document.querySelectorAll('.presence-toggle').forEach(grp=>{
    grp.querySelectorAll('button').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        grp.querySelectorAll('button').forEach(b=>{
          b.className = 'btn ' + (b.dataset.val==='present'?'btn-outline-success':b.dataset.val==='retard'?'btn-outline-warning':'btn-outline-danger');
        });
        btn.className = 'btn ' + (btn.dataset.val==='present'?'btn-success':btn.dataset.val==='retard'?'btn-warning':'btn-danger');
        const motifSelect = grp.closest('tr').querySelector('.presence-motif');
        motifSelect.style.display = btn.dataset.val==='present' ? 'none' : 'inline-block';
        if(btn.dataset.val==='present') motifSelect.value = '';
      });
    });
  });
}
document.getElementById('presenceModule').addEventListener('change', populatePresenceList);
document.getElementById('presenceDate').addEventListener('change', populatePresenceList);
document.getElementById('btnSavePresence').addEventListener('click', async ()=>{
  const mid = document.getElementById('presenceModule').value;
  const date = document.getElementById('presenceDate').value;
  if(!mid || !date){ toast('Sélectionnez un module et une date'); return; }
  document.querySelectorAll('#presenceListBody tr[data-student]').forEach(row=>{
    const etudiantId = row.dataset.student;
    const activeBtn = row.querySelector('.presence-toggle .btn-success, .presence-toggle .btn-warning, .presence-toggle .btn-danger');
    const statut = activeBtn ? activeBtn.dataset.val : 'present';
    const motif = statut!=='present' ? (row.querySelector('.presence-motif').value || '') : '';
    const idx = DB.presences.findIndex(p=>p.etudiantId===etudiantId && p.moduleId===mid && p.date===date);
    const record = {id: idx>=0?DB.presences[idx].id:uid(), etudiantId, moduleId:mid, date, statut, motif, formateurId: state.role==='formateur'?state.userId:null};
    if(idx>=0) DB.presences[idx] = record; else DB.presences.push(record);
  });
  await saveDB();
  toast("Appel enregistré");
  renderPresenceHistory();
});
document.getElementById('presenceHistFrom').addEventListener('change', renderPresenceHistory);
document.getElementById('presenceHistTo').addEventListener('change', renderPresenceHistory);
document.getElementById('presenceHistModule').addEventListener('change', renderPresenceHistory);
function filteredPresenceHistory(){
  const from = document.getElementById('presenceHistFrom').value;
  const to = document.getElementById('presenceHistTo').value;
  const modFilter = document.getElementById('presenceHistModule').value;
  let list = scopeByModuleId([...DB.presences]);
  if(state.role==='etudiant'){
    const u = currentUser();
    list = list.filter(p=>u && p.etudiantId===u.etudiantId);
  }
  if(modFilter) list = list.filter(p=>p.moduleId===modFilter);
  if(from) list = list.filter(p=>p.date>=from);
  if(to) list = list.filter(p=>p.date<=to);
  list.sort((a,b)=> b.date.localeCompare(a.date));
  return list;
}
function renderPresenceHistory(){
  const list = filteredPresenceHistory();
  const manage = canEdit('presences');
  const isEtudiantView = state.role==='etudiant';
  document.getElementById('thPresEtudiant').style.display = isEtudiantView ? 'none' : '';
  document.getElementById('thPresActions').style.display = isEtudiantView ? 'none' : '';

  // résumé de la période
  const total = list.length;
  const present = list.filter(p=>p.statut==='present').length;
  const retard = list.filter(p=>p.statut==='retard').length;
  const absent = list.filter(p=>p.statut==='absent').length;
  const taux = total>0 ? Math.round((present/total)*100) : 0;
  document.getElementById('presenceStatsRow').innerHTML = [
    {label:'Présences', num:present, icon:'bi-check-circle', color:'#1C7A46'},
    {label:'Retards', num:retard, icon:'bi-clock-history', color:'#B4700B'},
    {label:'Absences', num:absent, icon:'bi-x-circle', color:'#B03327'},
    {label:'Taux de présence', num:taux+'%', icon:'bi-graph-up', color:'#16233F'},
  ].map(c=>`<div class="col-6 col-lg-3"><div class="stat-card"><div class="stat-icon"><i class="bi ${c.icon}"></i></div><div class="stat-num" style="font-size:1.3rem;color:${c.color};">${c.num}</div><div class="stat-label">${c.label}</div></div></div>`).join('');

  document.getElementById('presenceHistoryBody').innerHTML = list.length ? list.slice(0,300).map(p=>{
    const cls = {present:'badge-statut-actif',retard:'badge-statut-partiel',absent:'badge-statut-abandon'}[p.statut];
    return `<tr>
      <td>${fmtDate(p.date)}</td>
      <td class="d-none d-md-table-cell">${getModule(p.moduleId)?.nom||'—'}</td>
      ${isEtudiantView ? '' : `<td>${nomComplet(getEtudiant(p.etudiantId))}</td>`}
      <td><span class="badge ${cls}">${p.statut}</span></td>
      <td class="d-none d-lg-table-cell text-muted small">${p.motif||'—'}</td>
      ${isEtudiantView ? '' : `<td class="text-end">${manage ? `<button class="btn btn-sm btn-icon" onclick="editerAppelSession('${p.moduleId}','${p.date}')" title="Modifier l'appel de ce jour"><i class="bi bi-pencil"></i></button>
      <button class="btn btn-sm btn-icon text-danger" onclick="askDelete('presences','${p.id}')" title="Supprimer cette présence"><i class="bi bi-trash"></i></button>` : ''}</td>`}
    </tr>`;
  }).join('') : `<tr><td colspan="${isEtudiantView?4:6}"><div class="empty-state"><i class="bi bi-calendar-x"></i><p>Aucun appel enregistré pour cette période</p></div></td></tr>`;

  renderAppelsSessions(list, manage);
}
/* Vue groupée par séance d'appel (module + date), pour modifier ou supprimer un appel entier en un clic */
function renderAppelsSessions(list, manage){
  const card = document.getElementById('appelsSessionsCard');
  card.style.display = manage ? '' : 'none';
  if(!manage) return;
  const groups = {};
  list.forEach(p=>{
    const key = p.moduleId+'|'+p.date;
    if(!groups[key]) groups[key] = {moduleId:p.moduleId, date:p.date, total:0, present:0};
    groups[key].total++;
    if(p.statut==='present') groups[key].present++;
  });
  const sessions = Object.values(groups).sort((a,b)=> b.date.localeCompare(a.date));
  document.getElementById('appelsSessionsBody').innerHTML = sessions.length ? sessions.map(s=>{
    const tauxSession = s.total>0 ? Math.round((s.present/s.total)*100) : 0;
    return `<tr>
      <td>${fmtDate(s.date)}</td>
      <td>${getModule(s.moduleId)?.nom||'—'}</td>
      <td>${s.total}</td>
      <td class="d-none d-md-table-cell">${tauxSession}%</td>
      <td class="text-end">
        <button class="btn btn-sm btn-icon" onclick="editerAppelSession('${s.moduleId}','${s.date}')" title="Modifier cet appel"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-icon text-danger" onclick="askDeletePresenceSession('${s.moduleId}','${s.date}')" title="Supprimer cet appel"><i class="bi bi-trash"></i></button>
      </td>
    </tr>`;
  }).join('') : `<tr><td colspan="5"><div class="empty-state"><i class="bi bi-calendar-x"></i><p>Aucun appel enregistré pour cette période</p></div></td></tr>`;
}
/* Charge un appel existant (module + date) dans le formulaire d'appel pour le modifier */
function editerAppelSession(moduleId, date){
  document.getElementById('presenceModule').value = moduleId;
  document.getElementById('presenceDate').value = date;
  populatePresenceList();
  document.getElementById('presenceAppelCard').scrollIntoView({behavior:'smooth', block:'start'});
}
/* Supprime tous les enregistrements de présence d'un appel (un module, une date) */
function askDeletePresenceSession(moduleId, date){
  pendingDelete = {collection:'presences-session', moduleId, date};
  new bootstrap.Modal(document.getElementById('modalConfirm')).show();
}
/* Supprime tous les appels correspondant à la période/filière actuellement filtrée */
function askDeletePresencePeriode(){
  const list = filteredPresenceHistory();
  if(!list.length){ toast('Aucun appel à supprimer pour cette période'); return; }
  pendingDelete = {collection:'presences-periode', ids: list.map(p=>p.id)};
  new bootstrap.Modal(document.getElementById('modalConfirm')).show();
}
document.getElementById('btnDeleteAppelsPeriode').addEventListener('click', askDeletePresencePeriode);
async function exportPresenceRapportPdf(){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const font = await ensurePdfFont(doc);
  const M = 14, W = 182;
  const from = document.getElementById('presenceHistFrom').value;
  const to = document.getElementById('presenceHistTo').value;
  const modFilter = document.getElementById('presenceHistModule').value;
  const list = filteredPresenceHistory();

  const total = list.length;
  const present = list.filter(p=>p.statut==='present').length;
  const retard = list.filter(p=>p.statut==='retard').length;
  const absent = list.filter(p=>p.statut==='absent').length;
  const taux = total>0 ? Math.round((present/total)*100) : 0;

  const periodeLabel = (from||to) ? `Période du ${from?fmtDate(from):'—'} au ${to?fmtDate(to):'—'}` : 'Toutes périodes';
  const moduleLabel = modFilter ? getModule(modFilter)?.nom||'' : 'Tous les modules';
  pdfHeader(doc, 'Rapport de présence', `${periodeLabel} — ${moduleLabel} — ${total} appel(s)`, font);

  let y = pdfStatsSection(doc, M, 50, W, 'Récapitulatif', [
    {label:'Présences', value:present, color:[28,122,70]},
    {label:'Retards', value:retard, color:[180,112,11]},
    {label:'Absences', value:absent, color:[176,51,39]},
    {label:'Taux présence', value:taux+'%', color:[22,35,63]},
  ], font) + 6;

  if(y > 265){ doc.addPage(); y = 20; }
  doc.autoTable({
    startY: y,
    head: [['Date','Module','Étudiant','Statut','Motif']],
    body: list.map(p=>[
      fmtDate(p.date),
      getModule(p.moduleId)?.nom||'—',
      nomComplet(getEtudiant(p.etudiantId)),
      {present:'Présent',retard:'Retard',absent:'Absent'}[p.statut]||p.statut,
      p.motif||'—',
    ]),
    styles:{font},
    headStyles:{fillColor:[22,35,63], textColor:255, fontSize:9, font},
    bodyStyles:{fontSize:8.5, font},
    alternateRowStyles:{fillColor:[245,246,248]},
  });

  pdfFooter(doc, font);
  doc.save(`rapport-presence-${(from||'debut')}-au-${(to||'fin')}.pdf`);
}
document.getElementById('btnExportPresencePdf').addEventListener('click', exportPresenceRapportPdf);

/* ---------- DOCUMENTS ---------- */
// Types de pièces qui composent le dossier administratif numérique de l'étudiant
// (constitué par la direction / le secrétariat au fil de l'inscription et du parcours).
const DOCUMENT_TYPES = ["Copie acte de naissance","Carte d'identité / CIP","Photo d'identité","Fiche d'inscription","Contrat de formation","Diplôme / Bulletin","Attestation","Certificat médical","Fiche de retard","Fiche d'absence","Autre"];
// Petit code couleur pour repérer vite les pièces administratives clés (identité / inscription / contrat)
// des autres justificatifs (médical, retard, absence...).
function documentBadgeClass(type){
  if(["Copie acte de naissance","Carte d'identité / CIP","Photo d'identité"].includes(type)) return 'bg-info-subtle text-info-emphasis border-0';
  if(["Fiche d'inscription","Contrat de formation"].includes(type)) return 'bg-warning-subtle text-warning-emphasis border-0';
  if(type==='Diplôme / Bulletin' || type==='Attestation') return 'bg-success-subtle text-success-emphasis border-0';
  return 'bg-light text-dark border';
}
function scopedDocumentsBase(){
  let base = DB.documents;
  if(state.role==='etudiant'){
    const u = currentUser();
    base = base.filter(d=>u && d.etudiantId===u.etudiantId);
  } else {
    const ids = scopedFiliereIds();
    if(ids){ const etIds = DB.etudiants.filter(e=>ids.includes(e.filiereId)).map(e=>e.id); base = base.filter(d=>etIds.includes(d.etudiantId)); }
  }
  return base;
}
function renderDocuments(){
  const editable = canEdit('documents');
  document.getElementById('btnNewDocument').style.display = editable?'inline-block':'none';
  let base = scopedDocumentsBase();

  // Filtres : étudiant concerné, type de pièce, recherche libre (nom du document ou de l'étudiant)
  const selEtudiant = document.getElementById('filterEtudiantDocument');
  const etudiantsVisibles = [...new Set(base.map(d=>d.etudiantId))].map(getEtudiant).filter(Boolean).sort((a,b)=>nomComplet(a).localeCompare(nomComplet(b)));
  const currentEtudiantFilter = selEtudiant.value;
  selEtudiant.innerHTML = `<option value="">Tous les étudiants</option>` + etudiantsVisibles.map(e=>`<option value="${e.id}">${nomComplet(e)}</option>`).join('');
  selEtudiant.value = etudiantsVisibles.some(e=>e.id===currentEtudiantFilter) ? currentEtudiantFilter : '';

  const selType = document.getElementById('filterTypeDocument');
  const currentTypeFilter = selType.value;
  selType.innerHTML = `<option value="">Tous les types</option>` + DOCUMENT_TYPES.map(t=>`<option value="${t}">${t}</option>`).join('');
  selType.value = currentTypeFilter;

  const search = (document.getElementById('searchDocument').value||'').toLowerCase();
  if(selEtudiant.value) base = base.filter(d=>d.etudiantId===selEtudiant.value);
  if(selType.value) base = base.filter(d=>d.type===selType.value);
  if(search) base = base.filter(d=> d.nom.toLowerCase().includes(search) || nomComplet(getEtudiant(d.etudiantId)).toLowerCase().includes(search));

  const list = [...base].sort((a,b)=>new Date(b.date)-new Date(a.date));
  document.getElementById('documentsCountBadge').textContent = list.length;
  document.getElementById('documentsBody').innerHTML = list.length ? list.map(d=>`
    <tr>
      <td>${nomComplet(getEtudiant(d.etudiantId))}</td>
      <td>${d.nom}</td>
      <td class="d-none d-md-table-cell"><span class="badge ${documentBadgeClass(d.type)}">${d.type}</span></td>
      <td class="d-none d-lg-table-cell">${fmtDate(d.date)}</td>
      <td class="text-end">
        ${d.fichier ? `<a class="btn btn-sm btn-outline-secondary" href="${d.fichier}" target="_blank" download="${d.nom}"><i class="bi bi-download"></i></a>` : ''}
        ${editable ? `<button class="btn btn-sm btn-icon text-danger" onclick="askDelete('documents','${d.id}')"><i class="bi bi-trash"></i></button>` : ''}
      </td>
    </tr>`).join('') : `<tr><td colspan="5"><div class="empty-state"><i class="bi bi-folder2-open"></i><p>Aucune pièce enregistrée</p></div></td></tr>`;
}
document.getElementById('searchDocument').addEventListener('input', renderDocuments);
document.getElementById('filterEtudiantDocument').addEventListener('change', renderDocuments);
document.getElementById('filterTypeDocument').addEventListener('change', renderDocuments);
document.getElementById('btnNewDocument').addEventListener('click', ()=>{
  document.getElementById('formDocument').reset();
  document.getElementById('documentFileInput').value='';
  document.getElementById('formDocument').elements['date'].value = new Date().toISOString().slice(0,10);
  // Si un filtre étudiant est actif dans la liste, on le pré-sélectionne dans le formulaire d'ajout
  const filtre = document.getElementById('filterEtudiantDocument').value;
  if(filtre) document.getElementById('selectEtudiantDocument').value = filtre;
  new bootstrap.Modal(document.getElementById('modalDocument')).show();
});
document.getElementById('formDocument').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.id = uid();
  const file = document.getElementById('documentFileInput').files[0];
  if(!file){ toast('Merci de sélectionner un fichier numérique'); return; }
  try{
    data.fichier = await uploadToCloudinary(file);
  }catch(err){
    console.error(err);
    toast("Échec de l'envoi du fichier — réessayez");
    return;
  }
  DB.documents.push(data);
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalDocument')).hide();
  toast('Pièce ajoutée au dossier de l\'étudiant');
  renderDocuments();
});

/* ---------- ANNONCES ---------- */
function renderAnnonces(){
  const editable = canEdit('annonces');
  document.getElementById('btnNewAnnonce').style.display = editable?'inline-block':'none';
  const list = [...DB.annonces].sort((a,b)=>new Date(b.date)-new Date(a.date));
  document.getElementById('annoncesList').innerHTML = list.length ? list.map(a=>`
    <div class="card-clean p-3 mb-3">
      <div class="d-flex justify-content-between align-items-start">
        <h6 class="fw-bold mb-1"><i class="bi bi-megaphone-fill me-1" style="color:var(--amber);"></i> ${a.titre}</h6>
        <div class="d-flex align-items-center gap-2">
          <span class="text-muted small">${fmtDate(a.date)}</span>
          ${editable ? `<button class="btn btn-sm btn-icon text-danger" onclick="askDelete('annonces','${a.id}')"><i class="bi bi-trash"></i></button>` : ''}
        </div>
      </div>
      <p class="small mb-1">${a.contenu}</p>
      <div class="text-muted" style="font-size:.76rem;">Publié par ${a.auteur||'—'}</div>
    </div>`).join('') : `<div class="empty-state"><i class="bi bi-megaphone"></i><p>Aucune annonce publiée</p></div>`;
  // L'étudiant ou le formateur qui consulte les annonces n'a plus de notification à leur sujet sur son tableau de bord.
  if(state.role==='etudiant' || state.role==='formateur'){
    const u = currentUser();
    if(u){ u.lastSeenAnnonces = new Date().toISOString(); saveDB(); }
  }
}
document.getElementById('btnNewAnnonce').addEventListener('click', ()=>{
  document.getElementById('formAnnonce').reset();
  new bootstrap.Modal(document.getElementById('modalAnnonce')).show();
});
document.getElementById('formAnnonce').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.id = uid();
  data.date = new Date().toISOString().slice(0,10);
  data.auteur = state.userName;
  DB.annonces.push(data);
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalAnnonce')).hide();
  toast('Annonce publiée');
  renderAnnonces();
});

/* ---------- MESSAGERIE ---------- */
function renderMessagerie(){
  const list = DB.messages.filter(m=>m.expediteurId===state.userId || m.destinataireId===state.userId)
    .sort((a,b)=>new Date(b.date)-new Date(a.date));
  document.getElementById('messagerieList').innerHTML = list.length ? list.map(m=>{
    const isSent = m.expediteurId===state.userId;
    const autre = DB.users.find(u=>u.id===(isSent?m.destinataireId:m.expediteurId));
    return `<div class="p-3" style="border-bottom:1px solid var(--border);">
      <div class="d-flex justify-content-between align-items-center mb-1">
        <span class="fw-semibold small">${isSent?'À '+ (autre?autre.nom:'—') : 'De '+(autre?autre.nom:'—')}</span>
        <span class="text-muted" style="font-size:.72rem;">${new Date(m.date).toLocaleString('fr-FR',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</span>
      </div>
      <div class="small">${m.contenu}</div>
    </div>`;
  }).join('') : `<div class="empty-state"><i class="bi bi-chat"></i><p>Aucun message</p></div>`;
  // Les messages reçus consultés disparaissent des notifications du tableau de bord.
  const nonLus = DB.messages.filter(m=>m.destinataireId===state.userId && !m.lu);
  if(nonLus.length){ nonLus.forEach(m=>m.lu=true); saveDB(); }
}
document.getElementById('formMessage').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.id = uid();
  data.expediteurId = state.userId;
  data.date = new Date().toISOString();
  data.lu = false;
  DB.messages.push(data);
  await saveDB();
  e.target.reset();
  toast('Message envoyé');
  renderMessagerie();
});

/* ---------- MON PROFIL (auto-gestion du formateur) ---------- */
function resetProfilPhotoBox(){
  document.getElementById('profilPhotoInput').value='';
  document.getElementById('profilPhotoPreview').style.display='none';
  document.getElementById('profilPhotoPreview').src='';
  document.getElementById('profilPhotoPlaceholderIcon').style.display='block';
}
function setProfilPhotoBox(dataUrl){
  const img = document.getElementById('profilPhotoPreview');
  const icon = document.getElementById('profilPhotoPlaceholderIcon');
  const hint = document.getElementById('profilPhotoViewHint');
  if(dataUrl){ img.src = dataUrl; img.style.display='block'; icon.style.display='none'; hint.style.display='flex'; }
  else { img.style.display='none'; icon.style.display='block'; hint.style.display='none'; }
}
// Clic sur la photo (si elle existe déjà) : agrandissement. Sinon : ouvre le sélecteur de fichier.
// Le bouton caméra, lui, ouvre toujours le sélecteur de fichier pour changer la photo.
document.getElementById('profilPhotoUploadBox').addEventListener('click', ()=>{
  const img = document.getElementById('profilPhotoPreview');
  if(img.style.display!=='none' && img.src){ openImgLightbox(img.src); }
  else { document.getElementById('profilPhotoInput').click(); }
});
document.getElementById('profilPhotoEditBtn').addEventListener('click', e=>{
  e.stopPropagation();
  document.getElementById('profilPhotoInput').click();
});
let profilPhotoPending = null;
let profilCvPending = null;
document.getElementById('profilPhotoInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  setProfilPhotoBox(URL.createObjectURL(file));
  profilPhotoPending = null;
  const uploadPromise = uploadToCloudinary(file)
    .then(url => { profilPhotoPending = url; })
    .catch(err => { console.error(err); toast("Échec de l'envoi de la photo — réessayez"); resetProfilPhotoBox(); });
  trackPendingUpload('profilPhoto', uploadPromise);
});
document.getElementById('profilCvInput').addEventListener('change', e=>{
  const file = e.target.files[0];
  if(!file) return;
  document.getElementById('profilCvCurrent').innerHTML = `<span class="text-muted small"><i class="bi bi-arrow-repeat me-1"></i> Envoi de ${file.name} en cours…</span>`;
  const uploadPromise = uploadToCloudinary(file)
    .then(url => {
      profilCvPending = url;
      document.getElementById('profilCvCurrent').innerHTML = `<span class="text-success small"><i class="bi bi-check-circle-fill me-1"></i> Nouveau fichier prêt : ${file.name}</span>`;
    })
    .catch(err => {
      console.error(err);
      toast("Échec de l'envoi du CV — réessayez");
      document.getElementById('profilCvCurrent').innerHTML = `<span class="text-danger small">Échec de l'envoi — réessayez</span>`;
    });
  trackPendingUpload('profilCv', uploadPromise);
});
function renderMonProfil(){
  const u = currentUser();
  const isEtudiant = state.role==='etudiant';
  document.getElementById('monProfilFormateurFields').style.display = isEtudiant ? 'none' : '';
  document.getElementById('monProfilEtudiantFields').style.display = isEtudiant ? '' : 'none';
  let photo = '';
  if(isEtudiant){
    const et = u && u.etudiantId ? getEtudiant(u.etudiantId) : null;
    photo = et?.photo || '';
    document.getElementById('monProfilEtudiantNom').textContent = et ? nomComplet(et) : '—';
    document.getElementById('monProfilEtudiantInfos').textContent = et ? `${et.matricule} · ${getFiliere(et.filiereId)?.nom||'—'}` : '—';
    profilCvPending = null;
  } else {
    const f = u && u.formateurId ? getFormateur(u.formateurId) : null;
    document.getElementById('profilNom').value = f?.nom || '';
    document.getElementById('profilPrenom').value = f?.prenom || '';
    document.getElementById('profilSpecialite').value = f?.specialite || '';
    document.getElementById('profilTelephone').value = f?.telephone || '';
    document.getElementById('profilEmail').value = f?.email || '';
    document.getElementById('profilPortfolio').value = f?.portfolio || '';
    document.getElementById('profilCvInput').value = '';
    profilCvPending = f?.cv || null;
    document.getElementById('profilCvCurrent').innerHTML = f?.cv ? `<a class="btn btn-sm btn-outline-secondary" href="${f.cv}" target="_blank" download="cv-${f.nom||'formateur'}"><i class="bi bi-file-earmark-person"></i> Voir mon CV actuel</a>` : '<span class="text-muted small">Aucun CV déposé pour le moment.</span>';
    photo = f?.photo || '';
  }
  document.getElementById('profilIdentifiant').value = u?.identifiant || '';
  document.getElementById('profilNouveauMdp').value = '';
  document.getElementById('profilMdpActuel').value = '';
  document.getElementById('profilError').style.display = 'none';
  document.getElementById('profilPhotoInput').value = '';
  profilPhotoPending = photo || null;
  setProfilPhotoBox(photo || '');
  renderMaGalerie();
}
document.getElementById('formMonProfil').addEventListener('submit', async e=>{
  e.preventDefault();
  await resolvePendingUpload('profilPhoto');
  await resolvePendingUpload('profilCv');
  const errBox = document.getElementById('profilError');
  errBox.style.display = 'none';
  const u = currentUser();
  if(!u) return;
  const isEtudiant = state.role==='etudiant';
  if(isEtudiant && !u.etudiantId) return;
  if(!isEtudiant && !u.formateurId) return;
  const target = isEtudiant ? getEtudiant(u.etudiantId) : getFormateur(u.formateurId);
  if(!target) return;

  const newIdentifiant = document.getElementById('profilIdentifiant').value.trim();
  const newMdp = document.getElementById('profilNouveauMdp').value;
  const mdpActuel = document.getElementById('profilMdpActuel').value;
  const identifiantChange = newIdentifiant.toLowerCase() !== (u.identifiant||'').toLowerCase();
  const mdpChange = !!newMdp;

  // Le mot de passe actuel est exigé dès qu'on touche à l'identifiant ou au mot de passe
  if(identifiantChange || mdpChange){
    if(!mdpActuel || mdpActuel !== u.motDePasse){
      errBox.textContent = "Mot de passe actuel incorrect. Vos identifiants n'ont pas été modifiés.";
      errBox.style.display = 'block';
      return;
    }
    if(identifiantChange){
      const conflict = DB.users.find(x => (x.identifiant||'').toLowerCase()===newIdentifiant.toLowerCase() && x.id!==u.id);
      if(conflict){
        errBox.textContent = 'Cet identifiant est déjà utilisé par un autre compte.';
        errBox.style.display = 'block';
        return;
      }
      u.identifiant = newIdentifiant;
    }
    if(mdpChange) u.motDePasse = newMdp;
  }

  if(isEtudiant){
    target.photo = profilPhotoPending || '';
  } else {
    target.nom = document.getElementById('profilNom').value;
    target.prenom = document.getElementById('profilPrenom').value;
    target.specialite = document.getElementById('profilSpecialite').value;
    target.telephone = document.getElementById('profilTelephone').value;
    target.email = document.getElementById('profilEmail').value;
    target.portfolio = document.getElementById('profilPortfolio').value;
    target.photo = profilPhotoPending || '';
    target.cv = profilCvPending || '';
    u.nom = nomComplet(target);
  }

  await saveDB();
  state.userName = u.nom;
  document.getElementById('sideUserName').textContent = state.userName;
  document.getElementById('sideUserNameMobile').textContent = state.userName;
  toast('Profil mis à jour');
  renderMonProfil();
  populateAllSelects();
});
document.getElementById('btnExportMaFichePdf').addEventListener('click', ()=>{
  const u = currentUser();
  if(u && u.etudiantId) exportFicheEtudiantPdf(u.etudiantId);
});

/* ---------- MA GALERIE (photos publiées par l'étudiant/formateur) ---------- */
function currentGalerieOwner(){
  const u = currentUser();
  if(!u) return null;
  if(state.role==='etudiant' && u.etudiantId) return {ownerType:'etudiant', ownerId:u.etudiantId};
  if(state.role==='formateur' && u.formateurId) return {ownerType:'formateur', ownerId:u.formateurId};
  return null;
}
function monGaleriePhotos(){
  const owner = currentGalerieOwner();
  if(!owner || !DB || !DB.galerie) return [];
  return DB.galerie.filter(g=>g.ownerType===owner.ownerType && g.ownerId===owner.ownerId);
}
function renderMaGalerie(){
  const box = document.getElementById('profilGaleriePreview');
  if(!box) return;
  const photos = monGaleriePhotos();
  box.innerHTML = photos.length ? photos.map(p=>`
    <div class="col-6 col-sm-4 col-md-3">
      <div style="position:relative;">
        <img src="${p.dataUrl}" class="galerie-photo-card" alt="" onclick="openImgLightbox('${p.dataUrl}')">
        <button type="button" class="btn btn-sm btn-danger" style="position:absolute;top:4px;right:4px;padding:1px 6px;line-height:1;" onclick="event.stopPropagation();supprimerMaPhotoGalerie('${p.id}')" title="Supprimer cette photo"><i class="bi bi-x-lg"></i></button>
      </div>
    </div>`).join('') : '<div class="col-12 text-muted small">Aucune photo publiée pour le moment.</div>';
}
async function supprimerMaPhotoGalerie(id){
  DB.galerie = (DB.galerie||[]).filter(g=>g.id!==id);
  await saveDB();
  renderMaGalerie();
  renderDashboard();
  renderPublicSite();
  toast('Photo supprimée');
}
document.getElementById('profilGaleriePhotoInput').addEventListener('change', async e=>{
  const files = Array.from(e.target.files||[]);
  if(!files.length) return;
  const owner = currentGalerieOwner();
  if(!owner){ e.target.value=''; return; }
  const u = currentUser();
  let okCount = 0;
  for(const file of files){
    try{
      const url = await uploadToCloudinary(file);
      DB.galerie.push({id:uid(), ownerType:owner.ownerType, ownerId:owner.ownerId, dataUrl:url, legende:u?.nom||'', date:new Date().toISOString()});
      okCount++;
    }catch(err){ console.error(err); toast("Échec de l'envoi d'une photo — réessayez"); }
  }
  e.target.value = '';
  if(okCount>0){
    await saveDB();
    renderMaGalerie();
    renderDashboard();
    renderPublicSite();
    toast(okCount>1 ? 'Photos ajoutées à votre galerie' : 'Photo ajoutée à votre galerie');
  }
});

/* ---------- UTILISATEURS (création des profils par la direction) ---------- */
// Onglet actif dans le menu Utilisateurs : administration | formateur | etudiant | partenaire
let usersTab = 'administration';
// Détermine à quel onglet appartient un compte. Tout rôle qui n'est ni formateur, ni étudiant,
// ni partenaire (y compris les futurs profils ajoutés par la direction) tombe dans "Administration".
function userTabForRole(role){
  if(role==='formateur') return 'formateur';
  if(role==='etudiant') return 'etudiant';
  if(role==='partenaire') return 'partenaire';
  return 'administration';
}
document.querySelectorAll('#usersTabGroup [data-userstab]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    usersTab = btn.dataset.userstab;
    document.querySelectorAll('#usersTabGroup [data-userstab]').forEach(b=>b.classList.toggle('active', b===btn));
    renderUtilisateurs();
  });
});
function renderUtilisateurs(){
  const list = DB.users.filter(u=>userTabForRole(u.role)===usersTab);
  const emptyLabel = {administration:'Aucun compte administration', formateur:'Aucun compte formateur', etudiant:'Aucun compte étudiant', partenaire:'Aucun compte partenaire'}[usersTab] || 'Aucun compte créé';
  document.getElementById('usersBody').innerHTML = list.length ? list.map(u=>`
    <tr>
      <td>
        <div class="d-flex align-items-center gap-2">
          <div class="avatar-circ">${initials(u.nom,'')}</div>
          <span>${u.nom}</span>
          <button class="btn btn-sm btn-icon" onclick="editUser('${u.id}')" title="Afficher / modifier"><i class="bi bi-eye"></i></button>
        </div>
      </td>
      <td class="text-mono d-none d-md-table-cell">${u.identifiant||'—'}</td>
      <td><span class="role-badge rb-${u.role}">${ROLES.find(r=>r.id===u.role)?.label||u.role}</span></td>
      <td class="d-none d-lg-table-cell small">${fmtDerniereConnexion(u.derniereConnexion)}</td>
    </tr>`).join('') : `<tr><td colspan="4"><div class="empty-state"><i class="bi bi-person-x"></i><p>${emptyLabel}</p></div></td></tr>`;
}
function fillUserRoleSelect(){
  document.getElementById('selectUserRole').innerHTML = ROLES.map(r=>`<option value="${r.id}">${r.label}</option>`).join('');
}
function fillUserLinkSelects(){
  document.getElementById('selectUserFormateurLink').innerHTML = '<option value="">—</option>' + DB.formateurs.map(f=>`<option value="${f.id}">${nomComplet(f)}</option>`).join('');
  document.getElementById('selectUserEtudiantLink').innerHTML = '<option value="">—</option>' + DB.etudiants.slice().sort((a,b)=>nomComplet(a).localeCompare(nomComplet(b),'fr',{sensitivity:'base'})).map(e=>`<option value="${e.id}">${nomComplet(e)} — ${e.matricule}</option>`).join('');
}
function renderPermsGrid(role, perms){
  const isDirection = role==='direction';
  document.getElementById('userPermsWrap').style.display = isDirection ? 'none' : 'block';
  const effective = perms || defaultPermsForRole(role);
  document.getElementById('userPermsBody').innerHTML = PERMISSION_MODULES.map(n=>{
    const p = effective[n.section] || {view:false,manage:false};
    const manageApplicable = MANAGE_MODULES.includes(n.section);
    return `<tr>
      <td><i class="bi ${n.icon} me-1 text-muted"></i>${n.label}</td>
      <td class="text-center"><input type="checkbox" class="form-check-input perm-view" data-module="${n.section}" ${p.view?'checked':''}></td>
      <td class="text-center">${manageApplicable ? `<input type="checkbox" class="form-check-input perm-manage" data-module="${n.section}" ${p.manage?'checked':''}>` : ''}</td>
    </tr>`;
  }).join('');
}
function toggleUserLinkFields(role){
  document.getElementById('userFormateurLinkWrap').style.display = role==='formateur' ? 'block' : 'none';
  document.getElementById('userEtudiantLinkWrap').style.display = role==='etudiant' ? 'block' : 'none';
}
document.getElementById('selectUserRole').addEventListener('change', e=>{
  const role = e.target.value;
  toggleUserLinkFields(role);
  renderPermsGrid(role, defaultPermsForRole(role));
});
document.getElementById('btnNewUser').addEventListener('click', ()=>{
  fillUserRoleSelect();
  fillUserLinkSelects();
  document.getElementById('formUser').reset();
  document.getElementById('formUser').elements['id'].value='';
  document.getElementById('modalUserTitle').textContent='Nouveau compte';
  document.getElementById('userLastLoginWrap').classList.add('d-none');
  document.getElementById('btnDeleteUserFromModal').classList.add('d-none');
  // Pré-sélectionne le rôle correspondant à l'onglet actif (ex : ouvrir "Nouveau compte" depuis l'onglet Formateur pré-remplit le rôle Formateur).
  const roleForTab = usersTab==='formateur' ? 'formateur' : usersTab==='etudiant' ? 'etudiant' : usersTab==='partenaire' ? 'partenaire' : 'direction';
  document.getElementById('selectUserRole').value = roleForTab;
  const initialRole = document.getElementById('selectUserRole').value;
  toggleUserLinkFields(initialRole);
  renderPermsGrid(initialRole, defaultPermsForRole(initialRole));
  new bootstrap.Modal(document.getElementById('modalUser')).show();
});
function editUser(id){
  fillUserRoleSelect();
  fillUserLinkSelects();
  const u = DB.users.find(x=>x.id===id);
  const f = document.getElementById('formUser');
  Object.keys(u).forEach(k=>{ if(f.elements[k]) f.elements[k].value = u[k]; });
  toggleUserLinkFields(u.role);
  renderPermsGrid(u.role, u.perms);
  document.getElementById('modalUserTitle').textContent='Modifier le compte';
  const lastLoginWrap = document.getElementById('userLastLoginWrap');
  lastLoginWrap.classList.remove('d-none');
  document.getElementById('userLastLoginValue').innerHTML = fmtDerniereConnexion(u.derniereConnexion);
  // Le bouton de suppression n'apparaît qu'en modification d'un compte existant, jamais à la création.
  // On empêche la direction de supprimer son propre compte par erreur pendant qu'elle est connectée dessus.
  const btnDelete = document.getElementById('btnDeleteUserFromModal');
  btnDelete.classList.toggle('d-none', u.id===state.userId);
  btnDelete.onclick = ()=>{
    bootstrap.Modal.getInstance(document.getElementById('modalUser')).hide();
    askDelete('users', u.id);
  };
  new bootstrap.Modal(document.getElementById('modalUser')).show();
}
document.getElementById('formUser').addEventListener('submit', async e=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  const identifiant = data.identifiant.trim().toLowerCase();
  const conflict = DB.users.find(u => (u.identifiant||'').toLowerCase()===identifiant && u.id!==data.id);
  if(conflict){ toast("Cet identifiant est déjà utilisé par un autre compte"); return; }
  // Construction des autorisations à partir des cases cochées
  const perms = defaultPermsForRole(data.role);
  if(data.role!=='direction'){
    PERMISSION_MODULES.forEach(n=>{ perms[n.section] = {view:false, manage:false}; });
    document.querySelectorAll('#userPermsBody .perm-view').forEach(cb=>{
      perms[cb.dataset.module].view = cb.checked;
    });
    document.querySelectorAll('#userPermsBody .perm-manage').forEach(cb=>{
      perms[cb.dataset.module].manage = cb.checked;
    });
  }
  data.perms = perms;
  if(data.role!=='formateur') delete data.formateurId;
  if(data.role!=='etudiant') delete data.etudiantId;
  if(data.id){
    const idx = DB.users.findIndex(x=>x.id===data.id);
    DB.users[idx] = {...DB.users[idx], ...data};
    if(!data.formateurId) delete DB.users[idx].formateurId;
    if(!data.etudiantId) delete DB.users[idx].etudiantId;
  } else {
    data.id = uid();
    DB.users.push(data);
  }
  await saveDB();
  bootstrap.Modal.getInstance(document.getElementById('modalUser')).hide();
  toast('Compte utilisateur enregistré');
  if(data.id===state.userId){ state.role = data.role; renderNav(); } // si la direction modifie son propre compte (rare)
  renderUtilisateurs();
});

/* ---------- SAUVEGARDE GÉNÉRALE (export / restauration) ---------- */
function exportBackup(){
  DB.lastBackupAt = new Date().toISOString();
  const payload = JSON.stringify(DB, null, 2);
  const blob = new Blob([payload], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `anadence-sauvegarde-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  saveDB(); // enregistre discrètement la date de cette sauvegarde, pour le rappel automatique
  checkBackupReminder();
  toast('Sauvegarde téléchargée');
}
document.getElementById('btnExportBackup').addEventListener('click', exportBackup);

/* Rappel automatique : alerte la Direction si aucune sauvegarde n'a été téléchargée depuis 7 jours (ou jamais) */
const BACKUP_REMINDER_DAYS = 7;
function checkBackupReminder(){
  const banner = document.getElementById('backupReminderBanner');
  const textEl = document.getElementById('backupReminderText');
  if(state.role !== 'direction'){ banner.classList.add('d-none'); banner.classList.remove('d-flex'); return; }
  const last = DB.lastBackupAt ? new Date(DB.lastBackupAt) : null;
  const days = last ? Math.floor((Date.now()-last.getTime())/(24*3600*1000)) : null;
  if(!last){
    textEl.textContent = "Aucune sauvegarde de l'application n'a encore été téléchargée. Pensez à en créer une régulièrement pour protéger vos données.";
  } else if(days >= BACKUP_REMINDER_DAYS){
    textEl.textContent = `Dernière sauvegarde téléchargée il y a ${days} jour(s). Pensez à en refaire une.`;
  } else {
    banner.classList.add('d-none'); banner.classList.remove('d-flex');
    return;
  }
  banner.classList.remove('d-none'); banner.classList.add('d-flex');
}
document.getElementById('btnBackupReminderNow').addEventListener('click', exportBackup);
document.getElementById('btnBackupReminderDismiss').addEventListener('click', ()=>{
  const banner = document.getElementById('backupReminderBanner');
  banner.classList.add('d-none'); banner.classList.remove('d-flex');
});

document.getElementById('backupRestoreInput').addEventListener('change', async e=>{
  const file = e.target.files[0];
  if(!file) return;
  try{
    const text = await file.text();
    const parsed = JSON.parse(text);
    // Vérification minimale : le fichier doit ressembler à une vraie sauvegarde de l'application
    if(!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.etudiants) || !Array.isArray(parsed.formateurs) || !Array.isArray(parsed.users)){
      toast('Ce fichier ne ressemble pas à une sauvegarde valide');
      e.target.value = '';
      return;
    }
    const ok = confirm(`Cette opération va REMPLACER toutes les données actuelles de l'application (étudiants, paiements, présences, comptes, etc.) par celles de ce fichier de sauvegarde.\n\nCette action est irréversible. Continuer ?`);
    if(!ok){ e.target.value=''; return; }
    DB = parsed;
    migrateDB();
    await saveDB();
    toast('Sauvegarde restaurée avec succès — rechargement de l\'application...');
    setTimeout(()=> location.reload(), 1200);
  }catch(err){
    console.error(err);
    toast('Échec de la lecture du fichier — vérifiez qu\'il s\'agit bien d\'un fichier de sauvegarde .json');
    e.target.value = '';
  }
});

/* ---------- MIGRATION DES FICHIERS BASE64 VERS CLOUDINARY ---------- */
// Convertit une chaîne "data:...;base64,...." en objet File exploitable par uploadToCloudinary
function dataUrlToFile(dataUrl, filename){
  const [header, b64] = dataUrl.split(',');
  const mimeMatch = header.match(/data:(.*?);base64/);
  const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) bytes[i] = bin.charCodeAt(i);
  return new File([bytes], filename, {type: mime});
}
function isBase64DataUrl(v){
  return typeof v === 'string' && v.startsWith('data:') && v.includes('base64,');
}
// Construit la liste des fichiers encore stockés en base64 dans la base, avec de quoi lire/écrire chacun
function buildMigrationTasks(){
  const tasks = [];
  DB.etudiants.forEach(e=>{
    if(isBase64DataUrl(e.photo)){
      tasks.push({ get:()=>e.photo, set:url=>{ e.photo=url; }, label:`Photo étudiant — ${nomComplet(e)}` });
    }
    ['preuveAbandon','diplomeFichiers'].forEach(field=>{
      let arr; try{ arr = JSON.parse(e[field]||'[]'); }catch(err){ arr = []; }
      arr.forEach((val,i)=>{
        if(isBase64DataUrl(val)){
          tasks.push({
            get:()=>arr[i],
            set:url=>{ arr[i]=url; e[field]=JSON.stringify(arr); },
            label:`${field==='preuveAbandon'?"Preuve d'abandon":'Fichier diplôme'} — ${nomComplet(e)} (${i+1})`
          });
        }
      });
    });
  });
  DB.formateurs.forEach(f=>{
    if(isBase64DataUrl(f.photo)) tasks.push({ get:()=>f.photo, set:url=>{ f.photo=url; }, label:`Photo formateur — ${nomComplet(f)}` });
    if(isBase64DataUrl(f.cv)) tasks.push({ get:()=>f.cv, set:url=>{ f.cv=url; }, label:`CV — ${nomComplet(f)}` });
  });
  DB.documents.forEach(d=>{
    if(isBase64DataUrl(d.fichier)) tasks.push({ get:()=>d.fichier, set:url=>{ d.fichier=url; }, label:`Document — ${d.nom||d.id}` });
  });
  (DB.rapports||[]).forEach(r=>{
    (r.participants||[]).forEach(p=>{
      const et = getEtudiant(p.etudiantId);
      if(isBase64DataUrl(p.fichePhoto)){
        tasks.push({ get:()=>p.fichePhoto, set:url=>{ p.fichePhoto=url; }, label:`Photo fiche rapport — ${nomComplet(et)}` });
      }
      if(Array.isArray(p.photosEtudiant)){
        p.photosEtudiant.forEach((val,i)=>{
          if(isBase64DataUrl(val)){
            tasks.push({
              get:()=>p.photosEtudiant[i],
              set:url=>{ p.photosEtudiant[i]=url; },
              label:`Photo chantier — ${nomComplet(et)} (${i+1})`
            });
          }
        });
      }
    });
  });
  return tasks;
}
async function migratePhotosToCloudinary(){
  const btn = document.getElementById('btnMigrateCloudinary');
  const wrap = document.getElementById('migrationProgressWrap');
  const bar = document.getElementById('migrationProgressBar');
  const label = document.getElementById('migrationProgressLabel');
  const logEl = document.getElementById('migrationLog');
  const log = (html) => { logEl.insertAdjacentHTML('beforeend', `<div>${html}</div>`); logEl.scrollTop = logEl.scrollHeight; };

  const tasks = buildMigrationTasks();
  if(!tasks.length){
    toast('Aucun fichier à migrer — tout est déjà sur Cloudinary');
    return;
  }
  if(!confirm(`${tasks.length} fichier(s) à migrer vers Cloudinary.\nCela peut prendre plusieurs minutes selon votre connexion. Ne fermez pas cette page pendant l'opération.\n\nContinuer ?`)) return;

  btn.disabled = true;
  wrap.style.display = '';
  logEl.innerHTML = '';
  bar.style.width = '0%';
  let done = 0, failed = 0;

  for(const task of tasks){
    label.textContent = `${done+failed+1}/${tasks.length} — ${task.label}`;
    try{
      const dataUrl = task.get();
      const file = dataUrlToFile(dataUrl, task.label.replace(/[^a-z0-9]/gi,'_').toLowerCase() || 'fichier');
      const url = await uploadToCloudinary(file);
      task.set(url);
      done++;
      log(`<span class="text-success">✓</span> ${task.label}`);
    }catch(err){
      failed++;
      console.error(err);
      log(`<span class="text-danger">✗</span> ${task.label} — échec (${err.message||'erreur réseau'})`);
    }
    bar.style.width = Math.round(((done+failed)/tasks.length)*100)+'%';
    // Sauvegarde périodique pour ne rien perdre en cas d'interruption en cours de route
    if((done+failed) % 8 === 0){
      try{ await saveDB(); }catch(err){ console.error(err); }
    }
  }

  await saveDB();
  label.textContent = `Terminé : ${done} fichier(s) migré(s)${failed?`, ${failed} échec(s) — relancez la migration pour réessayer`:''}.`;
  btn.disabled = false;
  toast(failed ? `Migration terminée avec ${failed} échec(s)` : 'Migration terminée avec succès — base allégée');
  renderEtudiants(); renderFormateurs(); renderDocuments();
}
document.getElementById('btnMigrateCloudinary').addEventListener('click', migratePhotosToCloudinary);

/* ---------- LOGO DU CENTRE (Paramètres) ---------- */
// Met à jour tous les emplacements "logo-mark" de l'application (navbar publique, menu offcanvas,
// modale de connexion, sidebar desktop/mobile) avec le logo configuré, ou revient aux initiales "NF".
function refreshCentreLogo(){
  const logo = DB && DB.parametres ? DB.parametres.logo : '';
  document.querySelectorAll('.logo-mark').forEach(el=>{
    if(logo){
      el.classList.add('has-logo');
      el.innerHTML = `<img src="${logo}" alt="Logo">`;
    } else {
      el.classList.remove('has-logo');
      el.innerHTML = 'NF';
    }
  });
  loadCentreLogoForPdf();
}
// Cache en base64 du logo (nécessaire pour l'insérer dans les PDF générés par jsPDF, qui exige des données base64)
let centreLogoPdfDataUrl = null;
async function loadCentreLogoForPdf(){
  const logo = DB && DB.parametres ? DB.parametres.logo : '';
  if(!logo){ centreLogoPdfDataUrl = null; return; }
  try{
    const res = await fetch(logo);
    const blob = await res.blob();
    centreLogoPdfDataUrl = await new Promise((resolve, reject)=>{
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }catch(err){
    console.error('Impossible de charger le logo pour les PDF', err);
    centreLogoPdfDataUrl = null;
  }
}
function renderParametres(){
  setCentreLogoBox(DB.parametres ? DB.parametres.logo : '');
}
function resetCentreLogoBox(){
  document.getElementById('centreLogoInput').value = '';
  document.getElementById('centreLogoPreview').style.display = 'none';
  document.getElementById('centreLogoPreview').src = '';
  document.getElementById('centreLogoPlaceholderIcon').style.display = 'block';
}
function setCentreLogoBox(dataUrl){
  const img = document.getElementById('centreLogoPreview');
  const icon = document.getElementById('centreLogoPlaceholderIcon');
  if(dataUrl){ img.src = dataUrl; img.style.display = 'block'; icon.style.display = 'none'; }
  else { img.style.display = 'none'; icon.style.display = 'block'; }
}
document.getElementById('centreLogoUploadBox').addEventListener('click', ()=> document.getElementById('centreLogoInput').click());
document.getElementById('centreLogoInput').addEventListener('change', async e=>{
  const file = e.target.files[0];
  if(!file) return;
  setCentreLogoBox(URL.createObjectURL(file));
  try{
    const url = await uploadToCloudinary(file);
    if(!DB.parametres) DB.parametres = {logo:'img/logo.png'};
    DB.parametres.logo = url;
    await saveDB();
    refreshCentreLogo();
    toast('Logo du centre mis à jour');
  }catch(err){
    console.error(err);
    toast("Échec de l'envoi du logo — réessayez");
    resetCentreLogoBox();
  }
});
document.getElementById('btnRemoveCentreLogo').addEventListener('click', async ()=>{
  if(!DB.parametres) DB.parametres = {logo:'img/logo.png'};
  DB.parametres.logo = '';
  await saveDB();
  resetCentreLogoBox();
  refreshCentreLogo();
  toast('Logo retiré');
});

/* ---------- DELETE ---------- */
function askDelete(collection, id){
  pendingDelete = {collection, id};
  new bootstrap.Modal(document.getElementById('modalConfirm')).show();
}
document.getElementById('btnConfirmDelete').addEventListener('click', async ()=>{
  if(pendingDelete){
    if(pendingDelete.collection==='presences-session'){
      // Supprime l'appel complet (toutes les présences) d'un module à une date donnée
      DB.presences = DB.presences.filter(p=>!(p.moduleId===pendingDelete.moduleId && p.date===pendingDelete.date));
      await saveDB();
      toast('Appel supprimé');
      renderSection(state.section);
      bootstrap.Modal.getInstance(document.getElementById('modalConfirm')).hide();
      pendingDelete = null;
      return;
    }
    if(pendingDelete.collection==='presences-periode'){
      // Supprime tous les appels de la période/filière filtrée
      const idsSet = new Set(pendingDelete.ids);
      DB.presences = DB.presences.filter(p=>!idsSet.has(p.id));
      await saveDB();
      toast('Appels de la période supprimés');
      renderSection(state.section);
      bootstrap.Modal.getInstance(document.getElementById('modalConfirm')).hide();
      pendingDelete = null;
      return;
    }
    if(pendingDelete.collection==='paiements'){
      DB.paiements = DB.paiements.filter(x=>x.id!==pendingDelete.id);
      await saveDB();
      toast('Versement supprimé');
      renderSection(state.section);
      if(currentHistoriqueEtId) viewHistorique(currentHistoriqueEtId);
      bootstrap.Modal.getInstance(document.getElementById('modalConfirm')).hide();
      pendingDelete = null;
      return;
    }
    if(pendingDelete.collection==='modules'){
      // Retire le module des inscriptions des étudiants et supprime les présences liées
      DB.etudiants.forEach(e=>{ if(e.moduleIds) e.moduleIds = e.moduleIds.filter(id=>id!==pendingDelete.id); });
      DB.presences = DB.presences.filter(p=>p.moduleId!==pendingDelete.id);
    }
    if(pendingDelete.collection==='formateurs'){
      // Détache le formateur des modules qui lui étaient confiés
      DB.modules.forEach(m=>{ if(m.formateurId===pendingDelete.id) m.formateurId=''; });
    }
    if(pendingDelete.collection==='filieres'){
      // Supprime aussi les modules de cette filière, les inscriptions et les présences correspondantes
      const modIds = modulesOfFiliere(pendingDelete.id).map(m=>m.id);
      DB.modules = DB.modules.filter(m=>m.filiereId!==pendingDelete.id);
      DB.etudiants.forEach(e=>{ if(e.moduleIds) e.moduleIds = e.moduleIds.filter(id=>!modIds.includes(id)); });
      DB.presences = DB.presences.filter(p=>!modIds.includes(p.moduleId));
    }
    DB[pendingDelete.collection] = DB[pendingDelete.collection].filter(x=>x.id!==pendingDelete.id);
    await saveDB();
    toast('Élément supprimé');
    populateAllSelects();
    renderSection(state.section);
    if(document.getElementById('modalModules').classList.contains('show')) renderModulesList();
  }
  bootstrap.Modal.getInstance(document.getElementById('modalConfirm')).hide();
  pendingDelete = null;
});

/* ---------- INIT ---------- */
(async function init(){
  try{
    await loadDB();
  }catch(e){
    // Le chargement a échoué : l'overlay d'erreur est déjà affiché par loadDB(), on n'ouvre surtout
    // pas l'application avec une base vide (cela écraserait les vraies données à la prochaine sauvegarde).
    return;
  }
  refreshCentreLogo();
  renderPublicSite();
  let savedUserId = null;
  try{ savedUserId = localStorage.getItem('anadenceSessionUserId'); }catch(e){}
  const savedUser = savedUserId ? DB.users.find(u=>u.id===savedUserId) : null;
  if(savedUser){
    enterApp(savedUser, true);
  } else {
    document.getElementById('publicSite').style.display='block';
  }
})();
